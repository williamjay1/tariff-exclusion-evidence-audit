# Tariff product-scope matching: reproducibility materials

This package supports the empirical study of Section 301 product-exclusion scope matching. It contains the frozen benchmark inputs, reference evidence, synthetic numeric stress test, model predictions, analysis code, source provenance, and independent checks. It does not contain model weights or the full downloaded corpus. The official rulings and statutory extracts are historical research materials; the task supplies CBP's base tariff classification and a candidate exclusion description. It does not predict base classification or determine current legal eligibility.

## Data and evidential boundaries

`datasets/benchmark.jsonl` contains 86 product–candidate pairs from 77 rulings and 45 grouping components. The supplied `group` and `fold` fields preserve the recorded five outer folds. The main same-code subset has 73 pairs. The all-code-known and exact-ten-digit subsets have 85 and 60 pairs respectively. A supplied eight-digit classification is never padded to ten digits. The earlier/later group-purged sensitivity is recorded in `results/chronological_sensitivity.json`.

`hq_reference.jsonl` and `ny_reference.jsonl` preserve the broader curated candidate set, reference dispositions, source quotations, locators, and screening decisions. Labels were coded by AI agents and checked against official text by another AI agent; they are **not independently human-expert validated gold labels**. Independent arithmetic audits do not establish the validity of the underlying labels. Reference dispositions describe CBP's decisions, and selected facts may omit an attribute used or assumed in that decision.

`datasets/statutory_rules.jsonl` contains 397 distinct descriptions with 429 note aliases from the USTR index updated January 17, 2024. There are 41 whole-code descriptions and 356 descriptions with narrower product text. The official PDF is not included; its extracted text and an independent table-extraction audit are retained. These historical rules are not asserted to remain in force.

`numeric_rule_gold.jsonl` contains 60 independently source-coded numeric predicates used to construct the **synthetic** stress test. These rules were purposively selected, not randomly sampled. Its fixed SHA-256 is `55c9dd4f3636a2c9adfc74efcd87bfd507933149de06fcc32cb10115113af804`. Models receive the selected literal numeric clause rather than the complete exclusion description. `stress.jsonl` contains 480 scenario rows, 443 distinct rule-ID/fact/label specifications, and 37 repeated rows under that identity. Ignoring source-rule identity, there are 435 distinct model inputs and 59 distinct literal clauses; `stress_input_duplicate_audit.json` records this additional post hoc sensitivity. Its 120 unit-conversion slots include 112 actual unit-representation changes and eight identity controls. All other product conditions are explicitly assumed satisfied; these are not 480 additional real CBP decisions. Gold construction preceded inspection of numeric-parser performance and was not regenerated to improve test results.

The packaged `cbp_rulings_derived.jsonl` is a **92-ruling subset**, selected by the union of ruling IDs in the curated references. It retains complete processed source records for auditing included and screened candidates. The original derived corpus contained 2,482 rulings and is not bundled. `source_provenance.json` lists the subset IDs and the official retrieval URL, time, size, and raw-response hash wherever applicable. Full acquisition manifests retain the query history and identify records outside the packaged subset. References to the original F: paths in these records are historical provenance, not files claimed to be present in the archive.

## Annotation erratum without changing frozen inputs

The H330938_1 `annotation_note` in the frozen benchmark and HQ reference incorrectly says that the absence of connectors “first appears in analysis.” The analysis quotes the statutory no-connectors condition and grants eligibility, but does not separately state a connector fact. The supplied FACTS extract does not establish that attribute. `annotation_errata.json` records this correction. The old note was never passed to any model; the prompt uses only facts and the literal candidate scope. No input bytes, disposition label, or prediction were changed to make this correction.

## Files and integrity

- `datasets/`: frozen model inputs, curated references, independent numeric coding, statutory extracts, and acquisition provenance.
- `results/`: frozen prediction JSONL files; per-run metadata; shared numeric traces; primary, sensitivity, and independent analyses. The original legacy NLI runs have `.meta.json` files but did not initially have separate `.run.json` fingerprints; their saved prompts and pinned model revisions are retained.
- `scripts/`: inference, baseline fitting, parsing, stress generation, analysis, validation, and optional acquisition code.
- `research/`: experiment plan, source checks, code preflight review, grounding and error analyses, and result audits. These reports record the scope and timing of checks; an earlier report that explicitly excludes the later 4B model is not evidence that the 4B run was checked at that earlier time.
- `model_metadata/`: pinned repository provenance, model cards, configuration, and available license text, without model weights or tokenizer vocabularies.
- `MANIFEST.json`: payload sizes and SHA-256 hashes, original copied-file hashes, and any package-only ROOT transformation. The manifest excludes its own hash. The sibling `RELEASE.json` identifies the ZIP hash.

Before running any analysis, extract a working copy to a D: computation directory and retain the original ZIP. The bundled analysis scripts write their own result files; execute them in a working copy if the delivered snapshot must remain unchanged. The preparation script in the original workspace defaults to plan-only mode and refuses a final build until all six neural prediction sets and required analyses are complete.

## Recompute recorded results without model downloads

From the extracted package root, a Python 3.12 interpreter can independently reconstruct the primary confusion counts, balanced accuracy, selective error counts, assumed cost calculations, source-composition diagnostics, and chronological/untruncated summaries using the Python standard library:

```powershell
python -B -X utf8 scripts/verify_results.py
```

This writes `results/independent_result_audit.json` and `research/result_audit.md` in the working copy. It reads the frozen neural/classical predictions and numeric states; it neither refits models nor changes the parser. It verifies 1,277 primary-analysis fields and the frozen parser hash. Its stated audit scope excludes the later 4B results. The later model can be independently checked with NumPy installed:

```powershell
python -B -X utf8 scripts/verify_scale_results.py
```

This audit reads all individual 4B predictions and reconstructs binary/selective metrics, assumed costs, stress scenarios, source-conditioned counts, prompt payloads, and recorded choice decisions. Bootstrap intervals are separately reconstructed by weighting group-level counts. It writes `results/independent_scale_audit.json` and `research/scale_result_audit.md` in the working copy. It does not run inference or repeat the earlier 1,277-field audit.

To reconstruct the primary analysis, including cluster bootstrap intervals, use an environment with NumPy and scikit-learn:

```powershell
python -B -X utf8 scripts/analyze_experiments.py
python -B -X utf8 scripts/analyze_scale.py
```

`cbp_preflight_checks.py` checks the numeric-source/test construction using independent arithmetic. `audit_grounding.py` checks source-string grounding against the selected cached official texts. It cannot certify that an adjudicated outcome is inferable from the retained facts. `diagnose_identifier.py` reproduces a post hoc, single-case intervention on the model identifier UH72600W; it is a failure diagnostic, not a new training example or parser repair. `prepare_benchmark.py`, `generate_stress.py`, and the reference-construction scripts describe how the frozen data were assembled; rerunning a construction script is unnecessary for recomputing the reported metrics and can overwrite its working-copy output.

## Refit or rerun models

The recorded neural runs used `D:\ptenv\Scripts\python.exe` (Python 3.12.10), with `D:\MLWork\tariff_scope_20261007\deps` on `PYTHONPATH` for Transformers and dependencies. Run metadata records PyTorch runtime `2.13.0+cpu` and Transformers `4.57.6`; scikit-learn is 1.9.0. `environment_capture.json` records distribution metadata from the packaging process and is **not** a claimed exact historical dependency lock. Versions reported by distribution metadata can differ from the imported runtime when dependencies are overlaid on `PYTHONPATH`; inspect the run metadata and the actual imported module versions before an inference rerun. No dependency installation is bundled.

Classical models can be refitted with `python -B scripts/run_classical.py`. It uses the supplied group folds, performs inner selection on the outer-training data, and separately fits the recorded chronological sensitivity. Neural model artifacts must be obtained from the pinned public repositories below and placed under `cache/models/nli`, `cache/models/qwen`, and `cache/models/qwen4` in the extracted working copy. The preparation scripts download these fixed revisions; consult their settings before initiating network transfers. All model caches, temporary files and working results must stay on D: in this project.

| Model | Repository | Pinned revision |
|---|---|---|
| NLI | `cross-encoder/nli-deberta-v3-small` | `fa2804872c3b4bd748f38c0185cc85775361e735` |
| Qwen 0.6B | `Qwen/Qwen3-0.6B` | `c1899de289a04d12100db370d81485cdf75e47ca` |
| Later Qwen 4B | `Qwen/Qwen3-4B-Instruct-2507` | `cdbee75f17c01a7cc42f958dc650907174af0554` |

After obtaining and verifying the weights, examples that create new prediction filenames are:

```powershell
python -B -X utf8 scripts/run_neural.py --model nli --input benchmark.jsonl --output replay_benchmark_nli.jsonl
python -B -X utf8 scripts/run_neural.py --model qwen --input benchmark.jsonl --output replay_benchmark_qwen.jsonl
python -B -X utf8 scripts/run_neural.py --model qwen4 --input benchmark.jsonl --output replay_benchmark_qwen4.jsonl
python -B -X utf8 scripts/run_neural.py --model qwen4 --input stress.jsonl --output replay_stress_qwen4.jsonl
```

The scripts operate offline once the artifacts are cached. Existing output names invoke fingerprint-checked resume behavior, not a fresh run. The stress-batching preparation/plan files are shared within a working root, so use a separate extracted working copy for a wholly independent 4B stress run. The larger model is a post hoc stronger-model sensitivity: version, post-training, native template, and BF16 arithmetic differ from the 0.6B model; this is not a controlled parameter-count scaling experiment. Its stress batching was chosen by an outcome-blind speed/numerical preflight, and batch-time allocations are not per-request latency measurements.

## Paths, source acquisition, and portability

The original experiment scripts used a hard-coded D: project ROOT. In **package copies only**, the exact `Path(original project root)` expression is replaced by `Path(__file__).resolve().parents[1]`. The packager validates that the Python abstract syntax tree differs only in those ROOT expressions, records both original and payload hashes, and leaves the original scripts unchanged. The constraint engine has no project ROOT and is copied byte-for-byte, preserving its frozen hash. This is a limited path adaptation, not a claim that every external acquisition or environment setup is universally portable.

Optional acquisition and original PDF-table checking retain F: raw-data paths and may require local configuration. The full corpus, raw PDF, model weights, installed dependencies, and original raw files are absent. Analysis and source-quote auditing use the included D: processed data; reconstructing the original broad search corpus requires new requests. Existing immutable raw data must not be overwritten, moved, or deleted. The collection scripts use fresh run folders. Configure original-source storage to an appropriate new immutable raw directory and processing output to D: before reacquisition.

Official source locations:

- CBP CROSS ruling page: `https://rulings.cbp.gov/ruling/{rulingNumber}`.
- CBP ruling JSON: `https://rulings.cbp.gov/api/ruling/{rulingNumber}`.
- CBP search JSON: `https://rulings.cbp.gov/api/search`; query arguments and retrieval dates are in the acquisition manifests. The recorded search interval was January 1, 2018 through October 7, 2026. The final downloaded set spans January 16, 2018 through September 16, 2026; this is a query-derived corpus, not an asserted census of every relevant ruling.
- USTR January 17, 2024 index: <https://ustr.gov/sites/default/files/Updated%20Index%20of%20Exclusions%20for%20Extension%201.17.24.pdf>.

These APIs and URLs were usable at collection time and may later change. A failed current request does not alter the stored retrieval record. Reacquisition can return revised content; compare hashes and preserve new downloads as a new version.

## Attribution and licensing

Official source excerpts retain CBP/USTR attribution and links. Public accessibility is not treated as a blanket license for every quoted third-party element; no new license is asserted for the official corpus or derived annotations. This archive does not grant rights beyond those held by the relevant source or contributor. No separate blanket redistribution license has been assigned to the project code or annotations in this delivery. Preserve provenance and check applicable source terms before redistributing a public derivative.

The included model cards identify Apache-2.0 for the three upstream model repositories; available upstream license files are retained in `model_metadata`. Those licenses govern the corresponding upstream artifacts and do not relicense the research corpus. Model weights are not redistributed here. There is no minted archive DOI or external repository release associated with this local delivery.
