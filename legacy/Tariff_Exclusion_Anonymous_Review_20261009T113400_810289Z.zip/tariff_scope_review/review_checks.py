"""Standard-library checks for the extracted anonymized review archive."""
from pathlib import Path
from collections import Counter
import hashlib,json,math,statistics
ROOT=Path(__file__).resolve().parent
V=ROOT/'revision_20261009'
def rows(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
manifest=read(ROOT/'review_manifest.json')
for rel,record in manifest['files'].items():
    p=ROOT/rel
    assert p.is_file(),rel
    assert hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256'],rel
benchmark=rows(ROOT/'datasets/benchmark.jsonl')
stress=rows(ROOT/'datasets/stress.jsonl')
assert len(benchmark)==86 and len({r['case_id'] for r in benchmark})==86
primary={r['case_id']:r for r in benchmark if r['code_match']==1}
exact={r['case_id']:r for r in benchmark if r['exact_code_match']}
assert len(primary)==73 and len(exact)==60
assert Counter(r['y'] for r in primary.values())=={1:47,0:26}
assert len(stress)==480 and len({r['case_id'] for r in stress})==480
evidence={r['case_id']:r for r in rows(V/'evidence_numeric/evidence_operational_reference.jsonl')}
assert set(evidence)==set(primary)
assert Counter(r['operational_evidence_state'] for r in evidence.values())=={'support':21,'refute':5,'unknown':47}
assert sum(len(r['conditions']) for r in rows(V/'evidence_numeric/evidence_condition_codes.jsonl'))==208
agreement=read(V/'evidence_numeric/evidence_agreement.json')
assert agreement['matching']==66 and agreement['n']==73
numerical={r['case_id']:r for r in rows(V/'evidence_numeric/real_numeric_v2_predictions.jsonl')}
assert len(numerical)==33
assert sum(r['prediction']==r['gold'] for r in numerical.values())==24
constructed=rows(V/'evidence_numeric/constructed_diagnostics.jsonl')
new_numeric=rows(V/'evidence_numeric/constructed_v2_predictions.jsonl')
assert len(constructed)==len(new_numeric)==96
assert len({(r['facts'],r['rule_text']) for r in constructed})==88
assert sum(r['prediction']==r['gold'] for r in new_numeric)==73
layers=read(V/'evidence_numeric/numeric_layer_analysis.json')
assert [layers['layer_results'][k]['three_state_correct'] for k in ['reference_rule_reference_fields','auto_rule_reference_fields','reference_rule_auto_fields','auto_rule_auto_fields']]==[33,30,17,17]
diagnostics=rows(V/'diagnostics/all_diagnostic_predictions.jsonl')
original={}
for model in sorted({r['model'] for r in diagnostics}):
    rr=[r for r in diagnostics if r['model']==model and r['code_match']==1]
    if len(rr)!=73:continue
    tp=sum(r['y']==1 and r['binary']==1 for r in rr)
    tn=sum(r['y']==0 and r['binary']==0 for r in rr)
    original[model]={'n':73,'tp':tp,'tn':tn,'ba':.5*(tp/47+tn/26),'answers':sum(r['selective']!=-1 for r in rr),'answered_errors':sum(r['selective']!=-1 and r['selective']!=r['y'] for r in rr)}
letter_mass={}
mass_reference=read(V/'diagnostics/letter_mass_independent_check.json')
for name in ['qwen14','granite8']:
    p=V/'models/outputs'/('benchmark_'+name+'_abc_original.jsonl')
    rr=rows(p);mass=[sum(math.exp(r['letter_logprobs'][k]) for k in ['A','B','C']) for r in rr]
    assert len(rr)==86 and all(abs(m-r['bare_letter_mass'])<1e-10 for m,r in zip(mass,rr))
    q=mass_reference[name]
    assert hashlib.sha256(p.read_bytes()).hexdigest()==q['source_sha256']
    assert abs(statistics.median(mass)-q['median_bare_letter_mass'])<1e-12
    assert abs(min(mass)-q['minimum_bare_letter_mass'])<1e-12
    assert Counter(r['raw_output'] for r in rr)==q['first_generated_tokens']
    letter_mass[name]={'n':86,'median':statistics.median(mass),'minimum':min(mass),'first_tokens':q['first_generated_tokens']}
native=[]
for p in sorted((V/'models/outputs').glob('benchmark_*.jsonl')):
    rr=rows(p)
    assert len(rr)==86 and {r['case_id'] for r in rr}=={r['case_id'] for r in benchmark},p.name
    rr=[r for r in rr if r['case_id'] in primary]
    correct=0;invalid=0;answers=0;disposition_errors=0
    for r in rr:
        status=r.get('pipeline_status','')
        bad=bool(r.get('invalid_output')) or status in ['invalid_rule_parse','invalid_evidence_parse']
        parsed=r.get('parsed')
        if 'parsed' not in r and 'prob_eligible' in r:
            parsed={1:'eligible',0:'ineligible',-1:'unknown'}.get(r.get('selective_prediction'))
        state={'eligible':'support','ineligible':'refute','unknown':'unknown'}.get(parsed)
        if bad or state is None:invalid+=1
        else:correct+=state==evidence[r['case_id']]['operational_evidence_state']
        pred=r.get('selective_prediction')
        if pred in [0,1]:
            answers+=1;disposition_errors+=pred!=primary[r['case_id']]['y']
    record={'file':p.name,'n':73,'evidence_correct':correct,'invalid':invalid,'determinate_n':answers,'disposition_errors':disposition_errors}
    if rr and all('binary_prediction' in r for r in rr):
        tp=sum(r['binary_prediction']==1 and primary[r['case_id']]['y']==1 for r in rr)
        tn=sum(r['binary_prediction']==0 and primary[r['case_id']]['y']==0 for r in rr)
        record['forced_binary_ba']=.5*(tp/47+tn/26)
    native.append(record)
mechanism=[]
truth={r['case_id']:{'pass':'eligible','fail':'ineligible','unknown':'unknown'}[r['gold']] for r in constructed}
for p in sorted((V/'models/outputs').glob('mechanism_*.jsonl')):
    rr=rows(p)
    assert len(rr)==96 and {r['case_id'] for r in rr}==set(truth),p.name
    correct=sum(not r.get('invalid_output') and r.get('parsed')==truth[r['case_id']] for r in rr)
    mechanism.append({'file':p.name,'n':96,'correct':correct,'invalid':sum(bool(r.get('invalid_output')) for r in rr)})
out={'status':'PASS','verified_payload_files':len(manifest['files']),'counts':{'pairs':86,'primary':73,'exact':60,'stress':480,'AI_evidence_states':{'support':21,'refute':5,'unknown':47},'real_numeric':{'cases':33,'conditions':43,'v2_correct':24},'mechanism':{'slots':96,'unique_inputs':88,'v2_correct':73}},'original_models_recalculated':original,'letter_mass_recalculated':letter_mass,'new_native_models_recalculated':native,'new_mechanism_models_recalculated':mechanism}
print(json.dumps(out,indent=2))
(ROOT/'review_check_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
