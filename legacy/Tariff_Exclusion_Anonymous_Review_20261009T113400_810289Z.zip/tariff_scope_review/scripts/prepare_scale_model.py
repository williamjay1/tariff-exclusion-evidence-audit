from prepare_models import download_model
if __name__=='__main__':
    download_model(('qwen4',('Qwen/Qwen3-4B-Instruct-2507','cdbee75f17c01a7cc42f958dc650907174af0554')))
