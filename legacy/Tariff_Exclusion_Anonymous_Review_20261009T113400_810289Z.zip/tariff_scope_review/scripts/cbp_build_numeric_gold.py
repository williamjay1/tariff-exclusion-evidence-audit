"""Independent source-read threshold annotations; no model-parser output is used.

Explicit constants below were read from official USTR descriptions. This is a
synthetic unit-predicate stress-test reference, NOT new observed CBP cases.
"""
import hashlib,json,datetime as dt
from pathlib import Path
R=Path(__file__).resolve().parents[1]
ind=[json.loads(s) for s in (R/'datasets'/'cbp_statutory_independent.jsonl').read_text('utf-8').splitlines()]
source={a:r for r in ind for a in r['aliases']}
# suffix, exact source clause, attribute, canonical unit, lower, lower inclusive,
# upper, upper inclusive. Null bounds remain unspecified, never imputed as zero.
G=[
('i)(15','each exceeding 746 W but not exceeding 2,238 W','power','W',746,False,2238,True),
('i)(22','of a width not exceeding 51 cm','width','cm',None,None,51,True),
('i)(27','weighing less than 36 kg','mass','kg',None,None,36,False),
('i)(52','not exceeding 16 W','power','W',None,None,16,True),
('i)(53','of an output of less than 18.65 W','output_power','W',None,None,18.65,False),
('i)(54','of an output exceeding 37.5 W but not exceeding 74.6 W','output_power','W',37.5,False,74.6,True),
('i)(57','of an output of 186.5 kW or more but not exceeding 373 kW','output_power','kW',186.5,True,373,True),
('i)(58','each of an output exceeding 300 kW but not exceeding 310 kW','output_power','kW',300,False,310,True),
('i)(60','measuring 100 mm or more but not over 130 mm in length','length','mm',100,True,130,True),
('i)(64','rated at over 5 A','current_rating','A',5,False,None,None),
('i)(66','for a voltage not exceeding 1,000 V','voltage','V',None,None,1000,True),
('i)(76','having a transmission range of not over 140 m','transmission_range','m',None,None,140,True),
('i)(8','pumps rated not over 1.5 KW','power_rating','kW',None,None,1.5,True),
('i)(87','6.5 mm or less in thickness','thickness','mm',None,None,6.5,True),
('ii)(10','having a displacement of more than 2 liters but not more than 2.5 liters','engine_displacement','L',2,False,2.5,True),
('ii)(11','each article weighing not more than 3 kg','mass','kg',None,None,3,True),
('ii)(12','individually weighing less than 14 kg','mass','kg',None,None,14,False),
('ii)(13','of 18.65 W or more but not exceeding 37.5 W','power','W',18.65,True,37.5,True),
('ii)(14','with an output of 18.65 W or more but not exceeding 37.5 W','output_power','W',18.65,True,37.5,True),
('ii)(15','with an output exceeding 74.6 W but not exceeding 735 W','output_power','W',74.6,False,735,True),
('ii)(16','with an output not exceeding 140 W','output_power','W',None,None,140,True),
('ii)(17','with an output not exceeding 515 W','output_power','W',None,None,515,True),
('ii)(18','with an output exceeding 74.6 W but not exceeding 735 W','output_power','W',74.6,False,735,True),
('ii)(19','with a power output exceeding 74.6 W but not exceeding 230 W','output_power','W',74.6,False,230,True),
('ii)(2','measuring not more than 2 cm in width','width','cm',None,None,2,True),
('ii)(28','for a voltage exceeding 1,000 V','voltage','V',1000,False,None,None),
('ii)(3','in rolls measuring not over 4.8 cm in width','roll_width','cm',None,None,4.8,True),
('ii)(30','of a cylinder capacity not exceeding 50 cc','cylinder_capacity','cm3',None,None,50,True),
('ii)(31','each of a power not exceeding 1,000 W','power','W',None,None,1000,True),
('ii)(6','measuring 2.5 cm or more but not exceeding 5.1 cm in width','width','cm',2.5,True,5.1,True),
('ii)(7','having a total thickness greater than 0.01 mm but not greater than 0.03 mm','total_thickness','mm',0.01,False,0.03,True),
('ii)(9','of a width greater than 1 m but not greater than 1.5 m','width','m',1,False,1.5,True),
('iii)(101','weighing at least 1.80 kg but no more than 2.72 kg','mass','kg',1.8,True,2.72,True),
('iii)(103','weighing not more than 127 kg','mass','kg',None,None,127,True),
('iii)(104','with a maximum weighing capacity of not more than 16 kg','maximum_weighing_capacity','kg',None,None,16,True),
('iii)(105','weighing at least 22 kg but not more than 42 kg','mass','kg',22,True,42,True),
('iii)(106','each such machine weighing 45 kg or more but not over 140 kg','mass','kg',45,True,140,True),
('iii)(112','measuring not less than 25 mm and not more than 105 mm in width','strap_width','mm',25,True,105,True),
('iii)(114','of an output of 56 W or more but not exceeding 69 W','output_power','W',56,True,69,True),
('iii)(115','of an output of 74.6 W or more but not exceeding 228 W','output_power','W',74.6,True,228,True),
('iii)(116','each of an output exceeding 74.6 W but not exceeding 335 W','output_power','W',74.6,False,335,True),
('iii)(117','each weighing at least 7 kg but not more than 11 kg','mass','kg',7,True,11,True),
('iii)(118','each weighing at least 9 kg but not more than 12.5 kg','mass','kg',9,True,12.5,True),
('iii)(119','weighing not more than 27.5 kg','mass','kg',None,None,27.5,True),
('iii)(122','of a power not exceeding 50 W','power','W',None,None,50,True),
('iii)(123','of a power not exceeding 1,500 W','power','W',None,None,1500,True),
('iii)(127','weighing more than 1.5 kg but not more than 17 kg','mass','kg',1.5,False,17,True),
('iii)(129','weighing not more than 55 kg','mass','kg',None,None,55,True),
('iii)(133','weighing not more than 87 g','mass','g',None,None,87,True),
('iii)(134','weighing not more than 175 g','mass','g',None,None,175,True),
('iii)(135','weighing not more than 450 g','mass','g',None,None,450,True),
('iii)(140','each measuring not more than 17 cm in height','height','cm',None,None,17,True),
('iii)(142','each measuring at least 9 m but not longer than 16 m in length','length','m',9,True,16,True),
('iii)(143','each measuring at least 4 m but not longer than 16 m in length','length','m',4,True,16,True),
('iii)(145','for a voltage not more than 1,000 V','voltage','V',None,None,1000,True),
('iii)(155','both measuring more than 69 cm but not more than 71 cm in diameter','wheel_diameter','cm',69,False,71,True),
('iii)(156','weighing less than 16.3 kg without accessories','mass_without_accessories','kg',None,None,16.3,False),
('iii)(157','having both wheels exceeding 63.5 cm in diameter','wheel_diameter','cm',63.5,False,None,None),
('iii)(159','weighing not more than 17.5 kg','mass','kg',None,None,17.5,True),
('iii)(160','with diameter (including, where appropriate, tires) of 20 cm or more but not over 23 cm','diameter_including_tires_where_appropriate','cm',20,True,23,True),
]
out=[]
for suffix,clause,attribute,unit,lower,li,upper,ui in G:
    rid='20(ttt)('+suffix+')'
    src=source[rid]
    assert clause in src['description'],(rid,'quote not verbatim',clause)
    assert lower is None or upper is None or lower<=upper
    out.append({'rule_id':rid,'clause':clause,'attribute':attribute,'unit':unit,'lower':lower,'lower_inclusive':li,'upper':upper,'upper_inclusive':ui,'base_description':src['description'],'source_page':src['page'],'source_quote':clause,'source_note_aliases':src['aliases'],'test_role':'synthetic_single_numeric_predicate_stress_test','other_conditions':'Fixed and assumed satisfied for this local predicate test; no full product eligibility claim.','annotation_provenance':'Source-read, manually specified constants by a separate AI agent; not generated from the evaluated parser or model outputs; no independent human expert review.'})
assert len(out)==60 and len(set(x['rule_id'] for x in out))==60
p=R/'datasets'/'numeric_rule_gold.jsonl'
if p.exists():raise FileExistsError('Gold already exists; do not silently replace a frozen reference')
b=''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out).encode('utf-8');p.write_bytes(b)
summary={'created_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'n_rules':len(out),'n_distinct_rules':len(set(r['rule_id'] for r in out)),'gold_sha256':hashlib.sha256(b).hexdigest(),'gold_path':str(p),'source':'USTR Index of Exclusions for Possible Extension, dated 2024-01-17','independent_source_extraction':'pdfplumber table geometry, independently checked against primary parser','claims_boundary':'Synthetic, one numeric predicate per actual rule; other conditions assumed satisfied. Not 60 new real-world cases; not full eligibility validation.','human_expert_review':False,'selected_before_access_to_model_results':True,'unit_normalization':{'KW':'kW','liters':'L','cc':'cm3'},'null_semantics':'No stated lower or upper bound; inclusive field is also null. Physical positivity is a domain restriction on generated inputs, not an inferred legal bound.','two_bound':sum(r['lower'] is not None and r['upper'] is not None for r in out),'upper_only':sum(r['lower'] is None and r['upper'] is not None for r in out),'lower_only':sum(r['lower'] is not None and r['upper'] is None for r in out),'exclusions':['20(ttt)(iii)(179) has a source-text 183 m upper width next to cm dimensions; exclude rather than silently repair it.','Ambiguous width-or-length disjunctions and unqualified range endpoint semantics excluded.']}
(R/'datasets'/'numeric_rule_gold_manifest.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
