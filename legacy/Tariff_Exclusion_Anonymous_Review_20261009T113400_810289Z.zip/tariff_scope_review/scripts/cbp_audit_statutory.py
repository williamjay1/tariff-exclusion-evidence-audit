"""Independent coordinate/table extraction audit of USTR index parser."""
import collections,difflib,json,re
from pathlib import Path
import pdfplumber
R=Path(__file__).resolve().parents[1]
pdf=Path(r'F:\AcademicData\tariff_scope_20261007\raw\statutes\ustr_index_20240117_20261007.pdf')
pattern=r'20\((?:ttt|uuu)\)\([iv]+\)\(\d+\)'
clean=lambda x:re.sub(r'\s+',' ',x).strip()
rows=[];empty=[];counts=[]
with pdfplumber.open(pdf) as doc:
    for i,page in enumerate(doc.pages):
        tables=page.extract_tables();counts.append([len(t) for t in tables])
        for ti,t in enumerate(tables):
            for ri,row in enumerate(t):
                txt=' '.join(x or '' for x in row)
                notes=re.findall(pattern,txt)
                if not notes:
                    if 'Reinstatement' not in txt:empty.append({'page':i+1,'row':ri,'text':txt})
                    continue
                desc=clean(re.sub(pattern,'',txt))
                rows.append({'page':i+1,'table_row':ri,'aliases':notes,'description':desc,'hts':sorted(set(re.findall(r'\b\d{4}\.\d{2}\.\d{4}\b',desc))),'whole_code':bool(re.fullmatch(r'\d{4}\.\d{2}\.\d{4}',desc))})
root=[json.loads(x) for x in (R/'datasets'/'statutory_rules.jsonl').read_text('utf-8').splitlines()]
mapping={tuple(r['aliases']):r for r in root}
diff=[]
for r in rows:
    o=mapping.get(tuple(r['aliases']))
    if not o:diff.append({'type':'alias_group_mismatch','row':r});continue
    if clean(o['description'])!=r['description']:
        diff.append({'type':'text_difference','aliases':r['aliases'],'page':r['page'],'independent':r['description'],'root':o['description'],'similarity':difflib.SequenceMatcher(None,r['description'],o['description']).ratio()})
    if r['hts']!=o['hts']:diff.append({'type':'hts_difference','aliases':r['aliases'],'independent':r['hts'],'root':o['hts']})
    if r['whole_code']!=o['whole_code']:diff.append({'type':'whole_code_difference','aliases':r['aliases']})
allnotes=[n for r in rows for n in r['aliases']]
summary={'independent_rows':len(rows),'root_rows':len(root),'independent_aliases':len(allnotes),'unique_aliases':len(set(allnotes)),'root_aliases':sum(len(r['aliases']) for r in root),'dual_alias_rows':sum(len(r['aliases'])==2 for r in rows),'whole_code':sum(r['whole_code'] for r in rows),'unique_hts':len(set(h for r in rows for h in r['hts'])),'empty_nonheader_rows':empty,'differences':diff,'page_table_row_counts':counts,'source':str(pdf)}
(R/'datasets'/'cbp_statutory_independent.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
(R/'datasets'/'cbp_statutory_audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='differences'},indent=2))
print('DIFFERENCES',len(diff))
for d in diff[:8]:print(json.dumps(d,ensure_ascii=False))
