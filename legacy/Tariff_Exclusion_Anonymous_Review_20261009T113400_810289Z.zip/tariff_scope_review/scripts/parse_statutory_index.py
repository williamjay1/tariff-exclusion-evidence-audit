import json,re,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
pages=json.loads((ROOT/'datasets'/'ustr_index_20240117.json').read_text(encoding='utf8'))
clean_pages=[]
for p in pages:
    t=re.sub(r'\s*\d+\s*\n\s*1/17/24\s*$','',p['text'])
    t=t.replace('Index of Exclusions for Possible Extension','')
    clean_pages.append(t)
text='\n'.join(clean_pages)
text=re.sub(r'Reinstatement Note\s*\(87 FR 17380\)\s*COVID Note\s*\(88 FR 31580\) Exclusion Product Description','',text)
pat=r'(?P<notes>(?:20\((?:ttt|uuu)\)\([iv]+\)\(\d+\)\s*)+)'
matches=list(re.finditer(pat,text));rows=[]
for i,m in enumerate(matches):
    desc=re.sub(r'\s+',' ',text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)]).strip()
    notes=re.findall(r'20\((?:ttt|uuu)\)\([iv]+\)\(\d+\)',m['notes'])
    hts=sorted(set(re.findall(r'\b\d{4}\.\d{2}\.\d{4}\b',desc)))
    scope=re.split(r'\(\s*(?:as )?described',desc,flags=re.I)[0].strip()
    whole=bool(re.fullmatch(r'\d{4}\.\d{2}\.\d{4}',desc))
    rows.append({'rule_id':notes[0],'aliases':notes,'description':desc,'scope':scope,'hts':hts,'whole_code':whole,
        'quantitative_marker':bool(re.search(r'\b(?:not (?:over|exceeding|more|less)|at least|less than|greater than|exceeding|between|ranging from|valued|weighing|measuring)\b',scope,re.I)),
        'number_outside_code':bool(re.search(r'\d',re.sub(r'\d{4}\.\d{2}\.\d{2,4}','',scope))),
        'negation_marker':bool(re.search(r'\b(?:other than|excluding|not|without)\b',scope,re.I)),
        'purpose_marker':bool(re.search(r'\b(?:designed|used|suitable|for use|of a kind)\b',scope,re.I)),
        'version':'USTR updated index 2024-01-17','source_url':'https://ustr.gov/sites/default/files/Updated%20Index%20of%20Exclusions%20for%20Extension%201.17.24.pdf'})
(ROOT/'datasets'/'statutory_rules.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf8')
summary={'rules':len(rows),'aliases':sum(len(r['aliases']) for r in rows),'unique_hts':len(set(h for r in rows for h in r['hts']))}
summary.update({k:sum(r[k] for r in rows) for k in ['whole_code','quantitative_marker','number_outside_code','negation_marker','purpose_marker']})
summary['unparsed_no_hts']=[r['rule_id'] for r in rows if not r['hts']]
(ROOT/'results'/'statutory_index_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(summary,indent=2))
