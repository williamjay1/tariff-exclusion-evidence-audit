"""Post hoc output-protocol audit; never modifies the main prompt or results.

Ten cases were selected for the source error analysis before Qwen completed.
Three cyclic label maps and six short greedy completions diagnose the saved run.
"""
import os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'deps'))
os.environ['HF_HOME']=str(ROOT/'cache'/'hf')
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TOKENIZERS_PARALLELISM']='false'
os.environ['TEMP']=os.environ['TMP']=str(ROOT/'temp')
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import json,time,hashlib,re
import torch,numpy as np
from transformers import AutoTokenizer,AutoModelForCausalLM

CASES=['H330938_1','H333110_1','H318593_2','H333371_1','H340899_1',
       'H332948_2','N311039_33','N307161','N312588','N306552']
GENERATE_CASES=['H330938_1','H333110_1','H318593_2','H333371_1','N307161','N306552']
DEFINITIONS={'eligible':'all description requirements are established',
             'ineligible':'at least one requirement is contradicted',
             'unknown':'missing facts prevent a decision'}
MAPS=[{'A':'eligible','B':'ineligible','C':'unknown'},
      {'A':'unknown','B':'eligible','C':'ineligible'},
      {'A':'ineligible','B':'unknown','C':'eligible'}]
ORIGINAL_MAP='A means all description requirements are established; B means at least one requirement is contradicted; C means missing facts prevent a decision.'

def main():
    torch.set_num_threads(6);torch.set_num_interop_threads(2)
    torch.manual_seed(20261007);np.random.seed(20261007)
    path=ROOT/'cache'/'models'/'qwen'
    tok=AutoTokenizer.from_pretrained(path,local_files_only=True)
    t=time.monotonic()
    model=AutoModelForCausalLM.from_pretrained(path,local_files_only=True,dtype=torch.float32,attn_implementation='sdpa')
    model.eval();load_seconds=time.monotonic()-t
    source=ROOT/'results'/'benchmark_qwen.jsonl'
    prior={x['case_id']:x for x in map(json.loads,source.read_text(encoding='utf-8').splitlines())}
    benchmark=ROOT/'datasets'/'benchmark.jsonl'
    data={x['case_id']:x for x in map(json.loads,benchmark.read_text(encoding='utf-8').splitlines())}
    variants={s:tok.encode(s,add_special_tokens=False) for s in ['A','B','C',' A',' B',' C','\nA','\nB','\nC']}
    tokens=[variants[x][0] for x in ['A','B','C']]
    assert all(len(variants[x])==1 for x in ['A','B','C'])
    space_single=all(len(variants[x])==1 for x in [' A',' B',' C'])
    records=[]
    for cid in CASES:
        saved=prior[cid];original=saved['prompt']
        assert original.count(ORIGINAL_MAP)==1
        record={'case_id':cid,'official_y':data[cid]['y'],'maps':[]}
        for k,mapping in enumerate(MAPS):
            start=time.monotonic()
            clause='; '.join(letter+' means '+DEFINITIONS[mapping[letter]] for letter in ['A','B','C'])+'.'
            prompt=original.replace(ORIGINAL_MAP,clause)
            if k==0:assert prompt==original
            inputs=tok(prompt,return_tensors='pt')
            with torch.inference_mode():
                logits=model(**inputs).logits[0,-1]
                p=torch.softmax(logits[tokens],dim=-1).numpy().astype(float).tolist()
                full=torch.softmax(logits,dim=-1)
                top=torch.topk(full,10)
            chosen=['A','B','C'][int(np.argmax(p))]
            rec={'rotation':k,'map':mapping,'prompt':prompt,'input_tokens':int(inputs['input_ids'].shape[1]),
                 'restricted_letter_scores':dict(zip(['A','B','C'],p)),
                 'restricted_semantic_scores':{mapping[l]:v for l,v in zip(['A','B','C'],p)},
                 'chosen_letter':chosen,'chosen_semantic':mapping[chosen],
                 'full_vocabulary_bare_letter_probability':{l:float(full[variants[l][0]]) for l in ['A','B','C']},
                 'full_vocabulary_bare_letter_total_mass':float(full[tokens].sum()),
                 'top10_next_tokens':[{'token_id':int(i),'decoded':tok.decode([int(i)]),'probability':float(v)} for i,v in zip(top.indices,top.values)]}
            if space_single:
                spaced=[variants[x][0] for x in [' A',' B',' C']]
                psp=torch.softmax(logits[spaced],dim=-1).numpy().astype(float).tolist()
                rec['restricted_leading_space_scores']=dict(zip(['A','B','C'],psp))
                rec['leading_space_chosen_letter']=['A','B','C'][int(np.argmax(psp))]
                rec['full_vocabulary_leading_space_letter_total_mass']=float(full[spaced].sum())
            if k==0:
                savedp=[saved['prob_eligible'],saved['prob_ineligible'],saved['prob_unknown']]
                rec['maximum_absolute_replay_score_difference']=max(abs(a-b) for a,b in zip(p,savedp))
                assert rec['maximum_absolute_replay_score_difference']<1e-5
                if cid in GENERATE_CASES:
                    with torch.inference_mode():
                        generated=model.generate(**inputs,max_new_tokens=8,do_sample=False,pad_token_id=tok.eos_token_id)
                    tail=generated[0,inputs['input_ids'].shape[1]:].tolist()
                    decoded=tok.decode(tail,skip_special_tokens=True)
                    parsed=decoded.strip()
                    rec['greedy_generation']={'max_new_tokens':8,'token_ids':tail,
                        'decoded_with_special_tokens':tok.decode(tail,skip_special_tokens=False),
                        'decoded_without_special_tokens':decoded,
                        'strict_single_letter':parsed if parsed in ['A','B','C'] else None,
                        'first_nonspace_letter':re.match(r'^\s*([ABC])\b',decoded).group(1) if re.match(r'^\s*([ABC])\b',decoded) else None,
                        'matches_restricted_strict':parsed==chosen}
            rec['seconds']=time.monotonic()-start
            record['maps'].append(rec)
            print(cid,'rotation',k,'letter',chosen,'semantic',mapping[chosen],'seconds',round(rec['seconds'],2),flush=True)
        records.append(record)
    from collections import Counter
    summary={
      'cases':len(records),'forward_calls':len(records)*3,'greedy_generation_cases':len(GENERATE_CASES),
      'selected_letter_by_rotation':{str(k):dict(Counter(r['maps'][k]['chosen_letter'] for r in records)) for k in range(3)},
      'selected_semantic_by_rotation':{str(k):dict(Counter(r['maps'][k]['chosen_semantic'] for r in records)) for k in range(3)},
      'unchanged_letter_across_all_maps':sum(len({m['chosen_letter'] for m in r['maps']})==1 for r in records),
      'unchanged_semantic_across_all_maps':sum(len({m['chosen_semantic'] for m in r['maps']})==1 for r in records),
      'greedy_strict_agreement':sum(r['maps'][0]['greedy_generation']['matches_restricted_strict'] for r in records if 'greedy_generation' in r['maps'][0]),
      'max_replay_difference':max(r['maps'][0]['maximum_absolute_replay_score_difference'] for r in records)}
    if space_single:
      summary['leading_space_letter_by_rotation']={str(k):dict(Counter(r['maps'][k]['leading_space_chosen_letter'] for r in records)) for k in range(3)}
    output={'audit_date':'2026-10-07','type':'post hoc protocol sensitivity; diagnostic purposive cases; main results untouched',
            'torch':torch.__version__,'threads':6,'dtype':'float32','device':'cpu','load_seconds':load_seconds,
            'model_provenance':json.loads((path/'provenance.json').read_text(encoding='utf-8')),
            'source_result_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'benchmark_sha256':hashlib.sha256(benchmark.read_bytes()).hexdigest(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'tokenization_variants':variants,'summary':summary,'records':records}
    out=ROOT/'results'/'qwen_protocol_audit.json'
    assert not out.exists(),'Do not overwrite audit output; review or version explicitly.'
    out.write_text(json.dumps(output,indent=2,ensure_ascii=False),encoding='utf-8')
    print('COMPLETE',json.dumps(summary),flush=True)

if __name__=='__main__':main()
