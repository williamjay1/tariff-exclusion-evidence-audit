"""Read-only, post hoc audit of the frozen numeric engine and saved stress runs."""
import sys,json,re,hashlib,time
from decimal import Decimal
from pathlib import Path
from collections import Counter,defaultdict
ROOT=Path(__file__).resolve().parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'scripts'))
from constraint_engine import verify_numeric,extract_facts

def read(name):return [json.loads(s) for s in (ROOT/name).read_text(encoding='utf-8').splitlines()]
def sha(name):return hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
def norm(s):return re.sub(r'\s+',' ',s).strip()
STATE={'pass':1,'fail':0,'unknown':-1,'not_parsed':-1}
LABEL={1:'pass',0:'fail',-1:'unknown'}
SCALE={k:Decimal(v) for k,v in {'W':'1','kW':'1000','g':'1','kg':'1000','mm':'1','cm':'10','m':'1000','V':'1','A':'1','L':'1','ml':'0.001','cm3':'0.001'}.items()}

def independent_reference(row,gold):
    """Check template facts against source-coded bounds without using engine code."""
    if 'has not been measured or reported' in row['facts']:return -1,None
    m=re.search(r' is ([0-9.]+)(?: to ([0-9.]+))? ([A-Za-z0-9]+)\.',row['facts'])
    assert m,row['case_id']
    lo=Decimal(m[1])*SCALE[m[3]];hi=Decimal(m[2] or m[1])*SCALE[m[3]]
    lower=None if gold['lower'] is None else Decimal(str(gold['lower']))*SCALE[gold['unit']]
    upper=None if gold['upper'] is None else Decimal(str(gold['upper']))*SCALE[gold['unit']]
    def ok(v):
        return (lower is None or v>lower or (v==lower and gold['lower_inclusive'])) and (upper is None or v<upper or (v==upper and gold['upper_inclusive']))
    if ok(lo) and ok(hi):return 1,m[3]
    if lower is not None and (hi<lower or hi==lower and not gold['lower_inclusive']):return 0,m[3]
    if upper is not None and (lo>upper or lo==upper and not gold['upper_inclusive']):return 0,m[3]
    return -1,m[3]

def summarize(rows,pred):
    n=len(rows);correct=sum(pred[r['case_id']]==r['y'] for r in rows)
    return {'n':n,'correct':correct,'accuracy':correct/n if n else None,
            'reference_counts':dict(Counter(r['y'] for r in rows)),
            'prediction_counts':dict(Counter(pred[r['case_id']] for r in rows)),
            'false_pass':sum(pred[r['case_id']]==1 and r['y']==0 for r in rows),
            'false_fail':sum(pred[r['case_id']]==0 and r['y']==1 for r in rows),
            'unwarranted_determinate':sum(pred[r['case_id']]!=-1 and r['y']==-1 for r in rows),
            'unnecessary_unknown':sum(pred[r['case_id']]==-1 and r['y']!=-1 for r in rows)}

def main():
    started=time.perf_counter()
    engine='scripts/constraint_engine.py';before=sha(engine)
    stress=read('datasets/stress.jsonl');gold={x['rule_id']:x for x in read('datasets/numeric_rule_gold.jsonl')}
    benchmark={x['case_id']:x for x in read('datasets/benchmark.jsonl')}
    nli={x['case_id']:x for x in read('results/stress_nli.jsonl')}
    qwen={x['case_id']:x for x in read('results/stress_qwen.jsonl')}
    assert len(stress)==480 and set(nli)==set(qwen)=={x['case_id'] for x in stress}
    traces=[];errors=[];predictions={'NLI':{},'Qwen':{},'Numeric':{}}
    genuine=[];identity=[];scale_changing=[];alias_only=[]
    independent_mismatches=[];groups=defaultdict(list)
    for r in stress:
        cid=r['case_id'];v=verify_numeric(r['facts'],r['rule_text']);p=STATE[v['state']]
        traces.append({'case_id':cid,**v})
        for name,saved in [('NLI',nli),('Qwen',qwen)]:predictions[name][cid]=saved[cid]['selective_prediction']
        predictions['Numeric'][cid]=p
        expected,factunit=independent_reference(r,gold[r['rule_id']])
        if expected!=r['y']:independent_mismatches.append({'case_id':cid,'reference':r['y'],'independent':expected})
        if r['scenario'].startswith('converted_'):
            original=gold[r['rule_id']]['unit']
            if factunit==original:identity.append(r)
            else:
                genuine.append(r)
                (scale_changing if SCALE[factunit]!=SCALE[original] else alias_only).append(r)
        groups[(r['rule_id'],r['facts'],r['y'])].append(r)
        if p!=r['y']:
            reason='Unsupported postposed upper bound: or less' if r['rule_id']=='20(ttt)(i)(87)' else 'Unsupported upper comparator: not longer than'
            kind='unnecessary_unknown' if p==-1 else ('false_pass' if p==1 and r['y']==0 else 'false_fail' if p==0 and r['y']==1 else 'unwarranted_determinate')
            errors.append({**r,'prediction':p,'error_type':kind,'syntax_reason':reason,'source_page':gold[r['rule_id']]['source_page'],'trace':v})
    unique=[v[0] for v in groups.values()]
    assert len(unique)==443 and len(genuine)==112 and len(identity)==8
    duplicate_inconsistency=[]
    for group in groups.values():
        for model,pred in predictions.items():
            if len({pred[r['case_id']] for r in group})>1:duplicate_inconsistency.append({'model':model,'case_ids':[r['case_id'] for r in group]})
    sets={'all_480':stress,'deduplicated_443':unique,'actual_unit_changes_112':genuine,'identity_transformations_8':identity,'scale_changes':scale_changing,'equivalent_unit_alias_changes':alias_only}
    metrics={name:{model:summarize(rows,p) for model,p in predictions.items()} for name,rows in sets.items()}
    h=benchmark['H317391_1'];hv=verify_numeric(h['facts'],h['rule_text']);hf=extract_facts(h['facts'])
    hquote='All subject merchandise described as traditional vacuum cleaners are accurately described under U.S. Notes 20(nn)(13), while a few subject traditional vacuum cleaner models are also accurately described under U.S. Notes 20(nn)(14). Thus, all subject vacuum cleaner products fall under the scope of the exclusions under subheading 9903.88.35, HTSUS.'
    sources={x['rulingNumber'].upper():x for x in read('datasets/cbp_rulings_derived.jsonl')}
    ht=norm(sources['H317391']['text']);assert hquote in ht
    offenders=[v for v in hf if v['quote']=='72600W'];assert len(offenders)==1 and hv['state']=='fail'
    offender=offenders[0];start,end=offender['span']
    hdetails={'case_id':h['case_id'],'official_y':h['y'],'facts':h['facts'],'rule_text':h['rule_text'],'numeric_trace':hv,'extracted_facts':hf,
       'offending_match':offender,'preceding_two_characters':h['facts'][start-2:start],
       'full_identifier':h['facts'][start-2:end],'reference_quote':hquote,'reference_offset':ht.index(hquote),'official_url':'https://rulings.cbp.gov/ruling/H317391',
       'cause':'extract_facts point-value regex lacks a left alphanumeric boundary. Its terminal negative lookahead prevents a following letter but does not prevent starting inside UH72600W. The match is 72600W, interpreted as 72600 W. The genuine bounded statements are deliberately not treated as point values. The spurious failure takes precedence over the unknown volume predicate.',
       'impact':'False determinate refusal on an officially eligible real product group; synthetic predicate accuracy does not establish source grounding.'}
    comparison=None
    existing=ROOT/'results/stress_numeric_traces.jsonl'
    if existing.exists():
        old={r['case_id']:r for r in read('results/stress_numeric_traces.jsonl')}
        comparison={'available':len(old),'state_disagreements':[r['case_id'] for r in traces if r['case_id'] not in old or r['state']!=old[r['case_id']]['state']]}
    engine_lines=(ROOT/engine).read_text(encoding='utf-8').splitlines()
    locators={}
    for title,needle in [('point_value_regex',"pat=rf'(?P<dollar>"),('postposed_lower_only',"pat=rf'(?P<v>{NUM})"),('failure_precedence',"elif 'fail' in states"),('unknown_unparsed_guard',"elif 'unknown' in states or unparsed")]:
        matches=[i for i,s in enumerate(engine_lines,1) if needle in s];locators[title]=matches
    assert sha(engine)==before
    out={'audit_date':'2026-10-07','post_hoc':True,'engine_modified':False,'engine_sha256':before,'engine_line_locators':locators,
        'independent_reference_mismatches':independent_mismatches,'same_input_prediction_inconsistency':duplicate_inconsistency,
        'existing_numeric_trace_comparison':comparison,'metrics':metrics,'numeric_errors':errors,'numeric_traces':traces,'H317391_1':hdetails,
        'duplicates':[{'case_ids':[r['case_id'] for r in group],'rule_id':group[0]['rule_id'],'facts':group[0]['facts'],'y':group[0]['y']} for group in groups.values() if len(group)>1],
        'unit_change_ids':[r['case_id'] for r in genuine],'identity_ids':[r['case_id'] for r in identity],
        'seconds':time.perf_counter()-started,'source_hashes':{f:sha(f) for f in ['datasets/stress.jsonl','datasets/numeric_rule_gold.jsonl','datasets/benchmark.jsonl','results/stress_nli.jsonl','results/stress_qwen.jsonl']}}
    (ROOT/'results/grounding_audit.json').write_text(json.dumps(out,indent=2,ensure_ascii=False,default=str),encoding='utf-8')
    L=['# Frozen-engine grounding and numerical stress audit','',
       'Post hoc diagnostic, 2026-10-07. The constraint engine, benchmark inputs and primary model outputs were not changed. The numeric engine was independently rerun on all 480 synthetic stress cases. Saved NLI and Qwen outputs were complete at 480 cases each. All neural comparisons below use their saved three-way selective prediction, because unknown is a reference state in this task. No new neural training or inference was needed.', '',
       '## Real-source false refusal: H317391_1','',
       'CBP grants the exclusion to the traditional dry vacuum group. The frozen numeric engine instead returns fail: it treats the substring `72600W` inside model identifier `UH72600W` as a 72,600-watt physical measurement and compares it against the 1,500-watt ceiling.', '',
       f"The offending match occupies fact-string offsets [{start}, {end}); the preceding characters are `UH`. The point-value regex at engine line {locators['point_value_regex'][0]} has no left alphanumeric boundary. Its trailing `(?![A-Za-z])` checks only what follows the match, and therefore does not exclude digits inside model identifiers. This is an observed lexical-grounding defect, not a unit-conversion or legal-interpretation disagreement.", '',
       'The actual statement that motor power does not exceed 1,500 W is a bound and is deliberately omitted by the point-value extractor. The volume statement is also a bound and yields no point candidate. The fabricated power violation therefore takes precedence over an unknown volume predicate. Returning a deterministic refusal is unsafe in this real case even though the engine performs well on clean templated measurements.', '',
       'Exact official quote:', '', '> '+hquote,'','Source: https://rulings.cbp.gov/ruling/H317391', '',
       'The engine remains frozen to preserve the primary comparison. A future repair would need explicit rejection or classification of identifier spans and regression tests on genuine measurements as well as model names. No repaired-performance claim is made. The optional 26 toy identifier examples were not added: the actual observed failure and exact code path already identify the defect, and extra toys would not estimate its real frequency.', '',
       '## Stress errors: 14 unnecessary unknowns, no wrong determinate decision','',
       f"Independent replay gives {metrics['all_480']['Numeric']['correct']}/480 correct three-state outputs. The 14 discrepancies are all unknown on determinate cases: nine required pass and five required fail. There are zero false passes, zero false fails and zero unwarranted determinate answers on the 120 truly unknown inputs. Thus these discrepancies are coverage failures, not incorrect binary certainty. This statement applies only to the synthetic single-predicate stress set; H317391_1 shows why it cannot be generalized to real-source safety.", '',
       'Two unsupported constructions explain the errors. The postposed upper bound `6.5 mm or less in thickness` is left unparsed: the grammar implements `or more`, but not `or less`. This creates six discrepancies under rule 20(ttt)(i)(87). The phrase `not longer than 16 m` is outside the recognized comparator vocabulary: the lower bound is parsed, but the upper quantity remains unparsed. This creates four discrepancies each under rules 20(ttt)(iii)(142) and 20(ttt)(iii)(143). Inputs below a parsed lower bound can still correctly fail; inputs satisfying that lower bound are referred because the upper clause is unresolved.', '',
       '| Case | Rule | Scenario | Reference | Actual | Unsupported source syntax |',
       '|---|---|---|---|---|---|']
    for e in errors:L.append(f"| {e['case_id']} | {e['rule_id']} | {e['scenario']} | {LABEL[e['y']]} | {LABEL[e['prediction']]} | {'or less' if e['rule_id']=='20(ttt)(i)(87)' else 'not longer than'} |")
    L+=['','The clauses are source-coded in the numeric gold file: thickness appears on source page 5 and both extension-cord length clauses on source page 10. The JSON audit retains each full synthetic fact, exact rule clause and complete execution trace. The source-coded bounds were created separately from the evaluated parser; this audit also checked all 480 template labels with a separate Decimal implementation against those bounds. Reference-label disagreements: '+str(len(independent_mismatches))+'.', '',
       '## Duplicate and unit-change sensitivity','',
       'Exact deduplication uses (rule_id, facts, y), retaining the first occurrence. It removes 37 repeated rows, leaving 443 distinct rule–fact–outcome triples. The same-input predictions are consistent within all duplicate groups. Deduplication addresses row repetition, not the correlation among cases sharing one of the 60 rules. One repeated thickness failure is removed, leaving 13 numeric errors in the deduplicated set.', '',
       '| Set | n | NLI correct | Qwen correct | Numeric correct |',
       '|---|---:|---:|---:|---:|']
    for key,title in [('all_480','All synthetic cases'),('deduplicated_443','Exact deduplication'),('actual_unit_changes_112','Actual unit representation changes'),('identity_transformations_8','Identity transformations'),('scale_changes','Scale-changing conversions'),('equivalent_unit_alias_changes','Equivalent-unit alias changes')]:
        m=metrics[key];L.append(f"| {title} | {m['Numeric']['n']} | {m['NLI']['correct']} | {m['Qwen']['correct']} | {m['Numeric']['correct']} |")
    L+=['','The NLI model returns unknown on 474/480 cases, and Qwen returns pass on all 480. Always predicting unknown would score 120/480 and always predicting pass scores 161/480. Consequently, the neural scores primarily expose failure to discriminate under these fixed zero-shot task formulations. In particular, NLI zero correct out of 112 changed-unit cases mostly means abstention (111 cases), not 112 incorrect numerical calculations. The stress comparison should not be generalized into a claim that all neural models cannot perform unit conversion.', '',
       'The generator labels 120 cases converted_inside or converted_outside. Eight retain V or A unchanged and are identity transformations, so they must not be counted as conversion evidence. The other 112 change the unit representation; the table further separates a numerical scale change from an equivalent-unit alias change, such as cubic centimetres to millilitres. These are controlled synthetic perturbations with all other requirements stipulated as satisfied, not new observed products.', '',
       'These results support bounded execution of the implemented comparison grammar on clean scalar inputs. They do not establish full statutory coverage, extraction reliability in free text, or reliable complete eligibility decisions. The sharp contrast between the identifier failure and the clean-template results is itself a useful test-design lesson: arithmetic checks and source grounding require separate validation.', '',
       '## Reproducibility','',f'Frozen engine SHA-256: {before}',f'Independent numeric replay elapsed time including file reads and report preparation: {out["seconds"]:.3f} seconds.',
       'Audit code: scripts/audit_grounding.py. Machine-readable output: results/grounding_audit.json. The report and JSON are diagnostic outputs; no principal results were replaced.']
    if comparison is not None:L.append(f"Agreement with saved primary numeric traces: {len(comparison['state_disagreements'])} state disagreements across {comparison['available']} available saved cases.")
    (ROOT/'research/grounding_audit.md').write_text('\n'.join(L)+'\n',encoding='utf-8')
    print(json.dumps({'metrics':metrics,'errors':len(errors),'independent_mismatches':independent_mismatches,'seconds':out['seconds']},indent=2))

if __name__=='__main__':main()
