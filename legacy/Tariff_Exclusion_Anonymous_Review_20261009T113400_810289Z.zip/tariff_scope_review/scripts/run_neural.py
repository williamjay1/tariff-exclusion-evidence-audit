"""Frozen local inference. Models receive only facts and literal candidate scope."""
import os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
os.environ['HF_HOME']=str(ROOT/'cache'/'hf')
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TOKENIZERS_PARALLELISM']='false'
os.environ['TEMP']=os.environ['TMP']=str(ROOT/'temp')
import argparse,json,re,time,hashlib
import torch,numpy as np
from transformers import AutoTokenizer,AutoModelForSequenceClassification,AutoModelForCausalLM

def scope(rule):return re.split(r'\(\s*(?:as )?described',rule,flags=re.I)[0].strip()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--model',choices=['nli','qwen','qwen4'],required=True);ap.add_argument('--input',default='benchmark.jsonl');ap.add_argument('--output');ap.add_argument('--limit',type=int);args=ap.parse_args()
    # Only the not-yet-started larger-model stress run uses an outcome-blind
    # batching preflight. Observed cases and earlier model paths stay single.
    if args.model=='qwen4' and args.input=='stress.jsonl' and args.limit is None:
        from run_qwen4_stress_batched import main as stress_main
        return stress_main(args)
    torch.set_num_threads(6);torch.set_num_interop_threads(2)
    torch.manual_seed(20261007);np.random.seed(20261007)
    path=ROOT/'cache'/'models'/args.model
    tok=AutoTokenizer.from_pretrained(path,local_files_only=True)
    inference_dtype='bfloat16' if args.model=='qwen4' else 'float32'
    t=time.monotonic()
    if args.model=='nli':model=AutoModelForSequenceClassification.from_pretrained(path,local_files_only=True)
    else:model=AutoModelForCausalLM.from_pretrained(path,local_files_only=True,dtype=torch.bfloat16 if args.model=='qwen4' else torch.float32,attn_implementation='sdpa')
    model.eval();load_sec=time.monotonic()-t
    rows=list(map(json.loads,(ROOT/'datasets'/args.input).read_text(encoding='utf8').splitlines()))
    if args.limit:rows=rows[:args.limit]
    out=ROOT/'results'/(args.output or f'{Path(args.input).stem}_{args.model}.jsonl')
    done=set()
    fingerprint={'input_sha256':hashlib.sha256((ROOT/'datasets'/args.input).read_bytes()).hexdigest(),
                 'model':args.model,'model_revision':json.loads((path/'provenance.json').read_text(encoding='utf8'))['revision'],
                 'prompt_version':'scope-v1','dtype':inference_dtype,'device':'cpu','transformers_context':512 if args.model=='nli' else 8192}
    runpath=out.with_suffix('.run.json')
    if out.exists():
        if runpath.exists():assert json.loads(runpath.read_text(encoding='utf8'))==fingerprint,'Run fingerprint changed; use a new output file.'
        else:
            # Completed preflight-era runs used exactly the same v1 prompts.
            oldmeta=json.loads(out.with_suffix('.meta.json').read_text(encoding='utf8'))
            assert oldmeta['input_sha256']==fingerprint['input_sha256'] and oldmeta['model']==args.model
            assert oldmeta.get('model_provenance',{}).get('revision')==fingerprint['model_revision'], 'Pinned model revision changed; use a new output file.'
            prior=list(map(json.loads,out.read_text(encoding='utf8').splitlines()))
            byid={r['case_id']:r for r in rows}
            if args.model=='nli':
                for old in prior:
                    r=byid[old['case_id']]
                    assert old['prompt']=={'premise':r['facts'],'hypothesis':'The product satisfies this description: '+scope(r['rule_text'])}
            else:raise ValueError('Unfingerprinted generative outputs require a new output file.')
        done={r['case_id'] for r in map(json.loads,out.read_text(encoding='utf8').splitlines())}
    runpath.write_text(json.dumps(fingerprint,indent=2),encoding='utf8')
    for i,r in enumerate(rows):
        if r['case_id'] in done:continue
        facts=r['facts'];rule=scope(r['rule_text']);start=time.monotonic()
        if args.model=='nli':
            # IDs, reference decisions, dates and analysis are never passed.
            hyp='The product satisfies this description: '+rule
            nt=len(tok(facts,hyp)['input_ids'])
            inputs=tok(facts,hyp,return_tensors='pt',max_length=512,truncation='only_first')
            with torch.inference_mode():p=torch.softmax(model(**inputs).logits,dim=-1)[0].numpy()
            # Model card order: contradiction, entailment, neutral.
            prob=[float(p[1]),float(p[0]),float(p[2])]
            prompt={'premise':facts,'hypothesis':hyp}
        else:
            user=("Evaluate only whether the stated product facts satisfy the supplied exclusion description. "
                  "This is a historical product-scope task. Origin, timing and any separately checked tariff code are held fixed. "
                  "Use only the stated facts. A means all description requirements are established; "
                  "B means at least one requirement is contradicted; C means missing facts prevent a decision. "
                  "Answer with exactly one letter: A, B or C.\n\nPRODUCT FACTS:\n"+facts+"\n\nEXCLUSION DESCRIPTION:\n"+rule)
            prompt=tok.apply_chat_template([{'role':'user','content':user}],tokenize=False,add_generation_prompt=True,enable_thinking=False)
            ids=tok(prompt,return_tensors='pt');nt=ids['input_ids'].shape[1]
            # Selected descriptions fit the model context. No silent truncation.
            if nt>8192:raise ValueError(f'Context too large: {r["case_id"]} {nt}')
            letter_ids=[tok.encode(x,add_special_tokens=False) for x in ['A','B','C']]
            assert all(len(x)==1 for x in letter_ids)
            with torch.inference_mode():
                scores=model(**ids).logits[0,-1,[x[0] for x in letter_ids]]
                # Qwen4 weights/logits are BF16 for the recorded RAM constraint;
                # promote its three scores for stable softmax and NumPy support.
                if args.model=='qwen4':prob=torch.softmax(scores.float(),dim=-1).numpy().astype(float).tolist()
                else:prob=torch.softmax(scores,dim=-1).numpy().astype(float).tolist()
        elapsed=time.monotonic()-start
        pred=int(prob[0]>=prob[1])
        sel=[1,0,-1][int(np.argmax(prob))]
        record={'case_id':r['case_id'],'model':args.model,'prob_eligible':prob[0],'prob_ineligible':prob[1],'prob_unknown':prob[2],
                'binary_prediction':pred,'selective_prediction':sel,'input_tokens':nt,'truncated':bool(args.model=='nli' and nt>512),
                'seconds':elapsed,'prompt':prompt}
        with out.open('a',encoding='utf8') as f:f.write(json.dumps(record,ensure_ascii=False)+'\n')
        if i%10==0:print(args.model,i+1,'/',len(rows),'seconds',round(elapsed,3),flush=True)
    meta={'torch':torch.__version__,'model':args.model,'load_seconds':load_sec,'threads':6,'dtype':inference_dtype,'device':'cpu',
          'input_sha256':hashlib.sha256((ROOT/'datasets'/args.input).read_bytes()).hexdigest(),
          'model_provenance':json.loads((path/'provenance.json').read_text(encoding='utf8'))}
    out.with_suffix('.meta.json').write_text(json.dumps(meta,indent=2),encoding='utf8')
    print('COMPLETE',out,flush=True)
if __name__=='__main__':main()
