"""Freeze source-grounded model inputs, labels and grouped evaluation splits."""
from pathlib import Path
import json,re,hashlib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import StratifiedGroupKFold
ROOT=Path(__file__).resolve().parents[1]
def norm(t):return re.sub(r'\s+',' ',t).strip()
def canonical(t):
    t=re.split(r'\(\s*(?:as )?described',t,flags=re.I)[0]
    return re.sub(r'[^a-z0-9 ]',' ',t.lower())
rows=[];audit=[]
for fn in ['hq_reference','ny_reference']:
    for r in map(json.loads,(ROOT/'datasets'/f'{fn}.jsonl').read_text(encoding='utf8').splitlines()):
        reason=None
        if r['reference_disposition'] not in ['eligible','ineligible']:reason='no_binary_reference'
        elif r['scope_type']!='product_specific':reason='outside_product_description_task'
        elif not r.get('include_in_primary',True):reason='documented_source_conflict'
        elif not r.get('benchmark_candidate',True) and r['case_id']!='H314080_1':reason='missing_full_candidate_rule'
        if reason:
            audit.append({'case_id':r['case_id'],'reason':reason});continue
        facts=r['facts'] if isinstance(r['facts'],str) else '\n'.join(r['facts'])
        facts=norm(facts)
        rule=norm(r['rule_text'])
        product_hts=r.get('product_hts',[])
        if isinstance(product_hts,str):product_hts=[product_hts]
        # Some annotated provenance schemas contain dictionaries.
        product_hts=[x if isinstance(x,str) else x.get('code','') for x in product_hts]
        locator=re.search(r'\(\s*(?:as )?described.*',rule,re.I)
        rule_hts=r.get('rule_hts',re.findall(r'\b\d{4}\.\d{2}\.\d{2,4}\b',locator[0] if locator else ''))
        if isinstance(rule_hts,str):rule_hts=[rule_hts]
        if not r.get('code_baseline_eligible',True):product_hts=[]
        product_hts=[x for x in product_hts if x and not x.startswith(('99','98'))]
        pairs=[(a.replace('.',''),b.replace('.','')) for a in product_hts for b in rule_hts]
        code_match=None if not pairs else int(any(a[:min(len(a),len(b))]==b[:min(len(a),len(b))] for a,b in pairs))
        exact_code=bool(pairs and any(len(a)==len(b)==10 and a==b for a,b in pairs))
        inp={'case_id':r['case_id'],'facts':facts,'rule_text':rule,'product_hts':product_hts,
             'rule_hts':rule_hts,'code_match':code_match,'exact_code_match':exact_code,
             'date':r['date'],'y':int(r['reference_disposition']=='eligible'),'rulingNumber':r['rulingNumber'],
             'group_hint':r['group_hint'],'source':fn[:2].upper(),'annotation_note':r['annotation_note']}
        rows.append(inp)
n=len(rows);parent=list(range(n))
def find(i):
    while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
    return i
def union(i,j):parent[find(j)]=find(i)
for i in range(n):
    for j in range(i):
        if rows[i]['rulingNumber']==rows[j]['rulingNumber'] or rows[i]['group_hint']==rows[j]['group_hint']:union(i,j)
# Shared wording and near-duplicate facts cannot straddle folds.
for key,threshold in [('rule_text',.87),('facts',.90)]:
    texts=[canonical(r[key]) if key=='rule_text' else r[key] for r in rows]
    mat=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5)).fit_transform(texts)
    sim=(mat@mat.T).toarray()
    for i in range(n):
        for j in range(i):
            if sim[i,j]>=threshold:union(i,j)
groups=[find(i) for i in range(n)]
for i,r in enumerate(rows):r['group']=f'G{groups[i]:03d}'
y=np.array([r['y'] for r in rows]);g=np.array([r['group'] for r in rows])
cv=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=20261007)
for fold,(_,test) in enumerate(cv.split(np.zeros(n),y,g)):
    for i in test:rows[i]['fold']=fold
p=ROOT/'datasets'/'benchmark.jsonl';p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf8')
summary={'n_pairs':n,'n_rulings':len(set(r['rulingNumber'] for r in rows)),'n_groups':len(set(g)),'positive':int(y.sum()),'negative':int(n-y.sum()),
 'code_match':sum(r['code_match']==1 for r in rows),'code_mismatch':sum(r['code_match']==0 for r in rows),'code_unknown':sum(r['code_match'] is None for r in rows),'exact10_match':sum(r['exact_code_match'] for r in rows),
 'excluded':audit,'folds':[{k:sum(r['fold']==k for r in rows)} for k in range(5)],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'explicit_inclusion':'H314080 retained despite evidence incompleteness; missing input facts do not justify removing a difficult reference decision.'}
(ROOT/'results'/'benchmark_manifest.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(summary,indent=2))
