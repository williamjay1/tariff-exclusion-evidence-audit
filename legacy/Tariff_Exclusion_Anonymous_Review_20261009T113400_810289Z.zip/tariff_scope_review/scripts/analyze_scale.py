"""Post hoc stronger-model sensitivity; primary analysis is never overwritten."""
from pathlib import Path
import json
import numpy as np
from sklearn.metrics import confusion_matrix
R=Path(__file__).resolve().parents[1]
def read(p):return [json.loads(x) for x in p.read_text(encoding='utf8').splitlines()]
rows=read(R/'datasets/benchmark.jsonl');rr={r['case_id']:r for r in read(R/'results/benchmark_qwen4.jsonl')}
assert set(rr)=={r['case_id'] for r in rows}
rec=[rr[r['case_id']] for r in rows]
y=np.array([r['y'] for r in rows]);g=np.array([r['group'] for r in rows]);code=np.array([r['code_match'] if r['code_match'] is not None else -1 for r in rows])
trace={r['case_id']:r for r in read(R/'results/numeric_traces.jsonl')};state=np.array([trace[r['case_id']]['state'] for r in rows])
b=np.array([r['binary_prediction'] for r in rec]);s=np.array([r['selective_prediction'] for r in rec]);b[code==0]=0;s[code==0]=0
bg=b.copy();sg=s.copy();bg[(state=='fail')&(code!=0)]=0;sg[(state=='fail')&(code!=0)]=0;sg[(state=='unknown')&(code!=0)]=-1
models={'Qwen3 4B Instruct':(b,s),'Qwen3 4B Instruct + numeric guard':(bg,sg)}
def met(y,p):
 tp=int(sum((y==1)&(p==1)));fn=int(sum((y==1)&(p==0)));fp=int(sum((y==0)&(p==1)));tn=int(sum((y==0)&(p==0)))
 return {'n':len(y),'tp':tp,'fn':fn,'fp':fp,'tn':tn,'accuracy':float(np.mean(y==p)),
  'balanced_accuracy':float((tp/(tp+fn)+tn/(tn+fp))/2) if tp+fn and tn+fp else None,
  'false_exemption_rate':fp/(fp+tn) if fp+tn else None,'eligible_recall':tp/(tp+fn) if tp+fn else None}
def boot(y,p,g):
 rng=np.random.default_rng(20261007);ug=np.unique(g);ixs=[np.where(g==v)[0] for v in ug];vals=[]
 for _ in range(2000):
  ix=np.concatenate([ixs[j] for j in rng.integers(len(ug),size=len(ug))]);m=met(y[ix],p[ix])
  if m['balanced_accuracy'] is not None:vals.append([m[k] for k in ['balanced_accuracy','false_exemption_rate','eligible_recall']])
 a=np.array(vals)
 return {k:np.quantile(a[:,j],[.025,.975]).tolist() for j,k in enumerate(['balanced_accuracy','false_exemption_rate','eligible_recall'])}
out={'analysis_status':'Post hoc stronger-model sensitivity after frozen primary evaluation; same user prompt and scoring. Model version, post-training, native template, and BF16 differ, not a pure parameter-scale experiment.','observed':{}}
masks={'same_code':code==1,'all_code_known':code>=0,'exact_ten_digit':np.array([r['exact_code_match'] for r in rows])}
for sub,mask in masks.items():
 dd={}
 for k,(p,q) in models.items():
  yy=y[mask];pp=p[mask];ss=q[mask];keep=ss!=-1;m=met(yy,pp);m['cluster_bootstrap_95ci']=boot(yy,pp,g[mask])
  m['selective']={'answered':int(keep.sum()),'referrals':int((~keep).sum()),'coverage':float(keep.mean()),'errors':int(sum((ss!=yy)&keep)),
    'error_rate_answered':float(np.mean(ss[keep]!=yy[keep])) if keep.any() else None,'false_exemptions':int(sum((ss==1)&(yy==0))),'false_denials':int(sum((ss==0)&(yy==1))),
    'eligible_coverage':float(np.mean(keep[yy==1])),'ineligible_coverage':float(np.mean(keep[yy==0]))}
  dd[k]=m
 out['observed'][sub]={'n':int(mask.sum()),'groups':len(set(g[mask])),'positive':int(y[mask].sum()),'negative':int(sum(y[mask]==0)),'models':dd}
mask=masks['same_code'];out['cost_sensitivity_same_code']={}
for grant in [1,5,10,25]:
 out['cost_sensitivity_same_code'][str(grant)]={}
 for referral in [.1,.25,.5]:
  out['cost_sensitivity_same_code'][str(grant)][str(referral)]={k:float((grant*sum((q[mask]==1)&(y[mask]==0))+sum((q[mask]==0)&(y[mask]==1))+referral*sum(q[mask]==-1))/mask.sum()) for k,(p,q) in models.items()}
stress=read(R/'datasets/stress.jsonl');pred={r['case_id']:r for r in read(R/'results/stress_qwen4.jsonl')};assert set(pred)=={r['case_id'] for r in stress}
sy=np.array([r['y'] for r in stress]);p=np.array([pred[r['case_id']]['selective_prediction'] for r in stress]);gg=np.array([r['group'] for r in stress]);ug=np.unique(gg);rng=np.random.default_rng(20261007);vals=[]
for _ in range(2000):
 ix=np.concatenate([np.where(gg==v)[0] for v in rng.choice(ug,size=len(ug),replace=True)]);vals.append(float(np.mean(sy[ix]==p[ix])))
seen=set();ix=[]
for i,r in enumerate(stress):
 key=(r['rule_id'],r['facts'],r['y'])
 if key not in seen:seen.add(key);ix.append(i)
out['stress']={'Qwen3 4B Instruct':{'n':len(sy),'correct':int(sum(p==sy)),'accuracy':float(np.mean(p==sy)),'rule_bootstrap_95ci':np.quantile(vals,[.025,.975]).tolist(),
  'confusion_labels':[-1,0,1],'confusion_matrix':confusion_matrix(sy,p,labels=[-1,0,1]).tolist(),
  'deduplicated':{'n':len(ix),'correct':int(sum(p[ix]==sy[ix])),'accuracy':float(np.mean(p[ix]==sy[ix]))},
  'by_scenario':{s:{'n':sum(r['scenario']==s for r in stress),'correct':int(sum((p==sy)&np.array([r['scenario']==s for r in stress])))} for s in sorted(set(r['scenario'] for r in stress))}}}
out['latency']={'Qwen3 4B Instruct':{'seconds_total':sum(r['seconds'] for r in rec),'median_seconds':float(np.median([r['seconds'] for r in rec])),'truncated_n':sum(r['truncated'] for r in rec),'input_tokens_median':float(np.median([r['input_tokens'] for r in rec]))}}
out['prediction_distribution']={str(k):int(sum(np.array([r['selective_prediction'] for r in rec])==k)) for k in [-1,0,1]}
out['observed_source']={}
for source in ['HQ','NY']:
 mask=(code==1)&np.array([r['source']==source for r in rows]);out['observed_source'][source]={k:met(y[mask],p[mask]) for k,(p,q) in models.items()}
(R/'results/scale_analysis.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps({'observed':out['observed']['same_code'],'stress':out['stress'],'latency':out['latency']},indent=2))
