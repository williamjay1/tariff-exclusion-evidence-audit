"""Independent structural/reference QA, without loading model predictions."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import hashlib
import json
import re
import sys
import numpy as np
from sklearn.model_selection import StratifiedGroupKFold

ROOT = Path(__file__).resolve().parents[1]
gold_path = ROOT / 'datasets' / 'numeric_rule_gold.jsonl'
assert hashlib.sha256(gold_path.read_bytes()).hexdigest() == '55c9dd4f3636a2c9adfc74efcd87bfd507933149de06fcc32cb10115113af804'
gold = {r['rule_id']: r for r in map(json.loads, gold_path.read_text(encoding='utf8').splitlines())}
stress = list(map(json.loads, (ROOT / 'datasets' / 'stress.jsonl').read_text(encoding='utf8').splitlines()))
scale = { 'W': ('power', Fraction(1)), 'kW': ('power', Fraction(1000)),
          'g': ('mass', Fraction(1)), 'kg': ('mass', Fraction(1000)),
          'mm': ('length', Fraction(1)), 'cm': ('length', Fraction(10)), 'm': ('length', Fraction(1000)),
          'V': ('voltage', Fraction(1)), 'A': ('current', Fraction(1)),
          'L': ('volume', Fraction(1000)), 'ml': ('volume', Fraction(1)), 'cm3': ('volume', Fraction(1)) }

def allowed(g, value):
    lower = None if g['lower'] is None else Fraction(str(g['lower']))
    upper = None if g['upper'] is None else Fraction(str(g['upper']))
    below = lower is not None and (value < lower or (value == lower and not g['lower_inclusive']))
    above = upper is not None and (value > upper or (value == upper and not g['upper_inclusive']))
    return not (below or above)

counts = Counter()
genuine_conversion = 0
identity_conversion = 0
for row in stress:
    g = gold[row['rule_id']]
    assert row['rule_text'] == g['clause'] and row['group'] == row['rule_id'] and row['synthetic']
    counts[row['scenario']] += 1
    if row['scenario'] == 'missing':
        assert row['y'] == -1 and 'not been measured or reported' in row['facts']
        continue
    m = re.search(r' is ([0-9.]+)(?: to ([0-9.]+))? ([A-Za-z0-9]+)\.', row['facts'])
    assert m, row['case_id']
    a, b, unit = m.groups()
    assert scale[unit][0] == scale[g['unit']][0]
    multiplier = scale[unit][1] / scale[g['unit']][1]
    a = Fraction(a) * multiplier
    if b:
        b = Fraction(b) * multiplier
        assert a < b and allowed(g, a) != allowed(g, b) and row['y'] == -1, row['case_id']
    else:
        assert int(allowed(g, a)) == row['y'], row['case_id']
    if row['scenario'].startswith('converted'):
        genuine_conversion += unit != g['unit']
        identity_conversion += unit == g['unit']
assert len(stress) == 480 and len({r['case_id'] for r in stress}) == 480
assert len(gold) == 60 and len({r['group'] for r in stress}) == 60
assert set(counts.values()) == {60}

rows = list(map(json.loads, (ROOT / 'datasets' / 'benchmark.jsonl').read_text(encoding='utf8').splitlines()))
y = np.array([r['y'] for r in rows]); groups = np.array([r['group'] for r in rows]); folds = np.array([r['fold'] for r in rows])
fold_audit = []
for fold in range(5):
    train = np.where(folds != fold)[0]; test = np.where(folds == fold)[0]
    assert not set(groups[train]) & set(groups[test])
    inner_audit = []
    for tr, te in StratifiedGroupKFold(3, shuffle=True, random_state=20261007+fold).split(np.zeros(len(train)), y[train], groups[train]):
        assert not set(groups[train][tr]) & set(groups[train][te])
        assert set(y[train][tr]) == set(y[train][te]) == {0,1}
        inner_audit.append({'train_n': len(tr), 'validation_n': len(te), 'train_classes': np.bincount(y[train][tr], minlength=2).tolist(), 'validation_classes': np.bincount(y[train][te], minlength=2).tolist()})
    fold_audit.append({'fold': fold, 'test_n': len(test), 'test_groups': len(set(groups[test])), 'test_classes': np.bincount(y[test], minlength=2).tolist(), 'inner': inner_audit})
test = np.array([i for i,r in enumerate(rows) if r['date'] >= '2023-01-01'])
test_groups = set(groups[test])
train = np.array([i for i,r in enumerate(rows) if r['date'] < '2023-01-01' and groups[i] not in test_groups])
assert not set(groups[train]) & set(groups[test])
summary = {'stress_rows': len(stress), 'stress_rules': len(gold), 'reference_label_mismatches': 0,
           'scenarios': dict(counts), 'genuine_converted_rows': genuine_conversion, 'identity_converted_rows': identity_conversion,
           'frozen_gold_sha256_verified': True, 'outer_inner_folds': fold_audit,
           'temporal_support': {'train_n': len(train), 'test_n': len(test), 'train_classes': np.bincount(y[train], minlength=2).tolist(), 'test_classes': np.bincount(y[test], minlength=2).tolist()},
           'model_outputs_read': False, 'parser_run_on_numeric_gold': False}
(ROOT / 'research' / 'cbp_preflight_checks.json').write_text(json.dumps(summary, indent=2), encoding='utf8')
print(json.dumps(summary, indent=2))
