"""Post hoc single-case intervention; no change to the frozen engine or benchmark."""
from pathlib import Path
import json,hashlib
from constraint_engine import verify_numeric
R=Path(__file__).resolve().parents[1]
rows=[json.loads(x) for x in (R/'datasets/benchmark.jsonl').read_text(encoding='utf8').splitlines()]
r=next(x for x in rows if x['case_id']=='H317391_1')
assert 'UH72600W' in r['facts']
variants={'original':r['facts'],'identifier_masked':r['facts'].replace('UH72600W','[MODEL IDENTIFIER]'),'identifier_explicitly_labeled':r['facts'].replace('UH72600W','model identifier UH72600W (not a power measurement)')}
out={'status':'Post hoc diagnostic intervention on one selected error, not an additional independent case or engine repair.','case_id':r['case_id'],'engine_sha256':hashlib.sha256((R/'scripts/constraint_engine.py').read_bytes()).hexdigest(),'variants':{k:{'facts':v,**verify_numeric(v,r['rule_text'])} for k,v in variants.items()}}
(R/'results/identifier_intervention.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf8')
print({k:v['state'] for k,v in out['variants'].items()})
