"""Download pinned public model artifacts to the D: compute cache."""
import concurrent.futures, hashlib, json, time
from pathlib import Path
import requests

ROOT=Path(__file__).resolve().parents[1]
MODELS={
 'nli':('cross-encoder/nli-deberta-v3-small','fa2804872c3b4bd748f38c0185cc85775361e735'),
 'qwen':('Qwen/Qwen3-0.6B','c1899de289a04d12100db370d81485cdf75e47ca'),
}
def ranged_download(url,p):
    for attempt in range(5):
        try:
            head=requests.get(url,headers={'Range':'bytes=0-0'},timeout=45)
            head.raise_for_status()
            total=int(head.headers['Content-Range'].split('/')[-1])
            resolved=head.url
            break
        except Exception:
            if attempt==4:raise
            time.sleep(2)
    parts=p.parent/(p.name+'.parts');parts.mkdir(exist_ok=True)
    chunk=4*2**20
    def part(start):
        end=min(total-1,start+chunk-1);cp=parts/str(start)
        if cp.exists() and cp.stat().st_size==end-start+1:return cp
        for attempt in range(6):
            try:
                rr=requests.get(resolved,headers={'Range':f'bytes={start}-{end}'},timeout=90)
                rr.raise_for_status()
                assert rr.status_code==206 and len(rr.content)==end-start+1,(rr.status_code,len(rr.content),start,end)
                assert rr.headers['Content-Range'].startswith(f'bytes {start}-{end}/')
                cp.write_bytes(rr.content)
                return cp
            except Exception:
                if attempt==5:raise
                time.sleep(2+attempt)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        for i,cp in enumerate(ex.map(part,range(0,total,chunk))):
            if i%10==0:print(p.parent.name,'download',round(min(total,(i+1)*chunk)/total*100,1),'%',flush=True)
    pp=p.with_suffix(p.suffix+'.part')
    with pp.open('wb') as f:
        for start in range(0,total,chunk):f.write((parts/str(start)).read_bytes())
    pp.rename(p)
def download_model(item):
    key,(repo,revision)=item
    path=ROOT/'cache'/'models'/key; path.mkdir(parents=True,exist_ok=True)
    data=requests.get(f'https://huggingface.co/api/models/{repo}/revision/{revision}',timeout=60).json()
    names=[x['rfilename'] for x in data['siblings'] if '/' not in x['rfilename'] and (x['rfilename'].endswith(('.json','.safetensors','.model','.txt')) or x['rfilename'] in ['README.md','LICENSE'])]
    manifest=[]
    for name in names:
        p=path/name
        url=f'https://huggingface.co/{repo}/resolve/{revision}/{name}'
        if not p.exists():
            if name.endswith('.safetensors'):
                ranged_download(url,p)
            else:
                for attempt in range(5):
                    try:
                        r=requests.get(url,timeout=90);r.raise_for_status();p.write_bytes(r.content);break
                    except Exception:
                        if attempt==4:raise
                        time.sleep(2)
        h=hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
        manifest.append({'file':name,'bytes':p.stat().st_size,'sha256':h.hexdigest(),'url':url})
        print(key,name,p.stat().st_size,flush=True)
    (path/'provenance.json').write_text(json.dumps({'repo':repo,'revision':revision,'files':manifest},indent=2),encoding='utf-8')
    return key
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        print(list(ex.map(download_model,MODELS.items())),flush=True)
