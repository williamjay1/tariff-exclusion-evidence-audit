"""Resume pinned Qwen4 downloads with 24 range workers; preserve existing parts."""
import os,sys,json,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'deps'))
os.environ['HF_HOME']=str(ROOT/'cache'/'hf')
os.environ['TEMP']=os.environ['TMP']=str(ROOT/'temp')
from prepare_models import download_model
import prepare_models
Executor=prepare_models.concurrent.futures.ThreadPoolExecutor
class DownloadExecutor(Executor):
    def __init__(self,max_workers=None,*args,**kwargs):
        super().__init__(max_workers=24 if max_workers==4 else max_workers,*args,**kwargs)
prepare_models.concurrent.futures.ThreadPoolExecutor=DownloadExecutor
if __name__=='__main__':
    print('Pinned qwen4 resume, 24 workers x 4 MiB chunks; existing verified-size parts reused.',flush=True)
    download_model(('qwen4',('Qwen/Qwen3-4B-Instruct-2507','cdbee75f17c01a7cc42f958dc650907174af0554')))
