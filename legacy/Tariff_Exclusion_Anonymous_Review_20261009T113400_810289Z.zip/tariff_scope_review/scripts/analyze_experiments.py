from pathlib import Path
import json,time,hashlib
import numpy as np
from sklearn.metrics import confusion_matrix
from constraint_engine import verify_numeric
ROOT=Path(__file__).resolve().parents[1]
def read(p):return list(map(json.loads,p.read_text(encoding='utf8').splitlines()))
rows=read(ROOT/'datasets/benchmark.jsonl');byid={r['case_id']:i for i,r in enumerate(rows)}
y=np.array([r['y'] for r in rows]);groups=np.array([r['group'] for r in rows]);codes=np.array([r['code_match'] if r['code_match'] is not None else -1 for r in rows])
traces=[]
for r in rows:
    t=time.perf_counter();v=verify_numeric(r['facts'],r['rule_text']);v.update(case_id=r['case_id'],seconds=time.perf_counter()-t);traces.append(v)
(ROOT/'results/numeric_traces.jsonl').write_text(''.join(json.dumps(t,default=str)+'\n' for t in traces),encoding='utf8')
states=np.array([t['state'] for t in traces])
models={'Code matching':{'binary':np.where(codes==0,0,1),'selective':np.where(codes==-1,-1,codes),'confidence':np.ones(len(rows))}}
latency={}
for key,title in [('nli','DeBERTa NLI'),('qwen','Qwen3 0.6B')]:
    rec=read(ROOT/'results'/f'benchmark_{key}.jsonl');d={r['case_id']:r for r in rec};rec=[d[r['case_id']] for r in rows]
    pred=np.array([r['binary_prediction'] for r in rec]);sel=np.array([r['selective_prediction'] for r in rec]);conf=np.array([max(r['prob_eligible'],r['prob_ineligible']) for r in rec])
    pred[codes==0]=0;sel[codes==0]=0;conf[codes==0]=1
    models[title]={'binary':pred,'selective':sel,'confidence':conf}
    bp=pred.copy();sp=sel.copy();c=conf.copy()
    bp[(states=='fail')&(codes!=0)]=0;sp[(states=='fail')&(codes!=0)]=0;c[(states=='fail')&(codes!=0)]=1
    sp[(states=='unknown')&(codes!=0)]=-1;c[(states=='unknown')&(codes!=0)]=-1
    models[title+' + numeric guard']={'binary':bp,'selective':sp,'confidence':c}
    latency[title]={'seconds_total':sum(r['seconds'] for r in rec),'median_seconds':float(np.median([r['seconds'] for r in rec])),'truncated_n':sum(r['truncated'] for r in rec),'input_tokens_median':float(np.median([r['input_tokens'] for r in rec]))}
lr=read(ROOT/'results/benchmark_classical.jsonl')
for key,title in [('word_lr','Word TFIDF LR'),('word_char_lr','Word and character TFIDF LR')]:
    d={r['case_id']:r for r in lr if r['model']==key};probs=np.array([d[r['case_id']]['prob_eligible'] for r in rows]);pred=(probs>=.5).astype(int);pred[codes==0]=0
    models[title]={'binary':pred,'selective':pred.copy(),'confidence':np.maximum(probs,1-probs)}

def metrics(yy,pp):
    tp=int(sum((yy==1)&(pp==1)));fn=int(sum((yy==1)&(pp==0)));fp=int(sum((yy==0)&(pp==1)));tn=int(sum((yy==0)&(pp==0)))
    return {'n':len(yy),'tp':tp,'fn':fn,'fp':fp,'tn':tn,'accuracy':float(np.mean(yy==pp)),
            'balanced_accuracy':float((tp/(tp+fn)+tn/(tn+fp))/2) if tp+fn and tn+fp else None,
            'false_exemption_rate':fp/(fp+tn) if fp+tn else None,'eligible_recall':tp/(tp+fn) if tp+fn else None}
def bootstrap(yy,pp,gg,B=2000):
    rng=np.random.default_rng(20261007);ug=np.unique(gg);index=[np.where(gg==g)[0] for g in ug];out=[]
    for _ in range(B):
        ids=np.concatenate([index[i] for i in rng.integers(len(ug),size=len(ug))]);m=metrics(yy[ids],pp[ids])
        if m['balanced_accuracy'] is not None:out.append([m['balanced_accuracy'],m['false_exemption_rate'],m['eligible_recall']])
    a=np.array(out)
    return {k:[float(x) for x in np.quantile(a[:,j],[.025,.975])] for j,k in enumerate(['balanced_accuracy','false_exemption_rate','eligible_recall'])}

output={'observed':{},'latency':latency,'numeric_state_counts':{k:int(sum(states==k)) for k in np.unique(states)},'protocol':'Frozen primary numeric engine, source-group bootstrap B=2000 seed=20261007; no threshold selection on test labels.'}
subsets={'same_code':codes==1,'all_code_known':codes>=0,'exact_ten_digit':np.array([r['exact_code_match'] for r in rows])}
for subset,mask in subsets.items():
    yy=y[mask];gg=groups[mask];out={}
    for name,m in models.items():
        p=m['binary'][mask];s=m['selective'][mask];keep=s!=-1
        result=metrics(yy,p);result['cluster_bootstrap_95ci']=bootstrap(yy,p,gg)
        result['selective']={'answered':int(keep.sum()),'referrals':int((~keep).sum()),'coverage':float(keep.mean()),'errors':int(sum((s!=yy)&keep)),
           'error_rate_answered':float(np.mean(s[keep]!=yy[keep])) if keep.sum() else None,
           'false_exemptions':int(sum((s==1)&(yy==0))),'false_denials':int(sum((s==0)&(yy==1))),
           'eligible_coverage':float(np.mean(keep[yy==1])),'ineligible_coverage':float(np.mean(keep[yy==0]))}
        risks=[]
        order=np.argsort(-m['confidence'][mask],kind='stable')
        if 'numeric guard' in name:order=order[m['confidence'][mask][order]>=0]
        for fraction in [.25,.50,.75,1.0]:
            k=min(len(order),max(1,round(len(yy)*fraction)));ii=order[:k]
            risks.append({'requested_coverage':fraction,'actual_coverage':k/len(yy),'n':k,'errors':int(sum(p[ii]!=yy[ii])),'risk':float(np.mean(p[ii]!=yy[ii]))})
        result['risk_coverage_descriptive']=risks;out[name]=result
    output['observed'][subset]={'n':int(mask.sum()),'groups':len(set(gg)),'positive':int(yy.sum()),'negative':int(len(yy)-yy.sum()),'models':out}
# Pairwise bootstrap difference for numeric veto, preserving the paired source groups.
mask=subsets['same_code'];yy=y[mask];gg=groups[mask];rng=np.random.default_rng(20261007);ug=np.unique(gg)
diff={}
for name in ['DeBERTa NLI','Qwen3 0.6B']:
    base=models[name]['binary'][mask];guard=models[name+' + numeric guard']['binary'][mask];ds=[]
    for _ in range(2000):
        ix=np.concatenate([np.where(gg==g)[0] for g in rng.choice(ug,size=len(ug),replace=True)])
        if len(set(yy[ix]))<2:continue
        ds.append(metrics(yy[ix],guard[ix])['balanced_accuracy']-metrics(yy[ix],base[ix])['balanced_accuracy'])
    diff[name]={'corrected':int(sum((base!=yy)&(guard==yy))),'new_errors':int(sum((base==yy)&(guard!=yy))),'balanced_accuracy_delta':metrics(yy,guard)['balanced_accuracy']-metrics(yy,base)['balanced_accuracy'],'cluster_bootstrap_95ci':np.quantile(ds,[.025,.975]).tolist()}
output['paired_numeric_guard']=diff
costs={}
for grant in [1,5,10,25]:
    costs[str(grant)]={}
    for referral in [.1,.25,.5]:
        values={}
        for name,m in models.items():
            p=m['selective'][mask]
            values[name]=float((grant*sum((p==1)&(yy==0))+sum((p==0)&(yy==1))+referral*sum(p==-1))/len(yy))
        values['Refer all']=referral
        costs[str(grant)][str(referral)]=values
output['cost_sensitivity_same_code']=costs
# Stress is a different task: three-state satisfaction of a single numeric predicate.
stress=read(ROOT/'datasets/stress.jsonl');sy=np.array([r['y'] for r in stress]);sg=np.array([r['group'] for r in stress]);predictions={}
for key,title in [('nli','DeBERTa NLI'),('qwen','Qwen3 0.6B')]:
    rr={r['case_id']:r for r in read(ROOT/'results'/f'stress_{key}.jsonl')}
    predictions[title]=np.array([rr[r['case_id']]['selective_prediction'] for r in stress])
numeric=[];stress_traces=[]
for r in stress:
    v=verify_numeric(r['facts'],r['rule_text']);numeric.append({'pass':1,'fail':0,'unknown':-1,'not_parsed':-1}[v['state']]);stress_traces.append({'case_id':r['case_id'],**v})
predictions['Numeric predicate execution']=np.array(numeric)
(ROOT/'results/stress_numeric_traces.jsonl').write_text(''.join(json.dumps(t,default=str)+'\n' for t in stress_traces),encoding='utf8')
stressout={};rng=np.random.default_rng(20261007);ug=np.unique(sg)
for name,p in predictions.items():
    vals=[]
    for _ in range(2000):
        ix=np.concatenate([np.where(sg==g)[0] for g in rng.choice(ug,size=len(ug),replace=True)]);vals.append(float(np.mean(p[ix]==sy[ix])))
    stressout[name]={'n':len(sy),'correct':int(sum(p==sy)),'accuracy':float(np.mean(p==sy)),'rule_bootstrap_95ci':np.quantile(vals,[.025,.975]).tolist(),
       'confusion_labels':[-1,0,1],'confusion_matrix':confusion_matrix(sy,p,labels=[-1,0,1]).tolist(),
       'by_scenario':{s:{'n':sum(r['scenario']==s for r in stress),'correct':int(sum((p==sy)&np.array([r['scenario']==s for r in stress])))} for s in sorted(set(r['scenario'] for r in stress))}}
output['stress']=stressout
output['frozen_engine_sha256']=hashlib.sha256((ROOT/'scripts/constraint_engine.py').read_bytes()).hexdigest()
(ROOT/'results/analysis.json').write_text(json.dumps(output,indent=2),encoding='utf8')
(ROOT/'results/all_observed_predictions.jsonl').write_text(''.join(json.dumps({'case_id':r['case_id'],'y':int(y[i]),'group':groups[i],'code_match':int(codes[i]),'numeric_state':states[i],'models':{k:{'binary':int(v['binary'][i]),'selective':int(v['selective'][i]),'confidence':float(v['confidence'][i])} for k,v in models.items()}})+'\n' for i,r in enumerate(rows)),encoding='utf8')
print('Analysis complete; same-code table:')
for k,v in output['observed']['same_code']['models'].items():print(k,v['balanced_accuracy'],v['fp'],v['fn'],v['selective'])
print('Stress:',{k:(v['correct'],v['accuracy']) for k,v in stressout.items()})
