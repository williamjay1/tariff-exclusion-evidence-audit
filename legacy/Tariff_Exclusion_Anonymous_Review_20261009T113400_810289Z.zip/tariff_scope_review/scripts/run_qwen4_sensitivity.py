"""Resource-conditioned 4B sensitivity run; fixed scope-v1, no prompt selection."""
import os,sys,time,json,subprocess,hashlib,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'deps'))
os.environ['PYTHONPATH']=str(ROOT/'deps')
os.environ['HF_HOME']=str(ROOT/'cache'/'hf')
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TEMP']=os.environ['TMP']=str(ROOT/'temp')
os.environ['PYTHONIOENCODING']='utf-8'
os.environ['TOKENIZERS_PARALLELISM']='false'

def run(args):
    cmd=[sys.executable,str(ROOT/'scripts/run_neural.py'),'--model','qwen4',*args]
    print('RUN',cmd,flush=True)
    completed=subprocess.run(cmd,env=os.environ.copy(),cwd=ROOT,check=False)
    if completed.returncode:raise RuntimeError(f'Inference exited {completed.returncode}: {args}')

def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines()]

def main():
    # Download is active in a separately managed process; a complete manifest
    # is its final action. This helper waits at most 30 minutes, without rereads
    # of the raw corpus or any model inference before the resource decision.
    manifest=ROOT/'cache/models/qwen4/provenance.json'
    deadline=time.monotonic()+1800
    while not manifest.exists():
        if time.monotonic()>deadline:raise TimeoutError('Pinned model download did not complete in 30 minutes.')
        time.sleep(2)
    prov=json.loads(manifest.read_text(encoding='utf-8'))
    assert prov['revision']=='cdbee75f17c01a7cc42f958dc650907174af0554'
    # A locally computed digest alone is not an authenticity check: compare
    # every shard to official Hugging Face LFS digests at the pinned revision.
    import requests
    url=f"https://huggingface.co/api/models/{prov['repo']}/revision/{prov['revision']}?blobs=true"
    response=requests.get(url,timeout=90);response.raise_for_status()
    official=response.json()
    official_weights={x['rfilename']:x['lfs']['sha256'] for x in official['siblings'] if x['rfilename'].endswith('.safetensors')}
    checked=[]
    for entry in prov['files']:
        if not entry['file'].endswith('.safetensors'):continue
        assert entry['file'] in official_weights
        checked.append({'file':entry['file'],'bytes':entry['bytes'],'local_sha256':entry['sha256'],
                        'official_lfs_sha256':official_weights[entry['file']],
                        'match':entry['sha256']==official_weights[entry['file']]})
    assert len(checked)==len(official_weights)==3 and all(x['match'] for x in checked)
    (ROOT/'results/qwen4_official_weight_hash_check.json').write_text(json.dumps({'repo':prov['repo'],'revision':prov['revision'],'official_api':url,'before_first_inference':True,'weights':checked},indent=2),encoding='utf-8')
    print('OFFICIAL WEIGHT DIGESTS MATCH',len(checked),'shards',flush=True)
    decision=json.loads((ROOT/'results/qwen4_resource_decision.json').read_text(encoding='utf-8-sig'))
    assert decision['decision_before_first_inference'] and decision['weights_dtype']=='bfloat16'
    start=time.monotonic()
    run(['--input','benchmark.jsonl','--limit','1'])
    sample=read(ROOT/'results/benchmark_qwen4.jsonl')[0]
    assert all(math.isfinite(sample[k]) for k in ['prob_eligible','prob_ineligible','prob_unknown'])
    meta=json.loads((ROOT/'results/benchmark_qwen4.meta.json').read_text(encoding='utf-8'))
    assert meta['dtype']=='bfloat16'
    preflight={'wall_seconds':time.monotonic()-start,'sample_seconds':sample['seconds'],
       'sample_input_tokens':sample['input_tokens'],'load_seconds':meta['load_seconds'],
       'finite_scores':True,'dtype':meta['dtype'],'threads':meta['threads'],
       'selection_rule':'Proceed on finite scores and successful resource execution; no outcome-based prompt or model selection.',
       'model_revision':prov['revision']}
    (ROOT/'results/qwen4_preflight.json').write_text(json.dumps(preflight,indent=2),encoding='utf-8')
    print('PREFLIGHT',json.dumps(preflight),flush=True)
    run(['--input','benchmark.jsonl'])
    run(['--input','stress.jsonl'])
    outputs={}
    for stem,expected in [('benchmark',86),('stress',480)]:
        path=ROOT/f'results/{stem}_qwen4.jsonl';rows=read(path)
        assert len(rows)==expected and len({r['case_id'] for r in rows})==expected
        assert all(math.isfinite(r[k]) for r in rows for k in ['prob_eligible','prob_ineligible','prob_unknown'])
        outputs[stem]={'n':len(rows),'inference_seconds':sum(r['seconds'] for r in rows),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    prior=json.loads((ROOT/'results/qwen4_prior_result_hashes.json').read_text(encoding='utf-8'))
    assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==v for name,v in prior.items())
    (ROOT/'results/qwen4_completion.json').write_text(json.dumps({'complete':True,'preflight':preflight,'outputs':outputs,'prior_results_unchanged':True},indent=2),encoding='utf-8')
    print('COMPLETE',json.dumps(outputs),flush=True)

if __name__=='__main__':main()
