"""Post hoc source-identity versus exact model-input duplication sensitivity."""
import json
from pathlib import Path
from collections import defaultdict
import numpy as np
R=Path(__file__).resolve().parents[1]
def read(p):return [json.loads(x) for x in (R/p).read_text(encoding='utf8').splitlines()]
rows=read('datasets/stress.jsonl');groups=defaultdict(list)
for i,r in enumerate(rows):groups[(r['facts'],r['rule_text'])].append(i)
assert all(len({rows[i]['y'] for i in ix})==1 for ix in groups.values())
selected=[ix[0] for ix in groups.values()];y=np.array([r['y'] for r in rows]);pred={}
for name,fn in [('DeBERTa NLI','nli'),('Qwen3 0.6B','qwen'),('Qwen3 4B Instruct','qwen4')]:
 rec={r['case_id']:r for r in read('results/stress_'+fn+'.jsonl')}
 pred[name]=np.array([rec[r['case_id']]['selective_prediction'] for r in rows])
rec={r['case_id']:r for r in read('results/stress_numeric_traces.jsonl')}
pred['Numeric predicate execution']=np.array([{'pass':1,'fail':0,'unknown':-1,'not_parsed':-1}[rec[r['case_id']]['state']] for r in rows])
clauses=np.array([r['rule_text'] for r in rows]);clausegroups=[np.where(clauses==c)[0] for c in np.unique(clauses)]
out={'status':'Post hoc sensitivity after final inference; no input or prediction changed.','rows':len(rows),'unique_model_inputs':len(groups),'duplicate_input_groups':sum(len(ix)>1 for ix in groups.values()),'unique_literal_clauses':len(clausegroups),'models':{}}
for name,p in pred.items():
 disagreements=[ix for ix in groups.values() if len({int(p[i]) for i in ix})>1];assert not disagreements,(name,disagreements)
 rng=np.random.default_rng(20261007);vals=[]
 for _ in range(2000):
  ix=np.concatenate([clausegroups[k] for k in rng.integers(len(clausegroups),size=len(clausegroups))]);vals.append(float(np.mean(p[ix]==y[ix])))
 out['models'][name]={'deduplicated_correct':int(sum(p[selected]==y[selected])),'deduplicated_accuracy':float(np.mean(p[selected]==y[selected])),'duplicate_label_disagreements':0,'all_rows_clause_bootstrap_95ci':np.quantile(vals,[.025,.975]).tolist()}
(R/'results/stress_input_duplicate_audit.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps(out,indent=2))
