"""Read collected CROSS records without modifying originals; derive section views."""
import collections, json, re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sources=sorted(p for p in (ROOT/'datasets').glob('cbp_*.jsonl') if re.fullmatch(r'cbp_(?:rulings|supplement|recovery)_\d{8}T\d{6}Z\.jsonl',p.name))
rows=[]; seen=set()
for line in '\n'.join(p.read_text('utf-8') for p in sources).splitlines():
    try: r=json.loads(line)
    except json.JSONDecodeError: continue  # source may still be appended
    if r['rulingNumber'] in seen: continue
    seen.add(r['rulingNumber'])
    t=r.get('text','')
    headings=list(re.finditer(r'\b(FACTS?|ISSUES?|LAW\s+AND\s+ANALYSIS|ANALYSIS|HOLDING)\s*:',t))
    r['sections']={}
    for i,m in enumerate(headings):
        end=headings[i+1].start() if i+1<len(headings) else len(t)
        name=re.sub(r'\s+',' ',m.group(1))
        r['sections'][name]=t[m.end():end].strip()
    # These are screening flags, not adjudicated eligibility labels.
    r['screening_flags']={
        'section_301_or_code':bool(re.search(r'Section\s+301|9903\.88\.',t,re.I)),
        'exclusion_in_subject':bool(re.search(r'exclu|exempt',r.get('subject',''),re.I)),
        'exclusion_in_issue':bool(re.search(r'exclu|exempt',r['sections'].get('ISSUE',r['sections'].get('ISSUES','')),re.I)),
        'exclusion_in_holding':bool(re.search(r'exclu|exempt',r['sections'].get('HOLDING',''),re.I)),
        'operationally_revoked':r.get('operationallyRevoked',False),
        'pdf_mojibake':('\ufffd' in t),
    }
    rows.append(r)

out=ROOT/'datasets'/'cbp_rulings_derived.jsonl'
temp=out.with_suffix('.tmp')
temp.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
temp.replace(out)
summary={'sources':[str(p) for p in sources],'derived':str(out),'n_records':len(rows),'collections':dict(collections.Counter(r['collection'] for r in rows)),'years':dict(sorted(collections.Counter(r['rulingDate'][:4] for r in rows).items())),'section_counts':dict(collections.Counter(k for r in rows for k in r['sections'])),'screen_counts':{k:sum(r['screening_flags'][k] for r in rows) for k in rows[0]['screening_flags']},'substantive_candidates':[{'rulingNumber':r['rulingNumber'],'date':r['rulingDate'],'subject':r['subject']} for r in rows if r['screening_flags']['section_301_or_code'] and (r['screening_flags']['exclusion_in_subject'] or r['screening_flags']['exclusion_in_issue'] or r['screening_flags']['exclusion_in_holding'])]}
(ROOT/'datasets'/'cbp_derived_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='substantive_candidates'},indent=2))
