"""Independent arithmetic/protocol audit of the completed post hoc 4B sensitivity.

Reads individual frozen predictions; never runs inference, fits a model, imports
the constraint engine, modifies source data or rewrites the primary analysis.
NumPy is used only for the recorded generator stream and quantiles. Bootstrap
estimates are rebuilt by weighted group confusion counts, rather than the row
concatenation used by analyze_scale.py.
"""
from pathlib import Path
from collections import Counter
from fractions import Fraction
from statistics import median
from datetime import datetime, timezone
import hashlib
import json
import math
import re
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
used = {}
checks = []
errors = []


def load(name, lines=False):
    data = (ROOT / name).read_bytes()
    used[name] = hashlib.sha256(data).hexdigest()
    return [json.loads(x) for x in data.decode('utf8').splitlines() if x] if lines else json.loads(data)


def compare(path, expected, actual):
    if isinstance(expected, dict):
        for key, val in expected.items():
            if key not in actual:
                errors.append({'path': path + '.' + str(key), 'error': 'missing field'})
            else:
                compare(path + '.' + str(key), val, actual[key])
    elif isinstance(expected, list):
        if len(expected) != len(actual):
            errors.append({'path': path, 'expected': expected, 'actual': actual})
        else:
            for ix, val in enumerate(expected):
                compare(path + f'[{ix}]', val, actual[ix])
    else:
        good = (math.isclose(float(expected), float(actual), abs_tol=1e-11, rel_tol=1e-11)
                if isinstance(expected, (int, float)) and actual is not None else expected == actual)
        checks.append(path)
        if not good:
            errors.append({'path': path, 'expected': expected, 'actual': actual})


def ratio(a, b):
    return float(Fraction(int(a), int(b))) if b else None


def binary_metrics(data, predictions):
    c = Counter((r['y'], predictions[r['case_id']]) for r in data)
    tp, fn, fp, tn = (c[k] for k in [(1, 1), (1, 0), (0, 1), (0, 0)])
    assert tp + fn + fp + tn == len(data)
    return {'n': len(data), 'tp': tp, 'fn': fn, 'fp': fp, 'tn': tn,
            'accuracy': ratio(tp + tn, len(data)),
            'balanced_accuracy': float((Fraction(tp, tp + fn) + Fraction(tn, fp + tn)) / 2) if tp + fn and fp + tn else None,
            'false_exemption_rate': ratio(fp, fp + tn), 'eligible_recall': ratio(tp, tp + fn)}


def selective_metrics(data, predictions):
    c = Counter((r['y'], predictions[r['case_id']]) for r in data)
    answered = sum(v for (y, p), v in c.items() if p != -1)
    wrong = c[0, 1] + c[1, 0]
    pos = sum(r['y'] == 1 for r in data)
    neg = len(data) - pos
    return {'answered': answered, 'referrals': len(data) - answered,
            'coverage': ratio(answered, len(data)), 'errors': wrong,
            'error_rate_answered': ratio(wrong, answered), 'false_exemptions': c[0, 1],
            'false_denials': c[1, 0], 'eligible_coverage': ratio(pos - c[1, -1], pos),
            'ineligible_coverage': ratio(neg - c[0, -1], neg)}


def cluster_intervals(data, predictions):
    groups = sorted({r['group'] for r in data})
    counts = []
    for group in groups:
        m = binary_metrics([r for r in data if r['group'] == group], predictions)
        counts.append([m[k] for k in ['tp', 'fn', 'fp', 'tn']])
    counts = np.array(counts, dtype='int64')
    rng = np.random.default_rng(20261007)
    estimates = []
    for _ in range(2000):
        weights = np.bincount(rng.integers(0, len(groups), len(groups)), minlength=len(groups))
        tp, fn, fp, tn = map(int, weights @ counts)
        if tp + fn and fp + tn:
            estimates.append([(ratio(tp, tp + fn) + ratio(tn, fp + tn)) / 2,
                              ratio(fp, fp + tn), ratio(tp, tp + fn)])
    return {key: np.quantile([x[ix] for x in estimates], [.025, .975]).tolist()
            for ix, key in enumerate(['balanced_accuracy', 'false_exemption_rate', 'eligible_recall'])}


def main():
    data = load('datasets/benchmark.jsonl', True)
    stress = load('datasets/stress.jsonl', True)
    bench_preds = load('results/benchmark_qwen4.jsonl', True)
    stress_preds = load('results/stress_qwen4.jsonl', True)
    analysis = load('results/scale_analysis.json')
    traces = {x['case_id']: x for x in load('results/numeric_traces.jsonl', True)}
    identifier = load('results/identifier_intervention.json')
    assert len(data) == len(bench_preds) == 86 and len(stress) == len(stress_preds) == 480
    prediction = {}
    protocol = {}
    for stem, inputs, records in [('benchmark', data, bench_preds), ('stress', stress, stress_preds)]:
        byid = {x['case_id']: x for x in records}
        assert len(byid) == len(records) and set(byid) == {r['case_id'] for r in inputs}
        meta = load(f'results/{stem}_qwen4.meta.json')
        fingerprint = load(f'results/{stem}_qwen4.run.json')
        compare(stem + '.meta.input_sha256', used[f'datasets/{stem}.jsonl'], meta['input_sha256'])
        compare(stem + '.run.input_sha256', used[f'datasets/{stem}.jsonl'], fingerprint['input_sha256'])
        compare(stem + '.model_revision', 'cdbee75f17c01a7cc42f958dc650907174af0554', meta['model_provenance']['revision'])
        compare(stem + '.dtype', 'bfloat16', meta['dtype'])
        for r in inputs:
            p = byid[r['case_id']]
            probs = [p[k] for k in ['prob_eligible', 'prob_ineligible', 'prob_unknown']]
            compare(stem + '.' + r['case_id'] + '.binary', int(probs[0] >= probs[1]), p['binary_prediction'])
            compare(stem + '.' + r['case_id'] + '.selective', [1, 0, -1][max(range(3), key=lambda i: probs[i])], p['selective_prediction'])
            scope = re.split(r'\(\s*(?:as )?described', r['rule_text'], flags=re.I)[0].strip()
            expected_tail = '\n\nPRODUCT FACTS:\n' + r['facts'] + '\n\nEXCLUSION DESCRIPTION:\n' + scope + '<|im_end|>\n<|im_start|>assistant\n'
            compare(stem + '.' + r['case_id'] + '.prompt_payload', True, p['prompt'].endswith(expected_tail))
        protocol[stem] = {'records': len(records), 'truncated': sum(p['truncated'] for p in records),
                          'input_sha256': meta['input_sha256'], 'dtype': meta['dtype']}
        prediction[stem] = byid
    b, s, bg, sg = {}, {}, {}, {}
    for r in data:
        i = r['case_id']; p = prediction['benchmark'][i]
        b[i] = 0 if r['code_match'] == 0 else p['binary_prediction']
        s[i] = 0 if r['code_match'] == 0 else p['selective_prediction']
        bg[i], sg[i] = b[i], s[i]
        if r['code_match'] != 0:
            if traces[i]['state'] == 'fail':
                bg[i] = sg[i] = 0
            elif traces[i]['state'] == 'unknown':
                sg[i] = -1
    model = {'Qwen3 4B Instruct': (b, s), 'Qwen3 4B Instruct + numeric guard': (bg, sg)}
    subsets = {'same_code': [r for r in data if r['code_match'] == 1],
               'all_code_known': [r for r in data if r['code_match'] is not None],
               'exact_ten_digit': [r for r in data if r['exact_code_match']]}
    observed = {}
    for name, sub in subsets.items():
        item = {'n': len(sub), 'groups': len({r['group'] for r in sub}),
                'positive': sum(r['y'] for r in sub), 'negative': sum(r['y'] == 0 for r in sub), 'models': {}}
        for label, (binary, selective) in model.items():
            item['models'][label] = {**binary_metrics(sub, binary),
                                     'selective': selective_metrics(sub, selective),
                                     'cluster_bootstrap_95ci': cluster_intervals(sub, binary)}
        compare('observed.' + name, item, analysis['observed'][name])
        observed[name] = item
    costs = {}
    for grant in [1, 5, 10, 25]:
        costs[str(grant)] = {}
        for referral in ['0.1', '0.25', '0.5']:
            values = {}
            for name, (_, selective) in model.items():
                amount = Fraction(0)
                for r in subsets['same_code']:
                    p = selective[r['case_id']]
                    amount += (Fraction(referral) if p == -1 else Fraction(grant) if p == 1 and r['y'] == 0 else Fraction(1) if p == 0 and r['y'] == 1 else Fraction(0))
                values[name] = float(amount / len(subsets['same_code']))
            costs[str(grant)][referral] = values
    compare('cost_sensitivity_same_code', costs, analysis['cost_sensitivity_same_code'])
    sp = {i: r['selective_prediction'] for i, r in prediction['stress'].items()}
    confusion = Counter((r['y'], sp[r['case_id']]) for r in stress)
    unique = {}
    for r in stress:
        unique.setdefault((r['rule_id'], r['facts'], r['y']), r)
    correct = sum(sp[r['case_id']] == r['y'] for r in stress)
    unique_correct = sum(sp[r['case_id']] == r['y'] for r in unique.values())
    stress_metrics = {'n': len(stress), 'correct': correct, 'accuracy': ratio(correct, len(stress)),
                      'confusion_labels': [-1, 0, 1],
                      'confusion_matrix': [[confusion[a, z] for z in [-1, 0, 1]] for a in [-1, 0, 1]],
                      'deduplicated': {'n': len(unique), 'correct': unique_correct, 'accuracy': ratio(unique_correct, len(unique))},
                      'by_scenario': {scenario: {'n': sum(r['scenario'] == scenario for r in stress),
                                               'correct': sum(r['scenario'] == scenario and sp[r['case_id']] == r['y'] for r in stress)}
                                      for scenario in sorted({r['scenario'] for r in stress})}}
    groups = sorted({r['group'] for r in stress}); counts = []
    for group in groups:
        rows = [r for r in stress if r['group'] == group]
        counts.append([sum(sp[r['case_id']] == r['y'] for r in rows), len(rows)])
    counts = np.array(counts, dtype='int64'); rng = np.random.default_rng(20261007); accuracy = []
    for _ in range(2000):
        weights = np.bincount(rng.integers(0, len(groups), len(groups)), minlength=len(groups))
        good, total = map(int, weights @ counts); accuracy.append(ratio(good, total))
    stress_metrics['rule_bootstrap_95ci'] = np.quantile(accuracy, [.025, .975]).tolist()
    compare('stress', stress_metrics, analysis['stress']['Qwen3 4B Instruct'])
    # The later exact-input sensitivity distinguishes source identity (443)
    # from model-visible text identity (435); no predictions are regenerated.
    duplicate_reference = load('results/stress_input_duplicate_audit.json')
    input_groups = {}
    for r in stress:
        input_groups.setdefault((r['facts'], r['rule_text']), []).append(r)
    clauses = sorted({r['rule_text'] for r in stress})
    duplicates = {'rows': len(stress), 'unique_model_inputs': len(input_groups),
                  'duplicate_input_groups': sum(len(v) > 1 for v in input_groups.values()),
                  'unique_literal_clauses': len(clauses), 'models': {}}
    all_stress_predictions = {'Qwen3 4B Instruct': sp}
    for title, short in [('DeBERTa NLI', 'nli'), ('Qwen3 0.6B', 'qwen')]:
        all_stress_predictions[title] = {r['case_id']: r['selective_prediction'] for r in load(f'results/stress_{short}.jsonl', True)}
    all_stress_predictions['Numeric predicate execution'] = {
        r['case_id']: {'pass': 1, 'fail': 0, 'unknown': -1, 'not_parsed': -1}[r['state']]
        for r in load('results/stress_numeric_traces.jsonl', True)}
    for title, decisions in all_stress_predictions.items():
        selected = [group[0] for group in input_groups.values()]
        ncorrect = sum(decisions[r['case_id']] == r['y'] for r in selected)
        disagreed = sum(len({decisions[r['case_id']] for r in group}) > 1 for group in input_groups.values())
        assert all(len({r['y'] for r in group}) == 1 for group in input_groups.values())
        clause_counts = []
        for clause in clauses:
            sub = [r for r in stress if r['rule_text'] == clause]
            clause_counts.append([sum(decisions[r['case_id']] == r['y'] for r in sub), len(sub)])
        clause_counts = np.array(clause_counts, dtype='int64')
        rng = np.random.default_rng(20261007); boot = []
        for _ in range(2000):
            weights = np.bincount(rng.integers(0, len(clauses), len(clauses)), minlength=len(clauses))
            correct_total, total = map(int, weights @ clause_counts)
            boot.append(ratio(correct_total, total))
        duplicates['models'][title] = {'deduplicated_correct': ncorrect, 'deduplicated_accuracy': ratio(ncorrect, len(selected)),
                                      'duplicate_label_disagreements': disagreed,
                                      'all_rows_clause_bootstrap_95ci': np.quantile(boot, [.025, .975]).tolist()}
    compare('exact_input_duplication', duplicates, duplicate_reference)
    execution = load('results/qwen4_execution_audit.json')
    repeat_sets = [[prediction['stress'][r['case_id']] for r in group] for group in input_groups.values() if len(group) > 1]
    largest_spread = max(max(max(p[k] for p in group) - min(p[k] for p in group)
                             for k in ['prob_eligible', 'prob_ineligible', 'prob_unknown']) for group in repeat_sets)
    compare('execution.max_repeated_input_score_spread', largest_spread,
            execution['datasets']['stress']['identical_input_repetitions']['maximum_conditional_score_spread'])
    batch_preflight = load('results/qwen4_stress_batch_preflight.json')
    max_preflight_difference = max(abs(a - b) for rec in batch_preflight['decisions'] for a, b in zip(rec['single_scores'], rec['batch_scores']))
    compare('execution.max_preflight_difference', max_preflight_difference, batch_preflight['maximum_absolute_score_difference'])
    compare('execution.preflight_speedup', sum(batch_preflight['single_seconds']) / batch_preflight['batch_seconds'], batch_preflight['speedup'])
    latency = {'seconds_total': sum(p['seconds'] for p in bench_preds),
               'median_seconds': median(p['seconds'] for p in bench_preds),
               'truncated_n': sum(p['truncated'] for p in bench_preds),
               'input_tokens_median': median(p['input_tokens'] for p in bench_preds)}
    compare('latency', latency, analysis['latency']['Qwen3 4B Instruct'])
    distribution = {str(label): sum(p['selective_prediction'] == label for p in bench_preds) for label in [-1, 0, 1]}
    compare('prediction_distribution', distribution, analysis['prediction_distribution'])
    sources = {}
    for source in ['HQ', 'NY']:
        sub = [r for r in subsets['same_code'] if r['source'] == source]
        sources[source] = {name: binary_metrics(sub, binary) for name, (binary, _) in model.items()}
    compare('observed_source', sources, analysis['observed_source'])
    engine_hash = hashlib.sha256((ROOT / 'scripts/constraint_engine.py').read_bytes()).hexdigest()
    compare('identifier.engine_sha256', engine_hash, identifier['engine_sha256'])
    original = next(r for r in data if r['case_id'] == 'H317391_1')['facts']
    expected_facts = {'original': original, 'identifier_masked': original.replace('UH72600W', '[MODEL IDENTIFIER]'),
                      'identifier_explicitly_labeled': original.replace('UH72600W', 'model identifier UH72600W (not a power measurement)')}
    for variant, facts in expected_facts.items():
        compare('identifier.' + variant + '.facts', facts, identifier['variants'][variant]['facts'])
        compare('identifier.' + variant + '.state', 'unknown' if variant == 'identifier_masked' else 'fail', identifier['variants'][variant]['state'])
    guard_changes = [{'case_id': r['case_id'], 'y': r['y'], 'state': traces[r['case_id']]['state'],
                      'before_binary': b[r['case_id']], 'after_binary': bg[r['case_id']],
                      'before_selective': s[r['case_id']], 'after_selective': sg[r['case_id']]}
                     for r in subsets['same_code'] if b[r['case_id']] != bg[r['case_id']] or s[r['case_id']] != sg[r['case_id']]]
    assert all(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == digest for p, digest in used.items()), 'Audited input changed during verification'
    report = {'date_utc': datetime.now(timezone.utc).isoformat(), 'status': 'PASS' if not errors else 'FAIL',
              'checked_fields': len(checks), 'discrepancies': errors, 'inputs_sha256': used,
              'observed': observed, 'cost_sensitivity_same_code': costs, 'stress': stress_metrics,
              'latency': latency, 'prediction_distribution': distribution, 'observed_source': sources,
              'exact_input_duplicate_sensitivity': duplicates,
              'execution_sensitivity': {'maximum_repeated_score_spread': largest_spread,
                                        'maximum_preflight_difference': max_preflight_difference,
                                        'preflight_speedup': batch_preflight['speedup']},
              'protocol': protocol, 'same_code_guard_changes': guard_changes,
              'identifier_diagnostic': {'case_id': 'H317391_1', 'states': {k: v['state'] for k, v in identifier['variants'].items()},
                                        'frozen_engine_hash_verified': engine_hash, 'counterfactual_edit_only': 'single model identifier',
                                        'scope': 'One selected post hoc error; neither an additional independent observation nor an engine repair.'},
              'method': 'Individual prediction records, Counter confusion tables and Fraction cost arithmetic. Bootstrap intervals independently rebuilt from weighted group confusion counts using the recorded NumPy generator stream and quantile convention. No model inference, threshold selection, parser rerun or data change.',
              'manuscript_audit': 'Numerical outputs here support a separate read-only check of the assembled manuscript; manuscript text is not mechanically certified by this script.'}
    (ROOT / 'results/independent_scale_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    text = ['# Independent later-model result audit',
            f"Status: **{report['status']}**; {len(checks)} checked fields; {len(errors)} discrepancies.", report['method']]
    for name, value in observed.items():
        text += [f'## {name}', f"n={value['n']}; positive={value['positive']}; negative={value['negative']}; groups={value['groups']}.",
                 '| Model | TP | FN | FP | TN | BA | BA 95% interval | Answered | Errors | Referrals |',
                 '|---|---:|---:|---:|---:|---:|---|---:|---:|---:|']
        for model_name, m in value['models'].items():
            text.append(f"| {model_name} | {m['tp']} | {m['fn']} | {m['fp']} | {m['tn']} | {m['balanced_accuracy']:.9f} | {m['cluster_bootstrap_95ci']['balanced_accuracy']} | {m['selective']['answered']} | {m['selective']['errors']} | {m['selective']['referrals']} |")
    text += ['## Synthetic stress', json.dumps(stress_metrics, indent=2),
             '## Exact-input duplicate sensitivity', json.dumps(duplicates, indent=2),
             '## Source-conditioned metrics', json.dumps(sources, indent=2),
             '## Example assumed-cost check', json.dumps(costs['10']['0.25'], indent=2),
             '## Identifier diagnostic', json.dumps(report['identifier_diagnostic'], indent=2),
             '## Boundaries', 'These are fixed-model and source-grounding/arithmetic checks, not independent expert validation of the reference labels. The 60 source rules are purposively selected, and synthetic inputs supply selected literal numeric clauses rather than complete exclusion descriptions. This audit does not repeat the previous 1,277-field primary-result audit. Manuscript text is checked separately.']
    (ROOT / 'research/scale_result_audit.md').write_text('\n\n'.join(text) + '\n', encoding='utf8')
    print(json.dumps({'status': report['status'], 'checked_fields': len(checks), 'discrepancies': errors,
                      'same_code': observed['same_code'], 'stress': stress_metrics, 'example_cost': costs['10']['0.25']}, indent=2))
    assert not errors, 'Discrepancies found'


if __name__ == '__main__':
    main()
