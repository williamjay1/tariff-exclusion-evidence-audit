"""Recall audit: broader singular/plural exclusion queries without '301'."""
import json, re, sys
from pathlib import Path
import collect_cbp as c

c.RATE=1.2
c.RUN.mkdir(parents=True,exist_ok=False)
source=sorted((c.ROOT/'datasets').glob('cbp_search_index_*.json'))[0]
prior=json.loads(source.read_text('utf-8'))
existing=set(prior['detail_order'])
rows={}; qms=[]
for term in ['exclusion','exclusions']:
    batch,qm=c.fetch_search(term);qms.append(qm)
    for row in batch:
        if row['rulingNumber'] not in rows: rows[row['rulingNumber']]={**row,'queries':[]}
        rows[row['rulingNumber']]['queries'].append(term)
order=sorted(set(rows)-existing,key=lambda k:(rows[k]['collection']!='hq',rows[k]['rulingDate']))
index=c.ROOT/'datasets'/f'cbp_supplement_index_{c.STAMP}.json'
index.write_text(json.dumps({'run':c.STAMP,'queries':qms,'rulings':list(rows.values()),'detail_order':order,'main_index':str(source)},ensure_ascii=False,indent=2),encoding='utf-8')
output=c.ROOT/'datasets'/f'cbp_supplement_{c.STAMP}.jsonl'
fail=[]
print('SUPPLEMENT to download',len(order),flush=True)
with output.open('x',encoding='utf-8') as f:
    for i,rid in enumerate(order):
        try:
            row=c.fetch_detail(rid)
            f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush()
            if i<10 or (i+1)%50==0: print(f'SUPPLEMENT {i+1}/{len(order)} {rid}',flush=True)
        except Exception as e:
            fail.append({'rulingNumber':rid,'error':str(e)})
            if 'Access/rate limit' in str(e): raise
            print('FAIL',rid,str(e),flush=True)
manifest={'run':c.STAMP,'search_queries':qms,'search_unique':len(rows),'detail_requested':len(order),'detail_failed':fail,'dataset':str(output),'responses':c.MAN}
mp=c.ROOT/'datasets'/f'cbp_supplement_manifest_{c.STAMP}.json'
mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
raw=c.RUN/'manifest.json'
with raw.open('x',encoding='utf-8') as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
raw.chmod(0o444)
print('SUPPLEMENT COMPLETE',len(order)-len(fail),str(output),flush=True)
