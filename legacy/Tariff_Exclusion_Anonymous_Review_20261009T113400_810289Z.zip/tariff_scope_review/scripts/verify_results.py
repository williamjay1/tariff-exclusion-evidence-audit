"""Independent arithmetic audit of frozen predictions; no fitting or rewriting inputs."""
from pathlib import Path
from collections import Counter
from fractions import Fraction
from datetime import datetime, timezone
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[1]
used = {}
checks = []
errors = []

def load(rel, lines=False):
    p = ROOT / rel
    raw = p.read_bytes()
    used[rel] = hashlib.sha256(raw).hexdigest()
    return [json.loads(x) for x in raw.decode('utf8').splitlines()] if lines else json.loads(raw)

def indexed(records, label):
    answer = {r['case_id']: r for r in records}
    assert len(answer) == len(records), label + ' has repeated case IDs'
    return answer

def check(path, got, expected):
    if isinstance(got, float) or isinstance(expected, float):
        equal = got is not None and expected is not None and math.isclose(got, expected, rel_tol=1e-12, abs_tol=1e-12)
    else:
        equal = got == expected
    checks.append(path)
    if not equal:
        errors.append({'field': path, 'independent': got, 'recorded': expected})

def quotient(a, b):
    return None if b == 0 else float(Fraction(a, b))

def statistics(ids, binary, selective):
    c = Counter((benchmark[i]['y'], binary[i]) for i in ids)
    tn, fp, fn, tp = c[0,0], c[0,1], c[1,0], c[1,1]
    n = len(ids); pos = tp + fn; neg = tn + fp
    s = Counter((benchmark[i]['y'], selective[i]) for i in ids)
    ans = sum(v for (truth, prediction), v in s.items() if prediction != -1)
    wrong = s[0,1] + s[1,0]
    return {'n': n, 'tp': tp, 'fn': fn, 'fp': fp, 'tn': tn, 'binary_errors': fp+fn, 'binary_error_rate': quotient(fp+fn,n),
            'accuracy': quotient(tp+tn,n),
            'balanced_accuracy': None if not pos or not neg else float((Fraction(tp,pos)+Fraction(tn,neg))/2),
            'false_exemption_rate': quotient(fp,neg), 'eligible_recall': quotient(tp,pos),
            'selective': {'answered': ans, 'referrals': n-ans, 'coverage': quotient(ans,n),
                          'errors': wrong, 'error_rate_answered': quotient(wrong,ans),
                          'false_exemptions': s[0,1], 'false_denials': s[1,0],
                          'eligible_coverage': quotient(s[1,0]+s[1,1],pos),
                          'ineligible_coverage': quotient(s[0,0]+s[0,1],neg),
                          'answered_tp': s[1,1], 'answered_tn': s[0,0],
                          'eligible_referrals': s[1,-1], 'ineligible_referrals': s[0,-1]}}

def support(ids):
    return {'n':len(ids), 'positive':sum(benchmark[i]['y'] for i in ids),
            'negative':sum(not benchmark[i]['y'] for i in ids),
            'groups':len({benchmark[i]['group'] for i in ids}),
            'rulings':len({benchmark[i]['rulingNumber'] for i in ids}), 'case_ids':ids}

def recursive_compare(path, computed, published):
    for key, val in computed.items():
        if key not in published:
            continue  # Additional audit-only detail is not a published number.
        if isinstance(val,dict):
            recursive_compare(path+'.'+key, val, published[key])
        else:
            check(path+'.'+key,val,published[key])

benchmark = indexed(load('datasets/benchmark.jsonl',True),'benchmark')
analysis = load('results/analysis.json')
traces = indexed(load('results/numeric_traces.jsonl',True),'numeric traces')
assert set(traces)==set(benchmark)
states = {i:r['state'] for i,r in traces.items()}
code = {i:r['code_match'] for i,r in benchmark.items()}
models = {'Code matching': {'binary': {i:int(code[i]!=0) for i in benchmark},
                            'selective': {i:(-1 if code[i] is None else code[i]) for i in benchmark}}}
neural = {}
for short,title in [('nli','DeBERTa NLI'),('qwen','Qwen3 0.6B')]:
    records = indexed(load(f'results/benchmark_{short}.jsonl',True),short)
    assert set(records)==set(benchmark)
    neural[short]=records
    binary={}; selective={}
    for i, r in records.items():
        scores=[r['prob_eligible'],r['prob_ineligible'],r['prob_unknown']]
        assert all(0<=x<=1 for x in scores) and math.isclose(sum(scores),1,abs_tol=1e-6)
        p=int(scores[0]>=scores[1]); s=[1,0,-1][max(range(3),key=scores.__getitem__)]
        check(short+'.'+i+'.stored_binary',p,r['binary_prediction'])
        check(short+'.'+i+'.stored_selective',s,r['selective_prediction'])
        binary[i], selective[i] = (0,0) if code[i]==0 else (p,s)
    models[title]={'binary':binary,'selective':selective}
    guard_binary={}; guard_selective={}
    for i in benchmark:
        if code[i]==0 or states[i]=='fail':
            guard_binary[i],guard_selective[i]=0,0
        elif states[i]=='unknown':
            guard_binary[i],guard_selective[i]=binary[i],-1
        else:
            guard_binary[i],guard_selective[i]=binary[i],selective[i]
    models[title+' + numeric guard']={'binary':guard_binary,'selective':guard_selective}

classical = load('results/benchmark_classical.jsonl',True)
for short,title in [('word_lr','Word TFIDF LR'),('word_char_lr','Word and character TFIDF LR')]:
    records=indexed([r for r in classical if r['model']==short],short)
    assert set(records)==set(benchmark)
    binary={}
    for i,r in records.items():
        check(short+'.'+i+'.stored_binary',int(r['prob_eligible']>=.5),r['binary_prediction'])
        check(short+'.'+i+'.fold',r['fold'],benchmark[i]['fold'])
        binary[i]=0 if code[i]==0 else int(r['prob_eligible']>=.5)
    models[title]={'binary':binary,'selective':binary.copy()}

subsets={'same_code':[i for i in benchmark if code[i]==1],
         'all_code_known':[i for i in benchmark if code[i] is not None],
         'exact_ten_digit':[i for i in benchmark if benchmark[i]['exact_code_match']]}
observed={}
for subset,ids in subsets.items():
    observed[subset]=support(ids)
    recursive_compare('observed.'+subset,observed[subset],analysis['observed'][subset])
    observed[subset]['models']={}
    for title,preds in models.items():
        met=statistics(ids,**preds)
        recursive_compare('observed.'+subset+'.'+title,met,analysis['observed'][subset]['models'][title])
        observed[subset]['models'][title]=met

same=subsets['same_code']
untruncated=[i for i in same if not neural['nli'][i]['truncated']]
truncation=support(untruncated)
truncation['definition']='Same-code rows with NLI truncated=false; all models are evaluated on this identical subset.'
truncation['excluded_case_ids']=[i for i in same if i not in untruncated]
truncation['models']={title:statistics(untruncated,**preds) for title,preds in models.items()}

chrono=load('results/chronological_sensitivity.json')
later=[i for i in benchmark if benchmark[i]['date']>='2023-01-01']
latergroups={benchmark[i]['group'] for i in later}
earlier=[i for i in benchmark if benchmark[i]['date']<'2023-01-01' and benchmark[i]['group'] not in latergroups]
assert not {benchmark[i]['group'] for i in earlier}&latergroups
check('chronological.train_n',len(earlier),chrono['train_n'])
check('chronological.test_n',len(later),chrono['test_n'])
check('chronological.train_class_counts',[sum(benchmark[i]['y']==x for i in earlier) for x in [0,1]],chrono['train_class_counts'])
check('chronological.test_class_counts',[sum(benchmark[i]['y']==x for i in later) for x in [0,1]],chrono['test_class_counts'])
chronopred=indexed(chrono['predictions'],'chronological predictions')
assert set(chronopred)==set(later)
raw={i:int(r['prob_eligible']>=.5) for i,r in chronopred.items()}
for i,r in chronopred.items():check('chronological.'+i+'.stored_prediction',raw[i],r['prediction'])
gated={i:0 if code[i]==0 else raw[i] for i in raw}
chronosame=[i for i in later if code[i]==1]
chronological={'cutoff':'2023-01-01','model':'Word and character TFIDF LR; trained on date/group-purged earlier rows, not outer-fold predictions',
               'training':support(earlier),'test_all':support(later),'test_same_code':support(chronosame),
               'all_test_raw':statistics(later,raw,raw),'all_test_common_code_gate':statistics(later,gated,gated),
               'same_code_test':statistics(chronosame,gated,gated),'best_C':chrono['best_C']}

paired={}
for title in ['DeBERTa NLI','Qwen3 0.6B']:
    base=models[title]['binary']; guard=models[title+' + numeric guard']['binary']
    corrections=[i for i in same if base[i]!=benchmark[i]['y'] and guard[i]==benchmark[i]['y']]
    introduced=[i for i in same if base[i]==benchmark[i]['y'] and guard[i]!=benchmark[i]['y']]
    change={'corrected':len(corrections),'new_errors':len(introduced),
            'balanced_accuracy_delta':observed['same_code']['models'][title+' + numeric guard']['balanced_accuracy']-observed['same_code']['models'][title]['balanced_accuracy']}
    recursive_compare('paired_numeric_guard.'+title,change,analysis['paired_numeric_guard'][title])
    paired[title]={**change,'corrected_case_ids':corrections,'new_error_case_ids':introduced}

# Explicit post-result source-composition diagnostic, not a semantic comparator.
source_values=sorted({r['source'] for r in benchmark.values()})
source_diagnostic={'role':'Post hoc source-selection/style diagnostic; uses HQ/NY metadata only, never product meaning. Not a semantic baseline.',
                   'composition':{},'same_code_source_model_metrics':{},'oof_fold_training_counts':[]}
for subset,ids in [('all_86',list(benchmark)),('same_code',same)]:
    source_diagnostic['composition'][subset]={s:support([i for i in ids if benchmark[i]['source']==s]) for s in source_values}
for source in source_values:
    ids=[i for i in same if benchmark[i]['source']==source]
    source_diagnostic['same_code_source_model_metrics'][source]={'support':support(ids),'models':{title:statistics(ids,**preds) for title,preds in models.items()}}
source_oof={}
for fold in sorted({r['fold'] for r in benchmark.values()}):
    training=[i for i in benchmark if benchmark[i]['fold']!=fold]
    testing=[i for i in benchmark if benchmark[i]['fold']==fold]
    assert not {benchmark[i]['group'] for i in training}&{benchmark[i]['group'] for i in testing}
    global_counts=Counter(benchmark[i]['y'] for i in training)
    global_majority=max((0,1),key=global_counts.__getitem__)  # Prespecified tie rule: ineligible (0).
    fold_record={'fold':fold,'global_training_counts':{str(k):global_counts[k] for k in [0,1]},'sources':{}}
    chosen={}
    for source in source_values:
        counts=Counter(benchmark[i]['y'] for i in training if benchmark[i]['source']==source)
        chosen[source]=max((0,1),key=counts.__getitem__) if sum(counts.values()) else global_majority
        fold_record['sources'][source]={'negative':counts[0],'positive':counts[1],'prediction':chosen[source], 'fallback_global_majority':not sum(counts.values())}
    for i in testing:source_oof[i]=chosen[benchmark[i]['source']]
    source_diagnostic['oof_fold_training_counts'].append(fold_record)
assert set(source_oof)==set(benchmark)
source_diagnostic['oof_definition']='Within each existing outer fold, estimate each source majority using all outer training rows only. Ties predict 0; unseen source falls back to global training majority. No rule/fact text is used.'
source_diagnostic['oof_predictions']=[{'case_id':i,'fold':benchmark[i]['fold'],'source':benchmark[i]['source'],'y':benchmark[i]['y'],'prediction':source_oof[i]} for i in benchmark]
source_diagnostic['oof_metrics_all_86']=statistics(list(benchmark),source_oof,source_oof)
source_diagnostic['oof_metrics_same_code']=statistics(same,source_oof,source_oof)
source_diagnostic['oof_metrics_same_code_by_source']={s:statistics([i for i in same if benchmark[i]['source']==s],source_oof,source_oof) for s in source_values}

costs={}
for grant,byref in analysis['cost_sensitivity_same_code'].items():
    costs[grant]={}
    for referral,recorded in byref.items():
        costs[grant][referral]={}
        for title,preds in models.items():
            terms=[]
            for i in same:
                decision=preds['selective'][i];truth=benchmark[i]['y']
                terms.append(Fraction(referral) if decision==-1 else Fraction(grant) if decision==1 and truth==0 else Fraction(1) if decision==0 and truth==1 else Fraction(0))
            value=float(sum(terms)/len(same))
            check('cost.'+grant+'.'+referral+'.'+title,value,recorded[title])
            costs[grant][referral][title]=value
        check('cost.'+grant+'.'+referral+'.Refer all',float(referral),recorded['Refer all'])

# Also independently check frozen three-state stress confusion counts, without parsing rules again.
stress=indexed(load('datasets/stress.jsonl',True),'stress')
stpred={}
for short,title in [('nli','DeBERTa NLI'),('qwen','Qwen3 0.6B')]:
    records=indexed(load(f'results/stress_{short}.jsonl',True),'stress '+short)
    assert set(records)==set(stress)
    stpred[title]={i:[1,0,-1][max(range(3),key=[r['prob_eligible'],r['prob_ineligible'],r['prob_unknown']].__getitem__)] for i,r in records.items()}
sttrace=indexed(load('results/stress_numeric_traces.jsonl',True),'stress numeric trace')
assert set(sttrace)==set(stress)
stpred['Numeric predicate execution']={i:{'pass':1,'fail':0,'unknown':-1,'not_parsed':-1}[r['state']] for i,r in sttrace.items()}
stressaudit={}
for title,pred in stpred.items():
    count=Counter((stress[i]['y'],pred[i]) for i in stress)
    correct=sum(count[z,z] for z in [-1,0,1])
    item={'n':len(stress),'correct':correct,'accuracy':quotient(correct,len(stress)),
          'confusion_labels':[-1,0,1],'confusion_matrix':[[count[a,b] for b in [-1,0,1]] for a in [-1,0,1]],
          'by_scenario':{s:{'n':sum(r['scenario']==s for r in stress.values()),'correct':sum(r['scenario']==s and pred[i]==r['y'] for i,r in stress.items())} for s in {r['scenario'] for r in stress.values()}}}
    recursive_compare('stress.'+title,item,analysis['stress'][title])
    stressaudit[title]=item

numeric_counts=dict(Counter(states.values()))
check('numeric_state_counts',numeric_counts,analysis['numeric_state_counts'])
enginehash=hashlib.sha256((ROOT/'scripts/constraint_engine.py').read_bytes()).hexdigest()
check('frozen_engine_sha256',enginehash,analysis['frozen_engine_sha256'])
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in used.items()),'An audited input changed while auditing'
report={'audit_date_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS' if not errors else 'FAIL',
        'checked_fields':len(checks),'discrepancies':errors,'inputs_sha256':used,
        'observed':observed,'untruncated_same_code':truncation,'chronological':chronological,
        'source_diagnostic':source_diagnostic,
        'paired_numeric_guard':paired,'cost_sensitivity_same_code':costs,'stress':stressaudit,
        'numeric_state_counts':numeric_counts,
        'independence':'Recomputed from benchmark labels and raw neural/classical prediction files using scalar decisions, Counter confusion counts, and Fraction arithmetic. Guard states read from frozen traces; parser not changed or rerun. Existing outputs not rewritten.',
        'not_audited':'Bootstrap quantiles and descriptive risk-ranking curves were code-reviewed previously but not independently resampled here; source-label validity is outside arithmetic audit.'}
(ROOT/'results/independent_result_audit.json').write_text(json.dumps(report,indent=2),encoding='utf8')

def table(obj):
    out=['| Model | TP | FN | FP | TN | BA | Binary error rate | Answered | Answered errors | Referrals |',
         '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for name,v in obj['models'].items():
        ba='undefined (one class)' if v['balanced_accuracy'] is None else f"{v['balanced_accuracy']:.9f}"
        out.append(f"| {name} | {v['tp']} | {v['fn']} | {v['fp']} | {v['tn']} | {ba} | {v['binary_error_rate']:.9f} | {v['selective']['answered']} | {v['selective']['errors']} | {v['selective']['referrals']} |")
    return '\n'.join(out)

text=['# Independent frozen-result audit',
      f"Audit status: **{report['status']}**. Independently checked {len(checks)} recorded fields; discrepancies: {len(errors)}.",
      report['independence'],
      'Predicted eligible is the positive class. FP means false exemption; FN means false denial. BA is balanced accuracy of the forced binary output. Answered errors and referral counts refer to the separate selective output.']
for subset,obj in observed.items():
    text.extend([f'## {subset}',f"n = {obj['n']}; eligible = {obj['positive']}; ineligible = {obj['negative']}; groups = {obj['groups']}; rulings = {obj['rulings']}.",table(obj)])
text.extend(['## NLI-untruncated shared subset',truncation['definition'],
             f"n = {truncation['n']}; eligible = {truncation['positive']}; ineligible = {truncation['negative']}; groups = {truncation['groups']}.",
             'Excluded IDs: '+', '.join(truncation['excluded_case_ids'])+'.',table(truncation),
             'This is a restriction of the original same-code sample, not a model rerun or a new independent test set.',
             '## Date-purged chronological sensitivity',
             'Cutoff: 2023-01-01. Earlier training rows sharing a group with any later test row are removed. Results here use the separately fitted chronological word/character LR model, not grouped cross-validation predictions.',
             f"Training n = {len(earlier)} ({chronological['training']['negative']} ineligible, {chronological['training']['positive']} eligible), {chronological['training']['groups']} groups. Later test n = {len(later)} ({chronological['test_all']['negative']} ineligible, {chronological['test_all']['positive']} eligible), {chronological['test_all']['groups']} groups. Selected C = {chrono['best_C']}.",
             f"Same-code later test n = {len(chronosame)} ({chronological['test_same_code']['negative']} ineligible, {chronological['test_same_code']['positive']} eligible), {chronological['test_same_code']['groups']} groups.",
             table({'models':{'Chronological LR, all later raw':chronological['all_test_raw'],'Chronological LR, all later common code gate':chronological['all_test_common_code_gate'],'Chronological LR, same-code later':chronological['same_code_test']}}),
             'The small number of positive later cases limits precision; this sensitivity is not evidence against pretraining contamination.',
             '## Guard changes, cost arithmetic, and stress counts',
             json.dumps(paired,indent=2),
             'All recorded same-code normalized cost values match an independent per-case Fraction sum, including the refer-all comparator. These are assumed relative cost ratios, not observed money or a validated operational optimum.',
             '\n'.join(['| Stress method | Correct / 480 | Three-state accuracy |','|---|---:|---:|']+[f"| {title} | {v['correct']} / 480 | {v['accuracy']:.9f} |" for title,v in stressaudit.items()])])
text.extend(['The synthetic test retains 480 scenario rows, 443 distinct rule/fact/label inputs, 60 source rules, 37 repeated rows, and eight identity-conversion controls. These counts do not represent additional real CBP cases.',
             '## Source composition and source-only diagnostic',source_diagnostic['role']])
comptable=['| Sample | Source | n | Eligible | Ineligible | Groups |','|---|---|---:|---:|---:|---:|']
for subset,by_source in source_diagnostic['composition'].items():
    for source,sp in by_source.items():comptable.append(f"| {subset} | {source} | {sp['n']} | {sp['positive']} | {sp['negative']} | {sp['groups']} |")
text.append('\n'.join(comptable))
for source,item in source_diagnostic['same_code_source_model_metrics'].items():
    text.extend([f'### Same-code source: {source}',table(item)])
text.extend([source_diagnostic['oof_definition'],
             table({'models':{'Source-only diagnostic, full 86':source_diagnostic['oof_metrics_all_86'],'Source-only diagnostic, same-code 73':source_diagnostic['oof_metrics_same_code']}}),
             'Source-conditioned binary and answered-case error rates are also stored numerically in the JSON audit (binary error rate = 1 − accuracy; answered error rate is explicit). A strong source-only result reveals an association of the curated source mix with outcomes. It does not validate a semantic/legal model or establish that source causes eligibility. Source or correlated writing style can be a shortcut even when the input omits the literal HQ/NY identifier.',
             '## Audit boundaries',report['not_audited'],
             'No predictions were regenerated, no threshold was selected from the results, and no existing data or result file was changed. The extra untruncated and chronological same-code summaries are descriptive post-result sensitivity summaries and should be labeled accordingly. The post hoc Qwen 4B comparison was not included because its outputs were not part of this frozen audit.',
             'Input SHA-256 hashes and full exact numerical records are retained in `results/independent_result_audit.json`.'])
(ROOT/'research/result_audit.md').write_text('\n\n'.join(text)+'\n',encoding='utf8')
print(json.dumps({'status':report['status'],'checked_fields':len(checks),'discrepancies':errors,
                  'untruncated_support':{k:truncation[k] for k in ['n','positive','negative','groups']},
                  'chronological_same_code':chronological['same_code_test'],
                  'source_composition':{sample:{src:{k:v[k] for k in ['n','positive','negative']} for src,v in contents.items()} for sample,contents in source_diagnostic['composition'].items()},
                  'source_only_same_code':source_diagnostic['oof_metrics_same_code']},indent=2))
assert not errors, 'Independent result discrepancies found'
