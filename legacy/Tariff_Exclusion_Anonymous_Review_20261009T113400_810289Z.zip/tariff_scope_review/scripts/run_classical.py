"""Nested grouped out-of-fold linear baselines; no test-set tuning."""
from pathlib import Path
import json,re,time
import numpy as np
from sklearn.pipeline import Pipeline,FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV,StratifiedGroupKFold
from sklearn.metrics import balanced_accuracy_score
ROOT=Path(__file__).resolve().parents[1]
rows=list(map(json.loads,(ROOT/'datasets'/'benchmark.jsonl').read_text(encoding='utf8').splitlines()))
X=np.array([r['facts']+' RULE: '+re.split(r'\(\s*(?:as )?described',r['rule_text'],flags=re.I)[0] for r in rows])
y=np.array([r['y'] for r in rows]);g=np.array([r['group'] for r in rows]);folds=np.array([r['fold'] for r in rows])
def model(kind):
    word=TfidfVectorizer(ngram_range=(1,2),min_df=1,sublinear_tf=True,max_features=18000)
    vec=word if kind=='word_lr' else FeatureUnion([('word',word),('char',TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),sublinear_tf=True,max_features=30000))])
    return Pipeline([('tfidf',vec),('clf',LogisticRegression(class_weight='balanced',solver='liblinear',max_iter=2000,random_state=20261007))])
records=[];log=[]
for kind in ['word_lr','word_char_lr']:
    for fold in range(5):
        train=np.where(folds!=fold)[0];test=np.where(folds==fold)[0]
        cv=StratifiedGroupKFold(3,shuffle=True,random_state=20261007+fold)
        assert not set(g[train])&set(g[test])
        search=GridSearchCV(model(kind),{'clf__C':[.1,1.,10.]},cv=cv,scoring='balanced_accuracy',n_jobs=1,error_score='raise')
        t=time.monotonic();search.fit(X[train],y[train],groups=g[train]);p=search.predict_proba(X[test])[:,1]
        log.append({'model':kind,'fold':fold,'train_n':len(train),'test_n':len(test),'best_C':search.best_params_['clf__C'],'inner_balanced_accuracy':search.best_score_,'seconds':time.monotonic()-t})
        for i,prob in zip(test,p):records.append({'case_id':rows[i]['case_id'],'model':kind,'prob_eligible':float(prob),'binary_prediction':int(prob>=.5),'fold':fold})
        print(kind,fold,'complete',flush=True)
# Temporal sensitivity removes train members sharing a group with later test cases.
test=np.array([i for i,r in enumerate(rows) if r['date']>='2023-01-01'])
testgroups=set(g[test]);train=np.array([i for i,r in enumerate(rows) if r['date']<'2023-01-01' and g[i] not in testgroups])
chrono={'train_n':len(train),'test_n':len(test),'train_class_counts':np.bincount(y[train],minlength=2).tolist(),'test_class_counts':np.bincount(y[test],minlength=2).tolist(),'shared_group_removal':True}
if len(train)>=20 and min(np.bincount(y[train],minlength=2))>=4:
    search=GridSearchCV(model('word_char_lr'),{'clf__C':[.1,1.,10.]},cv=StratifiedGroupKFold(3,shuffle=True,random_state=20261007),scoring='balanced_accuracy',n_jobs=1)
    search.fit(X[train],y[train],groups=g[train]);p=search.predict_proba(X[test])[:,1]
    chrono['best_C']=search.best_params_['clf__C'];chrono['predictions']=[{'case_id':rows[i]['case_id'],'prob_eligible':float(prob),'prediction':int(prob>=.5)} for i,prob in zip(test,p)]
else:chrono['status']='insufficient_training_class_support_after_group_purge'
(ROOT/'results'/'benchmark_classical.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records),encoding='utf8')
(ROOT/'results'/'classical_training_log.json').write_text(json.dumps(log,indent=2),encoding='utf8')
(ROOT/'results'/'chronological_sensitivity.json').write_text(json.dumps(chrono,indent=2),encoding='utf8')
print('COMPLETE',chrono['train_n'],chrono['test_n'])
