"""End-to-end acquisition QA on raw responses and derived records."""
import collections, hashlib, json, re, stat
from pathlib import Path

R=Path(__file__).resolve().parents[1]
manifests=sorted(set((R/'datasets').glob('cbp_manifest_*.json'))|set((R/'datasets').glob('cbp_*_manifest_*.json')))
index_paths=sorted((R/'datasets').glob('cbp_*index_*.json'))
wanted=set()
query_checks=[]
for p in index_paths:
    idx=json.loads(p.read_text('utf-8'));wanted.update(idx['detail_order'])
    for q in idx['queries']:
        query_checks.append({'query':q['query'],'total':q['reported_total'],'retrieved':q['retrieved'],'unique':q['unique'],'pass':q['reported_total']==q['retrieved']==q['unique']})
records=[json.loads(x) for x in (R/'datasets'/'cbp_rulings_derived.jsonl').read_text('utf-8').splitlines()]
ids=[r['rulingNumber'] for r in records]
errors=[]; raw_count=0;byte_count=0
for p in manifests:
    m=json.loads(p.read_text('utf-8'))
    for response in m['responses']:
        raw=Path(response['path']);raw_count+=1
        if not raw.exists():errors.append({'type':'missing_raw','path':str(raw)});continue
        b=raw.read_bytes();byte_count+=len(b)
        if hashlib.sha256(b).hexdigest()!=response['sha256']:errors.append({'type':'sha256_mismatch','path':str(raw)})
        if len(b)!=response['bytes']:errors.append({'type':'length_mismatch','path':str(raw)})
        if raw.stat().st_mode&stat.S_IWRITE:errors.append({'type':'raw_not_readonly','path':str(raw)})
for r in records:
    if not r.get('text','').strip():errors.append({'type':'empty_text','id':r['rulingNumber']})
    raw=json.loads(Path(r['raw_path']).read_text('utf-8'))
    if raw.get('rulingNumber')!=r['rulingNumber']:errors.append({'type':'id_mismatch','id':r['rulingNumber']})
    if raw.get('text')!=r['text']:errors.append({'type':'text_changed','id':r['rulingNumber']})
    if not ('2018-01-01'<=r['rulingDate'][:10]<='2026-10-07'):errors.append({'type':'out_of_frame_date','id':r['rulingNumber']})
summary={
    'status':'pass' if not errors and not(wanted-set(ids)) and len(ids)==len(set(ids)) and all(q['pass'] for q in query_checks) else 'issues',
    'search_index_files':[str(p) for p in index_paths],'manifest_files':[str(p) for p in manifests],
    'search_query_checks':query_checks,'expected_unique_rulings':len(wanted),'observed_records':len(ids),'unique_ids':len(set(ids)),
    'missing_ids':sorted(wanted-set(ids)),'extra_ids':sorted(set(ids)-wanted),'errors':errors,
    'raw_responses_verified':raw_count,'raw_response_bytes':byte_count,
    'collections':dict(collections.Counter(r['collection'] for r in records)),
    'date_range':[min(r['rulingDate'][:10] for r in records),max(r['rulingDate'][:10] for r in records)],
    'year_counts':dict(sorted(collections.Counter(r['rulingDate'][:4] for r in records).items())),
}
p=R/'datasets'/'cbp_validation.json';p.write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
