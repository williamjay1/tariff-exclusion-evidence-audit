"""Collect immutable official CROSS responses and normalize derived records.

No access-control bypass. Uses endpoints called by the public CROSS frontend.
All network responses are new files under F:; derived records are under D:.
"""
from __future__ import annotations
import argparse, concurrent.futures, datetime as dt, hashlib, json, math, os
from pathlib import Path
import re, threading, time
import requests

ROOT=Path(__file__).resolve().parents[1]
RAW=Path(r'F:\AcademicData\tariff_scope_20261007\raw\cbp')
BASE='https://rulings.cbp.gov'
LOCK=threading.Lock()
LAST=0.0
RATE=0.60
STAMP=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
RUN=RAW/STAMP
MAN=[]

def get(url, params=None):
    global LAST
    for attempt in range(3):
        with LOCK:
            wait=RATE-(time.monotonic()-LAST)
            if wait>0: time.sleep(wait)
            LAST=time.monotonic()
        try:
            r=requests.get(url,params=params,timeout=90,headers={'User-Agent':'AcademicTariffScopeResearch/1.0 (public data collection)'})
            if r.status_code in (401,403,429):
                raise RuntimeError(f'Access/rate limit: HTTP {r.status_code}; stopping instead of bypassing')
            r.raise_for_status()
            return r
        except (requests.Timeout,requests.ConnectionError):
            if attempt==2: raise
            time.sleep(2**attempt)

def save_response(r,relative,query=None):
    p=RUN/relative
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f: f.write(r.content)
    p.chmod(0o444)
    row={'url':r.url,'retrieved_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'path':str(p),'status':r.status_code,'bytes':len(r.content),'sha256':hashlib.sha256(r.content).hexdigest(),'query':query}
    with LOCK: MAN.append(row)
    return p

def fetch_search(term):
    rows=[]; pages=[]; reported=None
    slug=re.sub(r'[^a-zA-Z0-9]+','_',term).strip('_')
    page=1
    while True:
        params={'term':term,'fromDate':'2018-01-01','toDate':'2026-10-07','pageSize':100,'page':page,'sortBy':'DATE_ASC'}
        r=get(BASE+'/api/search',params)
        save_response(r,f'search/{slug}_{page:03d}.json',params)
        d=r.json(); reported=d['totalHits']; batch=d.get('rulings',[])
        pages.append({'page':page,'n':len(batch),'reported_total':reported})
        rows.extend(batch)
        if page>=math.ceil(reported/100) or not batch: break
        page+=1
    print(f'SEARCH {term!r}: total={reported}, retrieved={len(rows)}, unique={len(set(x["rulingNumber"] for x in rows))}',flush=True)
    return rows,{'query':term,'pages':pages,'reported_total':reported,'retrieved':len(rows),'unique':len(set(x['rulingNumber'] for x in rows))}

def normalize(d,p):
    # Preserve text verbatim. Do not clean mojibake into guessed legal wording.
    row={k:v for k,v in d.items() if k!='url'}
    row.update({'official_url':BASE+'/ruling/'+d['rulingNumber'],'raw_path':str(p),'retrieved_run':STAMP})
    text=row.get('text','')
    heads=list(re.finditer(r'(?im)(?:^|\n|\r)\s*(FACTS?|ISSUES?|LAW\s+AND\s+ANALYSIS|ANALYSIS|HOLDING)\s*:',text))
    row['sections']={}
    for i,m in enumerate(heads):
        end=heads[i+1].start() if i+1<len(heads) else len(text)
        row['sections'][re.sub(r'\s+',' ',m.group(1).upper())]=text[m.end():end].strip()
    row['derived_screen']={
        'has_301':bool(re.search(r'Section\s+301|9903\.88\.',text,re.I)),
        'has_exclusion':bool(re.search(r'exclu(?:sion|ded|de)',text,re.I)),
        'subject_exclusion':bool(re.search(r'exclu|exempt',row.get('subject',''),re.I)),
        'text_chars':len(text),
        'has_replacement_character':'\ufffd' in text,
    }
    return row

def fetch_detail(rid):
    r=get(BASE+'/api/ruling/'+rid)
    p=save_response(r,'rulings/'+rid+'.json')
    d=r.json()
    if not d.get('rulingNumber') or not d.get('text'):
        raise ValueError(f'Invalid detail response for {rid}')
    return normalize(d,p)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--max-details',type=int,default=100000); ap.add_argument('--workers',type=int,default=3); args=ap.parse_args()
    RUN.mkdir(parents=True,exist_ok=False)
    (ROOT/'datasets').mkdir(parents=True,exist_ok=True)
    (ROOT/'research').mkdir(parents=True,exist_ok=True)
    r=get(BASE+'/api/app-config'); save_response(r,'app_config.json')
    allrows={}; query_manifest=[]
    # Singular and plural differ in this search engine; retain both.
    for term in ['301 AND exclusion','301 AND exclusions','301 AND exempt','301 AND exclude']:
        rows,meta=fetch_search(term); query_manifest.append(meta)
        for row in rows:
            rid=row['rulingNumber']
            if rid not in allrows: allrows[rid]={**row,'queries':[]}
            allrows[rid]['queries'].append(term)
    # Include cases known independently of this lexical query to check recall.
    known=['H338585','H330938','H342570','H342571','H341677','H319100','N341609','H316644','H317391','H325770','H320198']
    order=sorted(allrows,key=lambda k:(not bool(re.search(r'exclu|exempt',allrows[k]['subject'],re.I)),allrows[k]['collection']!='hq',allrows[k]['rulingDate']))
    order=list(dict.fromkeys(known+order))[:args.max_details]
    index_path=ROOT/'datasets'/f'cbp_search_index_{STAMP}.json'
    index_path.write_text(json.dumps({'run':STAMP,'queries':query_manifest,'rulings':list(allrows.values()),'detail_order':order},ensure_ascii=False,indent=2),encoding='utf-8')
    output=ROOT/'datasets'/f'cbp_rulings_{STAMP}.jsonl'
    failures=[]
    with output.open('x',encoding='utf-8') as f:
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
            for i,(rid,future) in enumerate(zip(order,[pool.submit(fetch_detail,x) for x in order])):
                try:
                    row=future.result()
                    f.write(json.dumps(row,ensure_ascii=False)+'\n'); f.flush()
                    if i<20 or (i+1)%50==0: print(f'DETAIL {i+1}/{len(order)} {rid} chars={len(row["text"])} subject={row.get("subject","")[:80]}',flush=True)
                except Exception as e:
                    failures.append({'rulingNumber':rid,'error':str(e)})
                    print(f'FAIL {rid}: {e}',flush=True)
    manifest={'run':STAMP,'base':BASE,'search_queries':query_manifest,'search_unique':len(allrows),'detail_requested':len(order),'detail_failed':failures,'dataset':str(output),'responses':MAN}
    manifest_path=ROOT/'datasets'/f'cbp_manifest_{STAMP}.json'
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    raw_manifest=RUN/'manifest.json'
    with raw_manifest.open('x',encoding='utf-8') as f: json.dump(manifest,f,ensure_ascii=False,indent=2)
    raw_manifest.chmod(0o444)
    print(json.dumps({'completed':True,'rulings':len(order)-len(failures),'failures':len(failures),'dataset':str(output),'manifest':str(manifest_path),'raw':str(RUN)},indent=2),flush=True)

if __name__=='__main__': main()
