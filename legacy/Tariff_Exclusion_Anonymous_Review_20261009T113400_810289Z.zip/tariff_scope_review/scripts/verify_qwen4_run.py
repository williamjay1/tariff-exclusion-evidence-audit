"""Execution/provenance checks only; no accuracy or model selection."""
import json,hashlib,math
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[1]
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def body(prompt):return prompt.split('<|im_start|>user\n',1)[1].split('<|im_end|>',1)[0]
def main():
    audits={}
    for stem,n in [('benchmark',86),('stress',480)]:
        dataset=ROOT/f'datasets/{stem}.jsonl';out=ROOT/f'results/{stem}_qwen4.jsonl'
        expected=read(dataset);r=read(out);old={x['case_id']:x for x in read(ROOT/f'results/{stem}_qwen.jsonl')}
        meta=json.loads(out.with_suffix('.meta.json').read_text(encoding='utf-8'))
        run=json.loads(out.with_suffix('.run.json').read_text(encoding='utf-8'))
        assert len(r)==n and len({x['case_id'] for x in r})==n
        assert {x['case_id'] for x in r}=={x['case_id'] for x in expected}
        assert meta['dtype']==run['dtype']=='bfloat16'
        assert meta['input_sha256']==run['input_sha256']==sha(dataset)
        assert run['model_revision']=='cdbee75f17c01a7cc42f958dc650907174af0554'
        for x in r:
            p=[x[k] for k in ['prob_eligible','prob_ineligible','prob_unknown']]
            assert all(math.isfinite(z) and 0<=z<=1 for z in p)
            assert abs(sum(p)-1)<1e-6
            assert x['binary_prediction']==int(p[0]>=p[1])
            assert x['selective_prediction']==[1,0,-1][max(range(3),key=lambda k:p[k])]
            assert body(x['prompt'])==body(old[x['case_id']]['prompt'])
        audits[stem]={'n':n,'unique_case_ids':n,'all_finite_normalized_scores':True,'correct_score_to_option_mapping':True,
                      'all_user_messages_exactly_match_original_small_model':True,'model_native_chat_template_can_differ':True,
                      'input_hash_matches':True,'output_sha256':sha(out),'run_fingerprint':run}
        if stem=='stress':
            groups=defaultdict(list)
            for x in r:groups[body(x['prompt'])].append(x)
            dup=[g for g in groups.values() if len(g)>1]
            detail=[]
            for g in dup:
                spread=max(max(x[k] for x in g)-min(x[k] for x in g) for k in ['prob_eligible','prob_ineligible','prob_unknown'])
                detail.append({'case_ids':[x['case_id'] for x in g],'max_conditional_score_spread':spread,
                    'same_binary':len({x['binary_prediction'] for x in g})==1,
                    'same_selective':len({x['selective_prediction'] for x in g})==1})
            audits[stem]['identical_input_repetitions']={'unique_user_inputs':len(groups),'duplicate_groups':len(dup),
                'maximum_conditional_score_spread':max((d['max_conditional_score_spread'] for d in detail),default=0),
                'all_binary_choices_agree':all(d['same_binary'] for d in detail),
                'all_selective_choices_agree':all(d['same_selective'] for d in detail),'details':detail}
            assert all(x['latency_kind']==meta['latency_kind'] for x in r)
            assert all(abs(x['seconds']*x['batch_size_actual']-x['batch_wall_seconds'])<1e-8 for x in r)
            audits[stem]['latency_allocation_consistent']=True
    before=json.loads((ROOT/'results/qwen4_prior_result_hashes.json').read_text(encoding='utf-8'))
    assert all(sha(ROOT/name)==v for name,v in before.items())
    hashes=json.loads((ROOT/'results/qwen4_official_weight_hash_check.json').read_text(encoding='utf-8'))
    assert len(hashes['weights'])==3 and all(x['match'] for x in hashes['weights'])
    result={'completed_execution_checks':True,'prior_results_unchanged':True,'official_pinned_weight_hashes_match':True,
            'audit_scope':'Execution/provenance and repeated-input numerical consistency; no reference labels are used to select or score models.','datasets':audits}
    (ROOT/'results/qwen4_execution_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:{'n':v['n'],'repetitions':v.get('identical_input_repetitions',{})} for k,v in audits.items()},indent=2))
if __name__=='__main__':main()
