"""Recover transiently failed public requests into a new immutable raw run."""
import json,re
import collect_cbp as c

c.RATE=1.5
indexes=sorted((c.ROOT/'datasets').glob('cbp_*index_*.json'))
wanted=set()
for p in indexes:wanted.update(json.loads(p.read_text('utf-8')).get('detail_order',[]))
present=set()
for p in (c.ROOT/'datasets').glob('cbp_*.jsonl'):
    if not re.fullmatch(r'cbp_(?:rulings|supplement|recovery)_\d{8}T\d{6}Z\.jsonl',p.name):continue
    for line in p.read_text('utf-8').splitlines():
        try:present.add(json.loads(line)['rulingNumber'])
        except json.JSONDecodeError:pass
missing=sorted(wanted-present)
print('Missing requests',len(missing),missing,flush=True)
if not missing:raise SystemExit(0)
c.RUN.mkdir(parents=True,exist_ok=False)
out=c.ROOT/'datasets'/f'cbp_recovery_{c.STAMP}.jsonl'
fail=[]
with out.open('x',encoding='utf-8') as f:
    for rid in missing:
        try:
            row=c.fetch_detail(rid);f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush();print('RECOVERED',rid,flush=True)
        except Exception as e:
            fail.append({'rulingNumber':rid,'error':str(e)});print('FAIL',rid,str(e),flush=True)
            if 'Access/rate limit' in str(e):break
manifest={'run':c.STAMP,'detail_requested':len(missing),'detail_failed':fail,'dataset':str(out),'responses':c.MAN}
mp=c.ROOT/'datasets'/f'cbp_recovery_manifest_{c.STAMP}.json'
mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
raw=c.RUN/'manifest.json'
with raw.open('x',encoding='utf-8') as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
raw.chmod(0o444)
