"""Auditable partial numeric parser, not a general legal reasoner.

Unsupported or ambiguous values return unknown, never fabricated facts.
Written before primary evaluation; rule IDs/outcomes are not used.
"""
import re,math
from decimal import Decimal

NUM=r'(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?'
UNIT=r'(?:cm3|cc|amperes?|amps?|A|kilograms?|kg|grams?|g|millimeters?|mm|centimeters?|cm|meters?|metres?|m|kilowatts?|kW|watts?|W|volts?|V|liters?|litres?|L|milliliters?|ml|percent|%)'
MAPPING={
 'kg':('mass',1000.,'g'),'kilogram':('mass',1000.,'g'),'g':('mass',1.,'g'),'gram':('mass',1.,'g'),
 'mm':('length',1.,'mm'),'millimeter':('length',1.,'mm'),'cm':('length',10.,'mm'),'centimeter':('length',10.,'mm'),
 'm':('length',1000.,'mm'),'meter':('length',1000.,'mm'),'metre':('length',1000.,'mm'),
 'w':('power',1.,'W'),'watt':('power',1.,'W'),'kw':('power',1000.,'W'),'kilowatt':('power',1000.,'W'),
 'v':('voltage',1.,'V'),'volt':('voltage',1.,'V'),'l':('volume',1.,'L'),'liter':('volume',1.,'L'),'litre':('volume',1.,'L'),
 'ml':('volume',.001,'L'),'milliliter':('volume',.001,'L'),'percent':('fraction',1.,'%'),'%':('fraction',1.,'%'),
 '$':('value',1.,'USD'),'usd':('value',1.,'USD')}
MAPPING.update({'a':('current',1.,'A'),'amp':('current',1.,'A'),'ampere':('current',1.,'A'),'cm3':('volume',.001,'L'),'cc':('volume',.001,'L')})

def number(s):return Decimal(s.replace(',',''))
def normalize_unit(u):
    u=u.lower().strip()
    if u not in MAPPING:u=u.rstrip('s')
    x=MAPPING.get(u)
    return None if x is None else (x[0],Decimal(str(x[1])),x[2])

def attribute(unit,context,number_position):
    dim,scale,base=normalize_unit(unit)
    if dim=='mass':
        # Capacity and own mass are distinct quantities even when both use kg.
        local=context[max(0,number_position-50):number_position+25]
        if re.search(r'\b(?:capacity|load|maximum weighing capacity)\b',local,re.I):return 'mass_capacity'
        return 'weight'
    if dim!='length':return {'fraction':'percentage'}.get(dim,dim)
    opts=[]
    for name,pat in [('diameter',r'\bdiameter\b'),('height',r'\b(?:height|high|tall)\b'),('width',r'\b(?:width|wide)\b'),('length',r'\b(?:length|long)\b'),('thickness',r'\b(?:thickness|thick)\b'),('depth',r'\b(?:depth|deep)\b')]:
        for m in re.finditer(pat,context,re.I):
            distance=min(abs(m.start()-number_position),abs(m.end()-number_position))
            if distance<=70:opts.append((distance,name))
    if not opts:return 'dimension'
    return sorted(opts)[0][1]

def bounds(op,v):
    s=re.sub(r'\s+',' ',op.lower())
    s=re.sub(r'^no\b','not',s)
    if s in ('at least','not less than','not under'):return v,True,None,None
    if s in ('more than','over','exceeding','greater than'):return v,False,None,None
    if s in ('less than','under'):return None,None,v,False
    return None,None,v,True

OPS=r'(?:(?:not|no)\s+(?:more than|less than|greater than|exceeding|over|under)|at least|more than|less than|greater than|exceeding|over|under)'

def parse_constraints(scope):
    # Statistical codes and dates are not physical dimensions.
    scope=re.split(r'\(\s*(?:as )?described',scope,flags=re.I)[0]
    cs=[];occupied=[]
    def add(start,end,unit,v1,op1,v2=None,op2=None,unit2=None):
        if re.match(r'[²³/^]|\s+per\s',scope[end:]):return
        norm=normalize_unit(unit)
        if not norm:return
        dim,scale,base=norm
        a=attribute(unit,scope,start)
        lo,li,hi,ui=bounds(op1,number(v1)*scale)
        if v2 is not None:
            norm2=normalize_unit(unit2 or unit)
            if norm2[0]!=dim:return
            l2,li2,h2,ui2=bounds(op2,number(v2)*norm2[1])
            if l2 is not None:lo,li=l2,li2
            if h2 is not None:hi,ui=h2,ui2
        cs.append({'attribute':a,'dimension':dim,'unit':base,'lower':lo,'lower_inclusive':li,'upper':hi,'upper_inclusive':ui,'quote':scope[start:end],'span':[start,end]})
        occupied.append((start,end))
    # Two-sided bounds, with or without repeated unit.
    pat=rf'(?P<op1>{OPS})\s*(?:\$\s*)?(?P<v1>{NUM})\s*(?P<u1>{UNIT})?\s*(?:but|and)\s*(?P<op2>{OPS})\s*(?:\$\s*)?(?P<v2>{NUM})\s*(?P<u2>{UNIT})?'
    for m in re.finditer(pat,scope,re.I):
        unit=m['u1'] or m['u2'] or ('$' if '$' in m[0] else None)
        if unit:add(m.start(),m.end(),unit,m['v1'],m['op1'],m['v2'],m['op2'],m['u2'] or unit)
    pat=rf'(?P<op>{OPS})\s*(?P<dollar>\$\s*)?(?P<v>{NUM})\s*(?P<u>{UNIT})?(?![A-Za-z])'
    for m in re.finditer(pat,scope,re.I):
        if any(a<=m.start()<b for a,b in occupied):continue
        unit='$' if m['dollar'] else m['u']
        if unit:add(m.start(),m.end(),unit,m['v'],m['op'])
    # Postposed lower bound is common in statutory descriptions.
    pat=rf'(?P<v>{NUM})\s*(?P<u>{UNIT})\s*or more'
    for m in re.finditer(pat,scope,re.I):
        if any(a<=m.start()<b for a,b in occupied):continue
        add(m.start(),m.end(),m['u'],m['v'],'at least')
    return cs

def extract_facts(text):
    vals=[];occupied=[]
    # Explicit closed ranges are intervals; they do not establish all members meet a threshold.
    pat=rf'(?:between\s+)?(?P<v1>{NUM})\s*(?:to|and|[-–—])\s*(?P<v2>{NUM})\s*(?P<u>{UNIT})(?![A-Za-z])'
    for m in re.finditer(pat,text,re.I):
        if re.match(r'[²³/^]|\s+per\s',text[m.end():]):continue
        norm=normalize_unit(m['u']);a=attribute(m['u'],text,m.start())
        lo,hi=sorted((number(m['v1'])*norm[1],number(m['v2'])*norm[1]))
        vals.append({'attribute':a,'dimension':norm[0],'unit':norm[2],'lower':lo,'upper':hi,'quote':m[0],'span':[m.start(),m.end()]});occupied.append((m.start(),m.end()))
    pat=rf'(?P<dollar>\$\s*)?(?P<v>{NUM})\s*(?P<u>{UNIT})?(?![A-Za-z])'
    for m in re.finditer(pat,text,re.I):
        if any(a<=m.start()<b for a,b in occupied):continue
        if re.match(r'[²³/^]|\s+(?:per\s|or (?:more|less))',text[m.end():]):continue
        unit='$' if m['dollar'] else m['u']
        if not unit:continue
        # Explicit uncertainty/comparisons are not point values.
        prefix=text[max(0,m.start()-25):m.start()]
        if re.search(r'(?:more than|less than|greater than|over|under|at least|exceeding|up to|approximately|about)\s*$',prefix,re.I):continue
        norm=normalize_unit(unit);v=number(m['v'])*norm[1]
        vals.append({'attribute':attribute(unit,text,m.start()),'dimension':norm[0],'unit':norm[2],'lower':v,'upper':v,'quote':m[0],'span':[m.start(),m.end()]})
    return vals

def satisfies(c,v):
    lo=c['lower'];hi=c['upper']
    return (lo is None or (v>=lo if c['lower_inclusive'] else v>lo)) and (hi is None or (v<=hi if c['upper_inclusive'] else v<hi))

def interval_state(c,f):
    lo,hi=f['lower'],f['upper']
    if satisfies(c,lo) and satisfies(c,hi):return 'pass'
    if c['lower'] is not None and (hi<c['lower'] or (hi==c['lower'] and not c['lower_inclusive'])):return 'fail'
    if c['upper'] is not None and (lo>c['upper'] or (lo==c['upper'] and not c['upper_inclusive'])):return 'fail'
    return 'unknown'

def verify_numeric(facts,rule):
    cs=parse_constraints(rule);vals=extract_facts(facts);trace=[]
    scope=re.split(r'\(\s*(?:as )?described',rule,flags=re.I)[0]
    raw_quantities=list(re.finditer(rf'(?:\$\s*{NUM}|{NUM}\s*{UNIT})(?![A-Za-z])',scope,re.I))
    unparsed=[m[0] for m in raw_quantities if not any(c['span'][0]<=m.start()<c['span'][1] for c in cs)]
    # Unsupported-unit comparisons remain visible as unknown predicates.
    for m in re.finditer(rf'{OPS}\s*(?:\$\s*)?{NUM}',scope,re.I):
        if not any(c['span'][0]<=m.start()<c['span'][1] for c in cs):unparsed.append(m[0])
    for c in cs:
        matches=[f for f in vals if f['attribute']==c['attribute'] and f['dimension']==c['dimension']]
        distinct={(f['lower'],f['upper']) for f in matches}
        state=interval_state(c,matches[0]) if len(distinct)==1 else 'unknown'
        trace.append({'constraint':c,'candidates':matches,'state':state})
    states=[x['state'] for x in trace]
    has_disjunction=len(cs)>1 and bool(re.search(r'\bor\b(?!\s+more)',scope[min(c['span'][0] for c in cs):max(c['span'][1] for c in cs)],re.I))
    if has_disjunction:state='unknown'
    elif 'fail' in states:state='fail'
    elif 'unknown' in states or unparsed:state='unknown'
    elif states:state='pass'
    else:state='not_parsed'
    return {'state':state,'trace':trace,'n_constraints':len(cs),'unparsed_quantities':unparsed,'unsupported_disjunction':has_disjunction}

if __name__=='__main__':
    # Toy checks test distinctions with legal consequences, not sample outcomes.
    r='Motors, of a power not exceeding 1,000 W'
    assert verify_numeric("The product's power is 1 kW.",r)['state']=='pass'
    assert verify_numeric("The product's power is 1.001 kW.",r)['state']=='fail'
    assert verify_numeric('The product is a motor.',r)['state']=='unknown'
    r='Glass rods, measuring at least 5 mm but not more than 10 mm in diameter'
    assert verify_numeric('The product diameter is 0.5 cm.',r)['state']=='pass'
    assert verify_numeric('The product diameter is 11 mm.',r)['state']=='fail'
    assert verify_numeric('The product diameter is 9 to 11 mm.',r)['state']=='unknown'
    assert verify_numeric('The width is 2 cm.','width at least 1 m but not more than 150 cm')['state']=='fail'
    assert verify_numeric('The weight is 11 kg.','weight no more than 10 kg')['state']=='fail'
    assert verify_numeric('The weight is 2 kg.','weight no less than 5 kg')['state']=='fail'
    assert verify_numeric('The weight is not more than 10 kg.','weight at least 5 kg but not more than 10 kg')['state']=='unknown'
    assert verify_numeric('The pressure is 8 psi.','pressure not over 10 psi')['state']=='unknown'
    assert verify_numeric('The weight is between 5 and 10 kg.','weight at least 8 kg')['state']=='unknown'
    assert verify_numeric('The weight is 10 kg or less.','weight at least 5 kg')['state']=='unknown'
    assert verify_numeric('The area is 1 m².','area not over 200 cm²')['state']=='unknown'
    assert verify_numeric('The scale capacity is 16 kg.','scales weighing not over 2 kg')['state']=='unknown'
    assert verify_numeric('The diameter is 5.7 mm.','diameter not over 0.57 cm')['state']=='pass'
    assert verify_numeric('Width is 6 cm; height is 8 cm.','width not over 5 cm or height not over 10 cm')['state']=='unknown'
    print('Boundary, unit-conversion and interval checks passed.')
