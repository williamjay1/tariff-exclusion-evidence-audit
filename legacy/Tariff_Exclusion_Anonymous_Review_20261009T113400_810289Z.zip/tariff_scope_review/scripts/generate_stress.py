"""Synthetic single-predicate cases from separately frozen source-coded bounds.
No evaluated parser is used to derive reference outcomes.
"""
from pathlib import Path
from decimal import Decimal
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
gold=list(map(json.loads,(ROOT/'datasets'/'numeric_rule_gold.jsonl').read_text(encoding='utf8').splitlines()))
CONVERT={'W':('kW',.001),'kW':('W',1000),'g':('kg',.001),'kg':('g',1000),'mm':('cm',.1),'cm':('mm',10),'m':('cm',100),'V':('V',1),'A':('A',1),'L':('ml',1000),'cm3':('ml',1)}
def fmt(v):return f'{v:.10f}'.rstrip('0').rstrip('.')
def truth(g,x):
    x=Decimal(str(x))
    lo=None if g['lower'] is None else Decimal(str(g['lower']))
    hi=None if g['upper'] is None else Decimal(str(g['upper']))
    if lo is not None and (x<lo or (x==lo and not g['lower_inclusive'])):return 0
    if hi is not None and (x>hi or (x==hi and not g['upper_inclusive'])):return 0
    return 1
rows=[]
for j,g in enumerate(gold):
    lo,hi=g['lower'],g['upper'];anchor=hi if hi is not None else lo
    delta=max(abs(anchor)*.01,.001)
    inside=(lo+hi)/2 if lo is not None and hi is not None else (hi*.8 if hi is not None else lo+delta*2)
    boundary=lo if lo is not None else hi
    outside=lo-delta if lo is not None else hi+delta
    outside2=hi+delta if hi is not None else lo-delta*2
    attr=g['attribute'].replace('_',' ')
    # Every object governed by this clause takes the stated value (e.g., both wheels).
    lead='For every relevant component or item, the '+attr+' is '
    tail='. All other product requirements are fixed and satisfied.'
    cases=[('inside',lead+fmt(inside)+' '+g['unit']+tail,truth(g,inside)),
           ('boundary',lead+fmt(boundary)+' '+g['unit']+tail,truth(g,boundary)),
           ('outside_lower_or_upper',lead+fmt(outside)+' '+g['unit']+tail,truth(g,outside)),
           ('outside_upper_or_lower',lead+fmt(outside2)+' '+g['unit']+tail,truth(g,outside2))]
    alt,factor=CONVERT[g['unit']]
    cases.extend([('converted_inside',lead+fmt(inside*factor)+' '+alt+tail,truth(g,inside)),
                  ('converted_outside',lead+fmt(outside*factor)+' '+alt+tail,truth(g,outside)),
                  ('missing',f'The {attr} has not been measured or reported. All other product requirements are fixed and satisfied.',-1),
                  ('straddling',lead+fmt(max(0,boundary-delta))+' to '+fmt(boundary+delta)+' '+g['unit']+tail,-1)])
    for k,(scenario,facts,y) in enumerate(cases):
        rows.append({'case_id':f'S{j:03d}_{k}','rule_id':g['rule_id'],'group':g['rule_id'],'scenario':scenario,'facts':facts,
                     'rule_text':g['clause'],'y':y,'synthetic':True,'other_conditions':'Fixed as satisfied; only the stated numeric predicate is evaluated.'})
out=ROOT/'datasets'/'stress.jsonl'
out.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf8')
meta={'n':len(rows),'rules':len(gold),'state_counts':{str(y):sum(r['y']==y for r in rows) for y in [-1,0,1]},
      'scenarios_per_rule':8,'gold_sha256':hashlib.sha256((ROOT/'datasets'/'numeric_rule_gold.jsonl').read_bytes()).hexdigest(),'stress_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
      'reference_computation':'Decimal comparisons against independently source-coded bounds; no evaluated parser calls.'}
(ROOT/'results'/'stress_manifest.json').write_text(json.dumps(meta,indent=2),encoding='utf8')
print(json.dumps(meta,indent=2))
