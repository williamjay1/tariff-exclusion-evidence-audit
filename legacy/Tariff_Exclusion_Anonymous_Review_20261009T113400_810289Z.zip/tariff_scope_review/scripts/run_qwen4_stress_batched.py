"""Resource-only batching preflight and complete fixed-prompt Qwen4 stress run.

The first four prescribed diagnostics compare identical inputs singly and with
left padding. Reference outcomes are never accessed to select the configuration.
"""
import os,sys,json,re,time,hashlib,math,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'deps'))
os.environ['HF_HOME']=str(ROOT/'cache/hf')
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TEMP']=os.environ['TMP']=str(ROOT/'temp')
os.environ['TOKENIZERS_PARALLELISM']='false'
import torch,numpy as np
from transformers import AutoTokenizer,AutoModelForCausalLM

INSTRUCTION=("Evaluate only whether the stated product facts satisfy the supplied exclusion description. "
             "This is a historical product-scope task. Origin, timing and any separately checked tariff code are held fixed. "
             "Use only the stated facts. A means all description requirements are established; "
             "B means at least one requirement is contradicted; C means missing facts prevent a decision. "
             "Answer with exactly one letter: A, B or C.\n\nPRODUCT FACTS:\n")
INDICES=[0,127,254,479]
MAX_ABSOLUTE_SCORE_DIFFERENCE=0.01
MIN_SPEEDUP=1.10

def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main(args=None):
    torch.set_num_threads(6);torch.set_num_interop_threads(2)
    torch.manual_seed(20261007);np.random.seed(20261007)
    path=ROOT/'cache/models/qwen4'
    prov=json.loads((path/'provenance.json').read_text(encoding='utf-8'))
    tok=AutoTokenizer.from_pretrained(path,local_files_only=True);tok.padding_side='left'
    if tok.pad_token_id is None:tok.pad_token=tok.eos_token
    start=time.monotonic()
    model=AutoModelForCausalLM.from_pretrained(path,local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa')
    model.eval();load_seconds=time.monotonic()-start
    actual_dtypes=sorted({str(p.dtype) for p in model.parameters()})
    assert actual_dtypes==['torch.bfloat16'],actual_dtypes
    inputs_path=ROOT/'datasets/stress.jsonl';rows=read(inputs_path)
    assert len(rows)==480
    prompts=[]
    for r in rows:
        # No reference y, ruling outcome, or identifier enters the prompt.
        scope=re.split(r'\(\s*(?:as )?described',r['rule_text'],flags=re.I)[0].strip()
        user=INSTRUCTION+r['facts']+'\n\nEXCLUSION DESCRIPTION:\n'+scope
        prompts.append(tok.apply_chat_template([{'role':'user','content':user}],tokenize=False,add_generation_prompt=True,enable_thinking=False))
    token_counts=[len(tok(p)['input_ids']) for p in prompts]
    assert max(token_counts)<=8192
    letters=[tok.encode(c,add_special_tokens=False) for c in ['A','B','C']]
    assert all(len(x)==1 for x in letters);letter_ids=[x[0] for x in letters]
    def forward(indices):
        start=time.monotonic()
        batch=tok([prompts[i] for i in indices],return_tensors='pt',padding=True)
        positions=batch['attention_mask'].long().cumsum(-1)-1
        positions.masked_fill_(batch['attention_mask']==0,0)
        with torch.inference_mode():
            logits=model(**batch,position_ids=positions).logits[:,-1,letter_ids]
            score=torch.softmax(logits.float(),dim=-1).numpy().astype(float)
        assert np.isfinite(score).all()
        return score,time.monotonic()-start,int(batch['input_ids'].shape[1])
    preflight_path=ROOT/'results/qwen4_stress_batch_preflight.json'
    out=ROOT/'results'/((getattr(args,'output',None) if args else None) or 'stress_qwen4.jsonl')
    runpath=out.with_suffix('.run.json')
    if runpath.exists():
        prior=json.loads(runpath.read_text(encoding='utf-8'))
        assert prior['input_sha256']==sha(inputs_path) and prior['model_revision']==prov['revision']
        assert prior['prompt_version']=='scope-v1' and prior['dtype']=='bfloat16'
        assert prior.get('batch_preflight_protocol')=='outcome-blind-resource-v1'
        batch_size=prior['batch_size']
        audit=json.loads(preflight_path.read_text(encoding='utf-8'))
    else:
        # Freeze decision thresholds in a separate file before model scores.
        plan={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'indices':INDICES,
              'candidate_batch_size':4,'padding_side':'left','position_ids':'attention_mask.cumsum(-1)-1; pad positions zero',
              'max_absolute_conditional_score_difference':MAX_ABSOLUTE_SCORE_DIFFERENCE,'min_throughput_speedup':MIN_SPEEDUP,
              'require_all_selective_argmax_and_binary_choices_unchanged':True,'labels_accessed':False,
              'timing_warmup':'one unused forward on first diagnostic input; then four single forwards and one batch of four',
              'decision':'Batch4 only if all criteria pass; otherwise keep single-case inference.'}
        (ROOT/'results/qwen4_stress_batch_plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
        _,warmup_seconds,_=forward([INDICES[0]])
        single=[];times=[]
        for i in INDICES:
            score,seconds,_=forward([i]);single.append(score[0]);times.append(seconds)
        single=np.array(single)
        batched,batch_seconds,padded_tokens=forward(INDICES)
        differences=np.abs(single-batched)
        same_argmax=np.argmax(single,axis=1)==np.argmax(batched,axis=1)
        same_binary=(single[:,0]>=single[:,1])==(batched[:,0]>=batched[:,1])
        speedup=sum(times)/batch_seconds
        use_batch=bool(same_argmax.all() and same_binary.all() and differences.max()<=MAX_ABSOLUTE_SCORE_DIFFERENCE and speedup>=MIN_SPEEDUP)
        batch_size=4 if use_batch else 1
        audit={'plan':plan,'model_revision':prov['revision'],'actual_parameter_dtypes':actual_dtypes,
              'warmup_seconds':warmup_seconds,'single_seconds':times,'batch_seconds':batch_seconds,'speedup':speedup,
              'maximum_absolute_score_difference':float(differences.max()),'same_selective_argmax':same_argmax.tolist(),
              'same_binary_choice':same_binary.tolist(),'batch_padded_length':padded_tokens,'selected_batch_size':batch_size,
              'decisions':[{'case_id':rows[i]['case_id'],'input_tokens':token_counts[i],
                 'single_scores':single[j].tolist(),'batch_scores':batched[j].tolist(),'absolute_difference':differences[j].tolist()} for j,i in enumerate(INDICES)]}
        preflight_path.write_text(json.dumps(audit,indent=2),encoding='utf-8')
        print('OUTCOME-BLIND BATCH PREFLIGHT',json.dumps({k:audit[k] for k in ['speedup','maximum_absolute_score_difference','same_selective_argmax','same_binary_choice','selected_batch_size']}),flush=True)
    fingerprint={'input_sha256':sha(inputs_path),'model':'qwen4','model_revision':prov['revision'],'prompt_version':'scope-v1',
       'dtype':'bfloat16','softmax_dtype':'float32','device':'cpu','transformers_context':8192,
       'batch_size':batch_size,'padding_side':'left','position_ids':'explicit attention mask cumulative indices',
       'batch_preflight_protocol':'outcome-blind-resource-v1','batch_preflight_sha256':sha(preflight_path)}
    if runpath.exists():assert json.loads(runpath.read_text(encoding='utf-8'))==fingerprint
    else:runpath.write_text(json.dumps(fingerprint,indent=2),encoding='utf-8')
    done={r['case_id'] for r in read(out)} if out.exists() else set()
    pending=[i for i,r in enumerate(rows) if r['case_id'] not in done]
    for start in range(0,len(pending),batch_size):
        indices=pending[start:start+batch_size];scores,seconds,padded=forward(indices)
        for j,i in enumerate(indices):
            p=scores[j].tolist()
            record={'case_id':rows[i]['case_id'],'model':'qwen4','prob_eligible':p[0],'prob_ineligible':p[1],'prob_unknown':p[2],
                'binary_prediction':int(p[0]>=p[1]),'selective_prediction':[1,0,-1][int(np.argmax(p))],
                'input_tokens':token_counts[i],'truncated':False,'seconds':seconds/len(indices),'prompt':prompts[i],
                'latency_kind':'allocated_batch_share' if batch_size>1 else 'single_example_forward',
                'batch_size_actual':len(indices),'batch_wall_seconds':seconds,'padded_tokens':padded,'padding_side':'left'}
            with out.open('a',encoding='utf-8') as f:f.write(json.dumps(record,ensure_ascii=False)+'\n')
        if start%(batch_size*5)==0:print('qwen4 stress',len(done)+start+len(indices),'/',len(rows),'batch',len(indices),'seconds',round(seconds,3),flush=True)
    meta={'torch':torch.__version__,'model':'qwen4','load_seconds':load_seconds,'threads':6,'dtype':'bfloat16','device':'cpu',
          'actual_parameter_dtypes':actual_dtypes,'input_sha256':sha(inputs_path),'model_provenance':prov,'batch_size':batch_size,
          'latency_kind':'allocated_batch_share' if batch_size>1 else 'single_example_forward','padding_side':'left',
          'position_ids':'explicit attention mask cumulative indices','preflight_file':preflight_path.name}
    out.with_suffix('.meta.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print('COMPLETE',out,flush=True)

if __name__=='__main__':main()
