# Method-code preflight review

Review date: 2026-10-07. Review of method code and `research/EXPERIMENT_PLAN.md`. The reviewer did not inspect model evaluation outputs, optimize thresholds against results, or change the frozen numeric gold. Review was read-only except for one explicitly authorized minimum edit: checking the pinned model revision when migrating an old NLI run without a fingerprint. The small counterexamples below are independently constructed grammar/arithmetic probes, not benchmark cases.

**Final code-preflight disposition: GO for the frozen, explicitly scoped experiments.** The initial consequential parser defects were repaired and their independent toy checks now pass. Nested training, reference-label generation, shared code gating, cluster resampling, and cost arithmetic have no fatal defect identified in the reviewed versions. This is a code/design preflight decision, not verification of the unseen numerical results or a submission-readiness decision. The limits below must constrain the manuscript claims.

## Findings requiring repair or an explicit comparison design

### P1. Predicate polarity, unit conversion, and incomplete evidence must not produce confident wrong answers

The initial numeric engine produced the following incorrect states in independent toy checks:

| Rule | Stated fact | Correct local state | Initial result |
|---|---|---|---|
| length at least 1 m and not more than 150 cm | length 2 cm | fail | pass; lower bound became 10 mm |
| weight no more than 10 kg | weight 11 kg | fail | pass; `no more` was parsed as `more` |
| weight no less than 5 kg | weight 2 kg | fail | pass; `no less` was parsed as `less` |
| weight from 5 through 10 kg | weight not more than 10 kg | unknown | pass; an upper bound became a point |
| weight at least 8 kg | weight between 5 and 10 kg | unknown | pass; only the upper endpoint was extracted |
| weight at least 5 kg | weight 10 kg or less | unknown | pass; postposed bound became a point |
| area not more than 200 cm² | area 1 m² | fail, or unknown if area unsupported | pass; square units were truncated to length units |
| scale mass not more than 2 kg | scale capacity 16 kg | unknown | fail; capacity was identified as self-weight |
| width not more than 0.57 cm | width 5.7 mm | pass | fail due to binary floating-point conversion |
| width <= 5 cm OR height <= 10 cm | width 6 cm, height 8 cm | pass, or unknown if OR unsupported | fail; alternatives were conjoined |

Final repairs observed in source include separate scaling for each bound, `no` polarity, explicit comparative fact guards, extra supported units, unsupported-prefix-comparison detection, Decimal comparisons, compound-unit rejection, separation of mass capacity from own mass, and referral for detected numerical disjunctions. All counterexamples above are now covered by passing toy checks. The engine remains a partial parser, not a proof of conservative behavior for every possible natural-language construction. Capacity, areal density, input/output power, and total/individual mass cannot be identified from the unit alone; unsupported semantic distinctions remain a stated boundary.

Exact decimal arithmetic is appropriate for closed/open thresholds. A broad epsilon must not silently turn a strict upper or lower bound into an inclusive one. Decimal traces also need an explicit JSON encoding policy; otherwise logging a correct prediction can fail with a serialization error.

Primary code locations: `constraint_engine.py`, `parse_constraints`, `extract_facts`, `attribute`, `interval_state`, and `verify_numeric`.

### P1. Resume-by-case-ID can attach old predictions to a changed input

At initial review, `run_neural.py` line 29 skips any existing `case_id`, regardless of input text, model files, prompt version, tokenizer, or scoring method. Its final metadata then records the **current** input SHA. If an annotation or prompt is corrected and the same output path is reused, stale predictions can be silently presented as predictions from the new input.

Required repair: freeze and verify a run fingerprint before resuming. It should cover at least dataset SHA, pinned model provenance, tokenizer/prompt/scoring version, and relevant execution settings. A mismatch should require a new output path or explicit restart. A row-level input hash is additionally useful. Do not rewrite final metadata to certify a mixed run.

### P1. Tariff information must be shared fairly when estimating a condition-checking increment

`prepare_benchmark.py` supplies product/rule codes and derives a code-match variable. The reviewed benchmark has code-mismatch cases. `run_neural.py` strips the described-in code parenthesis and feeds only product facts plus natural-language scope; its Qwen prompt explicitly holds separately checked codes fixed. If the hybrid alone receives a code-mismatch veto, its improvement over the raw neural baseline includes extra structured code information, not only numerical or missing-fact handling.

Acceptable designs include applying the same code gate to every semantic baseline and separately reporting the incremental numeric/abstention layer; or making the same-code task primary, with cross-code candidate rejection as a separate stage. Retaining an ungated model is useful as an ablation, provided the information difference is explicit. This is an attribution issue, not an instruction to discard inconvenient cases.

### P1/P2. Candidate rule codes cannot be inferred from every code mentioned in the description

The initial fallback `rule_hts=re.findall(...,rule)` in `prepare_benchmark.py` collects all 8–10 digit code strings. A description such as “housings for water pumps of subheading 8413.30.90 (as described in subheading 8413.91.9010)” refers to the pump code in its prose but covers housings under the latter code. Treating both as candidate coverage can falsely admit an unrelated product code.

Required repair: use independently annotated rule codes or extract only the statutory `described in` coverage locator, retaining explicitly stated historical-version alternatives. Preserve product-code provenance separately; codes inferred from the holding/analysis must not be reclassified as pre-analysis factual inputs.

The prefix comparison itself is an intentionally coarse comparator: agreement between an 8-digit product code and a 10-digit rule code is **prefix consistency**, not proven exact 10-digit eligibility. Report exact matches, compatible partial codes, mismatches, and unavailable codes distinctly. Any hybrid claim that assumes correct exact code coverage needs the stronger subset/gate.

## Checks that passed or are acceptable with the recorded limits

- Neural calls explicitly consume `facts` and `rule_text`, not the `y`, case ID, title, date, source annotation note, or reference disposition fields in the JSON input.
- A literal outcome-term scan of supplied fact passages did not expose an explicit copied eligibility/denial conclusion; matches such as “subject to this protest” were not themselves outcome leakage.
- The local NLI checkpoint config confirms the assumed label order: contradiction, entailment, neutral.
- The document/ruling and curated rule-family grouping is combined transitively with near-duplicate rule/fact similarity. Keeping all products from a ruling together is correct.
- Global unsupervised text similarity used solely to define duplicate groups is acceptable data curation, provided learned model features are fitted on training folds only. It should not be described as the model's TF-IDF training.
- Five outer folds in the inspected design each contain both outcome classes. One fold has only three independent groups, despite having seventeen rows; therefore row counts must not be mistaken for the effective independent sample size. Report group counts and cluster-aware uncertainty.
- NLI premise truncation is explicitly recorded. A truncated baseline is valid as a resource-limited comparator, but claims should not imply it saw all the product facts. If the hypothesis alone exceeds its context, `truncation='only_first'` can fail and needs an explicit failure record.
- Qwen uses restricted next-token scoring over A/B/C, not unconstrained answer generation. These normalized three-token scores are not automatically calibrated legal probabilities.
- The protocol acknowledges public-source pretraining contamination cannot be excluded; date splitting alone does not establish uncontaminated pretrained evaluation.
- Keeping underdetermined factual inputs in the audit is preferable to silently supplying facts from the legal analysis. Observed CBP disposition and sufficiency of the model-visible evidence must remain distinct.

## Protocol wording to align before manuscript drafting

- Use “false exemption” or “false eligibility” consistently for predicted eligible among reference ineligible. The current plan alternates this with “false exclusion,” which is easy to misread.
- The rule census and synthetic numeric test must remain separate from observed CBP prediction results.
- Any unsupported predicate should produce unknown/referral at the applicable stage, rather than be described as verified compliance.
- A frozen compact generative model is a resource-constrained baseline; it is not evidence that a proposed system dominates current frontier LLMs.

## Repair verification and remaining script reviews

### Repaired engine, inputs, and model resumption

- Executed the repaired engine's toy assertions, including the independently raised mixed-unit, polarity, incomplete interval, compound-unit, quantity-type, exact boundary, and disjunction examples. All passed. The evaluated engine was not run on the numeric gold by this reviewer.
- `prepare_benchmark.py` now limits rule-code fallback extraction to the statutory `described in` locator. This removes the previously identified confusion between a component's code and a code mentioned for its parent product.
- `run_neural.py` now records and checks dataset SHA, pinned model revision, prompt version, context limit, dtype, and device before resumption. The legacy NLI migration additionally compares the old input SHA and every stored prompt. The reviewer added an explicit equality assertion for the old versus current pinned model revision; independent toy metadata checks confirmed equal revisions are accepted and changed/missing revisions are rejected. Syntax was checked without loading or rerunning model predictions.
- Prompt/scoring version is a manual provenance commitment. A later prompt or scoring change must increment it or use a new output file. No fingerprint can certify arbitrary unrecorded changes to a local checkpoint.

### Nested classical training

`run_classical.py` fits TF-IDF and logistic regression inside one scikit-learn pipeline. Each outer test fold is excluded from vocabulary/IDF fitting, coefficient estimation, and hyperparameter choice. The search over C = 0.1, 1, 10 uses three inner grouped folds on the outer training partition only. Both word-only and word-plus-character models use the same outer assignment. No held-out score is used to select a model or threshold in the reviewed script.

An independent structural check reproduced all five outer and fifteen inner partitions. Every train/validation/test partition had both classes, and every checked train/test or train/validation pair had disjoint group IDs. Outer test fold sizes were 17, 18, 17, 17, and 17; independent group counts were 3, 11, 11, 9, and 11. The benchmark contains 86 pairs, 77 rulings, and 45 groups, with 73 prefix-compatible code pairs, 12 mismatches, and one unavailable code comparison.

The fixed 2023 cutoff sensitivity removes earlier rows whose group appears in the later test set. Independent recomputation gives 41 training rows (12 ineligible, 29 eligible) and 28 test rows (22 ineligible, 6 eligible), with no group overlap. This supports running the recorded sensitivity but does not make its six positive test observations precise. The temporal split is a sensitivity analysis, not proof that pretrained models have never seen a source document. Full resumption protection is not needed for classical runs because that script rewrites a complete result file rather than appending by case ID; the final archive should nevertheless preserve its input/script hashes and package versions.

### Independent synthetic reference validation

The independent audit script `scripts/cbp_preflight_checks.py` loads only the source-coded gold, the generated input cases, and the benchmark design. It does not import the evaluated numeric parser or read model predictions. It parses the numerical strings actually displayed in each generated fact, converts units with exact `fractions.Fraction` arithmetic, compares against independently source-coded bounds, and checks that an unknown interval straddles the reference boundary. This is separate from the generator's Decimal truth function, including a check against possible formatting or floating-point generation errors.

All **480 scenario-row reference labels match** that independent calculation. There are 60 rules and eight scenarios per rule; rule text and group IDs match the frozen gold. The numeric-gold SHA remains `55c9dd4f3636a2c9adfc74efcd87bfd507933149de06fcc32cb10115113af804`.

The following distinctions are necessary when reporting this test:

- There are **443 distinct rule/fact/label inputs**, not 480 distinct product specifications. The 37 repeated rows arise from coincident outside scenarios for upper-only rules and identity conversion controls. Retaining the recorded eight-scenario design gives each rule the same row weight, but does not create additional independent evidence.
- Of 120 rows named converted-inside or converted-outside, **112 change units and eight are identity controls** for V/A rules. Report them accordingly; do not call all 120 genuine unit conversions.
- The exact-boundary scenario uses the lower endpoint when both endpoints exist. Upper endpoints in those rules are bracketed by inside/outside examples, but not each tested at exact equality. The design does not exhaustively test every endpoint.
- Other legal requirements are explicitly fixed as satisfied, and the text applies the measurement to every relevant component/item. Success supports local numeric-predicate execution, not full exclusion entitlement, realistic measurement uncertainty, or an additional set of real CBP adjudications.
- Variants from one source rule share one group. No model is fitted on these stress rows in the reviewed design; any future training would need to retain rule-group separation and consider shared clause families as well.

Machine-readable structural checks are saved in `research/cbp_preflight_checks.json`. These are reference/design validation outputs, not model-performance results.

### Analysis logic, fairness, uncertainty, and costs

The reviewer also read `analyze_experiments.py` without executing it or opening any prediction/result file.

1. **Shared information:** Both frozen neural models and both classical models receive the same code-mismatch veto in the analysis. Primary reporting uses the 73 prefix-compatible pairs; additional all-known-code and exact-ten-digit subsets are explicit. The numeric guard does not uniquely receive the mismatch information. The interpretation still needs to distinguish prefix consistency from exact ten-digit coverage.
2. **Guard logic:** Numeric fail can turn a semantic binary decision into ineligible; unknown causes referral only in the selective output. Numeric pass never forces eligibility, and an unsupported/unparsed rule does not itself establish compliance. The binary guard and selective guard answer different questions and are correctly stored separately. Decimal trace logging uses `default=str`, preserving exact decimal values as strings.
3. **Metric arithmetic:** Full binary confusion counts, balanced accuracy, false exemption rate, and eligible recall have the usual denominators. Selective errors count answered rows only, while false exemptions and denials are stored as counts with coverage and class-specific coverage. Unknown/reference insufficiency is not introduced as a third observed CBP truth label.
4. **Cluster bootstrap:** Source groups, rather than individual rows, are sampled with replacement, carrying every row of each sampled group. Guard-versus-base differences use the same sampled rows within each replicate. Replicates without both classes are skipped for balanced accuracy. These intervals describe variation across the curated groups conditional on frozen predictions; they do not include repeated model fitting, annotation error, selection into CROSS publication, or uncertainty about legal validity.
5. **Costs:** The script assigns cost ratios of 1, 5, 10, or 25 to false exemption, 1 to false denial, and 0.1, 0.25, or 0.5 to each referral, then divides by the number of same-code rows. A refer-all comparator has cost equal to the specified referral ratio. This is transparent normalized sensitivity arithmetic; it must not be presented as measured operational dollars or an empirically optimal policy.
6. **Risk–coverage curves:** Curves rank the forced binary predictions by the script's chosen score; numerical unknowns are excluded from guard curves. They are descriptive ranking curves, distinct from the native three-way argmax decisions reported in the selective table. Restricted three-token scores and max-class scores are not calibrated confidence. Ties are stably ordered, so a coarse constant-confidence comparator's curve is order-dependent and should not carry a substantive superiority claim.
7. **Stress uncertainty:** Stress resampling is by source rule, preserving its eight scenario rows. This is appropriate for the recorded rule-weighted design. It does not remove the acknowledged duplicate-input or repeated-language limitations.

No fatal bug was identified in these analysis operations. The protocol still uses the ambiguous phrase "false exclusion" for predicted eligible among reference ineligible; manuscript and protocol terminology should consistently say **false exemption**. Code formulas already use the clearer term.

### Reviewed version hashes

| Script | SHA-256 |
|---|---|
| constraint_engine.py | d1baf202365a737751294db4003ed05660f2499d6135e06684410bf75741a568 |
| prepare_benchmark.py | e3e5f79411559af8aa73fe49de03207a4a2c84a3e8af21ea08b6a14c42f2d186 |
| run_neural.py | c771c0a822b8212552ab89cfbe8f265340502166782b53d6a4a8d04a2ba6f673 |
| run_classical.py | a1741197b542ce327fdc9fed37f7f7721e5306b66dfce3489f5661c155698764 |
| generate_stress.py | 2bca0d464307d36418857108693149e07463be1cec41e167728b634c9a3648c3 |
| analyze_experiments.py | 49dd2c0561e17a0027aa79d7b34abf01bcd704a56d455d07bfca823a57588178 |

The review is frozen at these versions. Further method changes should be labeled and tracked; this report should not be used to certify a materially different implementation. No held-out model score was inspected for this review.
