# Independent later-model result audit

Status: **PASS**; 1999 checked fields; 0 discrepancies.

Individual prediction records, Counter confusion tables and Fraction cost arithmetic. Bootstrap intervals independently rebuilt from weighted group confusion counts using the recorded NumPy generator stream and quantile convention. No model inference, threshold selection, parser rerun or data change.

## same_code

n=73; positive=47; negative=26; groups=41.

| Model | TP | FN | FP | TN | BA | BA 95% interval | Answered | Errors | Referrals |

|---|---:|---:|---:|---:|---:|---|---:|---:|---:|

| Qwen3 4B Instruct | 31 | 16 | 10 | 16 | 0.637479542 | [0.508407206632653, 0.7631639146886824] | 67 | 23 | 6 |

| Qwen3 4B Instruct + numeric guard | 31 | 16 | 10 | 16 | 0.637479542 | [0.508407206632653, 0.7631639146886824] | 47 | 15 | 26 |

## all_code_known

n=85; positive=47; negative=38; groups=44.

| Model | TP | FN | FP | TN | BA | BA 95% interval | Answered | Errors | Referrals |

|---|---:|---:|---:|---:|---:|---|---:|---:|---:|

| Qwen3 4B Instruct | 31 | 16 | 10 | 28 | 0.698208287 | [0.6016151277584204, 0.8132212643678162] | 79 | 23 | 6 |

| Qwen3 4B Instruct + numeric guard | 31 | 16 | 10 | 28 | 0.698208287 | [0.6016151277584204, 0.8132212643678162] | 59 | 15 | 26 |

## exact_ten_digit

n=60; positive=45; negative=15; groups=31.

| Model | TP | FN | FP | TN | BA | BA 95% interval | Answered | Errors | Referrals |

|---|---:|---:|---:|---:|---:|---|---:|---:|---:|

| Qwen3 4B Instruct | 31 | 14 | 5 | 10 | 0.677777778 | [0.5228816355810617, 0.8065097402597402] | 55 | 16 | 5 |

| Qwen3 4B Instruct + numeric guard | 31 | 14 | 5 | 10 | 0.677777778 | [0.5228816355810617, 0.8065097402597402] | 41 | 11 | 19 |

## Synthetic stress

{
  "n": 480,
  "correct": 252,
  "accuracy": 0.525,
  "confusion_labels": [
    -1,
    0,
    1
  ],
  "confusion_matrix": [
    [
      51,
      9,
      60
    ],
    [
      0,
      46,
      153
    ],
    [
      0,
      6,
      155
    ]
  ],
  "deduplicated": {
    "n": 443,
    "correct": 237,
    "accuracy": 0.5349887133182845
  },
  "by_scenario": {
    "boundary": {
      "n": 60,
      "correct": 47
    },
    "converted_inside": {
      "n": 60,
      "correct": 59
    },
    "converted_outside": {
      "n": 60,
      "correct": 7
    },
    "inside": {
      "n": 60,
      "correct": 59
    },
    "missing": {
      "n": 60,
      "correct": 51
    },
    "outside_lower_or_upper": {
      "n": 60,
      "correct": 16
    },
    "outside_upper_or_lower": {
      "n": 60,
      "correct": 13
    },
    "straddling": {
      "n": 60,
      "correct": 0
    }
  },
  "rule_bootstrap_95ci": [
    0.49375,
    0.5583333333333333
  ]
}

## Exact-input duplicate sensitivity

{
  "rows": 480,
  "unique_model_inputs": 435,
  "duplicate_input_groups": 43,
  "unique_literal_clauses": 59,
  "models": {
    "Qwen3 4B Instruct": {
      "deduplicated_correct": 233,
      "deduplicated_accuracy": 0.535632183908046,
      "duplicate_label_disagreements": 0,
      "all_rows_clause_bootstrap_95ci": [
        0.49360135319846915,
        0.559322033898305
      ]
    },
    "DeBERTa NLI": {
      "deduplicated_correct": 117,
      "deduplicated_accuracy": 0.2689655172413793,
      "duplicate_label_disagreements": 0,
      "all_rows_clause_bootstrap_95ci": [
        0.2400753648233487,
        0.25416666666666665
      ]
    },
    "Qwen3 0.6B": {
      "deduplicated_correct": 155,
      "deduplicated_accuracy": 0.3563218390804598,
      "duplicate_label_disagreements": 0,
      "all_rows_clause_bootstrap_95ci": [
        0.32083333333333336,
        0.3495762711864407
      ]
    },
    "Numeric predicate execution": {
      "deduplicated_correct": 422,
      "deduplicated_accuracy": 0.9701149425287356,
      "duplicate_label_disagreements": 0,
      "all_rows_clause_bootstrap_95ci": [
        0.9364406779661016,
        1.0
      ]
    }
  }
}

## Source-conditioned metrics

{
  "HQ": {
    "Qwen3 4B Instruct": {
      "n": 27,
      "tp": 8,
      "fn": 3,
      "fp": 6,
      "tn": 10,
      "accuracy": 0.6666666666666666,
      "balanced_accuracy": 0.6761363636363636,
      "false_exemption_rate": 0.375,
      "eligible_recall": 0.7272727272727273
    },
    "Qwen3 4B Instruct + numeric guard": {
      "n": 27,
      "tp": 8,
      "fn": 3,
      "fp": 6,
      "tn": 10,
      "accuracy": 0.6666666666666666,
      "balanced_accuracy": 0.6761363636363636,
      "false_exemption_rate": 0.375,
      "eligible_recall": 0.7272727272727273
    }
  },
  "NY": {
    "Qwen3 4B Instruct": {
      "n": 46,
      "tp": 23,
      "fn": 13,
      "fp": 4,
      "tn": 6,
      "accuracy": 0.6304347826086957,
      "balanced_accuracy": 0.6194444444444445,
      "false_exemption_rate": 0.4,
      "eligible_recall": 0.6388888888888888
    },
    "Qwen3 4B Instruct + numeric guard": {
      "n": 46,
      "tp": 23,
      "fn": 13,
      "fp": 4,
      "tn": 6,
      "accuracy": 0.6304347826086957,
      "balanced_accuracy": 0.6194444444444445,
      "false_exemption_rate": 0.4,
      "eligible_recall": 0.6388888888888888
    }
  }
}

## Example assumed-cost check

{
  "Qwen3 4B Instruct": 1.5684931506849316,
  "Qwen3 4B Instruct + numeric guard": 0.910958904109589
}

## Identifier diagnostic

{
  "case_id": "H317391_1",
  "states": {
    "original": "fail",
    "identifier_masked": "unknown",
    "identifier_explicitly_labeled": "fail"
  },
  "frozen_engine_hash_verified": "d1baf202365a737751294db4003ed05660f2499d6135e06684410bf75741a568",
  "counterfactual_edit_only": "single model identifier",
  "scope": "One selected post hoc error; neither an additional independent observation nor an engine repair."
}

## Boundaries

These are fixed-model and source-grounding/arithmetic checks, not independent expert validation of the reference labels. The 60 source rules are purposively selected, and synthetic inputs supply selected literal numeric clauses rather than complete exclusion descriptions. This audit does not repeat the previous 1,277-field primary-result audit. Manuscript text is checked separately.

## Limited assembled-manuscript verification

The assembled `manuscript/tariff_exclusion_manuscript.md` was read after the 4B run and final exact-input sensitivity were complete. Audited SHA-256: `de26256f3584cf52713cdc5fd1fdb844792931df6a229323047e65cf58e699d8`. The abstract contains 217 whitespace-delimited words. This was a content check; no manuscript or analysis code was edited.

**PASS. No numerical or interpretation correction is required for the reviewed additions.** The earlier guard-state, grouping/resampling wording, NLI prefix, and H330938 connector-evidence issues are already corrected. This check does not reopen those resolved issues or claim a new literature/source-expertise review.

| Item checked | Evidence and exact verified value | Decision |
|---|---|---|
| Abstract and main binary result | 4B TP31/FN16/FP10/TN16; BA 0.6374795417348609; group CI [0.508407206632653, 0.7631639146886824] | 63.7% and 50.8–76.3% match |
| Table 1 | Every displayed BA, interval, false-grant and missed-eligible cell agrees with the frozen primary analysis, previous independent primary audit, and the new 4B recomputation | All rows match; source-only correctly marked diagnostic |
| Table 2 | 4B native 67 answers, 23 errors, FP10/FN13, 6 referrals; guarded 47 answers, 15 errors, FP5/FN10, 26 referrals | All six rows agree with corresponding saved or independently recalculated metrics |
| Table 3 | 4B scenario correct counts in displayed order: 59,47,16,13,59,7,51,0; total252/480; CI[0.49375,0.5583333333333333] | Four model columns, total/accuracy/interval rows agree with saved primary results and new 4B recomputation |
| 4B native/guard cost at FP=5, referral=0.5 | 66/73=0.9041095890410958 and 48/73=0.6575342465753424 | 0.904/0.658 match |
| 4B native/guard cost at FP=1, referral=0.5 | 26/73=0.3561643835616438 and 28/73=0.3835616438356164 | 0.356/0.384 match; full referral0.500 is explicit |
| Observed-case latency | Median7.007499999977881seconds; no 4B truncation; model loading excluded by recorded timer | 7.01seconds matches and batch-time limitation is explicit |
| Source-identity deduplication | 443 rule-ID/fact/label specifications; Qwen4B237 correct | Correctly distinguished from exact model inputs |
| Exact-input sensitivity | 435 inputs,59 clauses,43 repeated-input groups; correctNLI117/Qwen0.6B155/Qwen4B233/numeric422; numeric clause CI[0.9364406779661016,1] | Text matches; all four discrete prediction sets are consistent within repeated-input groups |
| Numeric input scope | Synthetic model input uses selected literal numeric clause, other conditions fixed satisfied; 60 rules purposive rather than random | Stated in Methods and no claim of complete-rule validation |
| Classical fitting scope | Full86 under nested group fitting; reporting then restricts pooled held-out predictions to73 | Explicit and consistent with code |
| Identifier intervention | Originalfail, maskedunknown, explicitly-labeledfail; only UH72600W string changed; engine hash unchanged | Correctly described as one selected post hoc diagnostic, not repair or error-prevalence estimate |
| 4B resource preflight | Max score difference0.000044756001443602145; throughput factor1.640222944726763; full-run repeated-input spread0.01949131488800049 | Appendix rounding0.0000448/1.64/0.01949 matches; no unjustified all-score equivalence claim |

The abstract, results, and conclusion retain the distinction between a local predicate test and observed CBP dispositions. They do not claim deployment validation, improved binary performance from the numeric guard, a clean causal effect of model size, or expert-adjudicated gold labels. H330938 is described as missing a connector-specific factual finding, without inferring that fact from the eventual grant. The frozen data's older contradictory annotation is separately disclosed by the reproducibility-package erratum and did not enter model prompts.
