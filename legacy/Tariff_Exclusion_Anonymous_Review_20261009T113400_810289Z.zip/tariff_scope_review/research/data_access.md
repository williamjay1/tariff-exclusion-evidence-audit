# CBP CROSS data acquisition and access verification

Acquisition date: 2026-10-07. All retrieved materials are official public CBP records. No authentication, browser cookies, or access-control workaround was used. This report describes actual collection, not a proposed data source.

## Verified interface

The live CROSS page is an Angular application. Its publicly delivered application bundle calls the following relative endpoints. Both were tested successfully with HTTP 200 JSON responses.

- `https://rulings.cbp.gov/api/search`: GET parameters `term`, `collection`, `commodityGrouping`, `fromDate`, `toDate`, `pageSize`, `page`, and `sortBy`. The frontend caps `pageSize` at 100. `sortBy=DATE_ASC` provides chronological order. Response keys are `rulings` and `totalHits`.
- `https://rulings.cbp.gov/api/ruling/{rulingNumber}`: GET individual full records. Stable public human-readable citation: `https://rulings.cbp.gov/ruling/{rulingNumber}`.
- `https://rulings.cbp.gov/api/app-config`: public runtime configuration, preserved once per primary collection.

Returned ruling fields include `text`, `rulingNumber`, `subject`, `rulingDate`, `collection` (`hq` or `ny`), `categories`, `tariffs`, `relatedRulings`, `modifiedBy`, `modifies`, `revokedBy`, `revokes`, `operationallyRevoked`, `isUsmca`, `isNafta`, and `commodityGrouping`. The individual endpoint also returns an expiring PDF URL. It is preserved only in the original JSON; analysis uses the stable ruling URL and removes the expiring link.

## Reproducible search frame

All searches use `fromDate=2018-01-01`, `toDate=2026-10-07`, `pageSize=100`, and full pagination. The engine distinguishes singular and plural words; searching `9903.88` alone returned zero and was not treated as a valid tariff prefix search.

| Search term | Reported and retrieved hits | Unique within query |
|---|---:|---:|
| `301 AND exclusion` | 177 | 177 |
| `301 AND exclusions` | 1723 | 1723 |
| `301 AND exempt` | 80 | 80 |
| `301 AND exclude` | 54 | 54 |
| `exclusion` | 392 | 392 |
| `exclusions` | 2104 | 2104 |

The four primary queries yielded 1916 unique candidates after adding a small independently identified recall-check seed list. Broader singular/plural queries without `301` added 566 unique records not in the primary list. Collection is complete: **2482 unique full ruling records were retrieved**, with no missing or duplicate IDs. Two transient network failures (H323646 and N326929) were recovered into a separate immutable raw run. The completed manifests retain both the original failed-attempt accounting and the successful recovery.

The final corpus contains **368 HQ and 2114 NY rulings**, covering decision dates from **2018-01-16 through 2026-09-16**. Some recent records use uppercase `HQ`/`NY` while older records use lowercase; filter these fields case-insensitively. There are 1906 records containing the explicit Section 301 phrase or a 9903.88 code, but this textual flag is still not a substantive exclusion-eligibility label.

End-to-end acquisition QA passed: all six paginated queries have identical reported-hit, retrieved-hit, and unique-ID counts; all 2482 expected records have nonempty text and matching original ruling IDs; all preserved text equals its raw response; **2531 original response files (25,163,602 bytes)** passed SHA-256, byte-length, and read-only checks. There are no remaining errors. Evidence: `datasets/cbp_validation.json`.

These are lexical candidates. They include ordinary classification letters with a standard Section 301 paragraph, unrelated ITC exclusion orders, historical comparisons, and records that merely mention exclusions. Search membership is not an eligibility label and is not proof that a record adjudicates a Section 301 product exclusion.

## Storage and implementation

- Immutable original response files: `F:\AcademicData\tariff_scope_20261007\raw\cbp\<UTC-run-stamp>\search` and `rulings`. Every response uses exclusive file creation and is made read-only. No existing raw material is overwritten, moved, or deleted.
- Collector: `D:\MLWork\tariff_scope_20261007\scripts\collect_cbp.py`.
- Recall supplement: `D:\MLWork\tariff_scope_20261007\scripts\cbp_collect_supplement.py`.
- Derived section parser: `D:\MLWork\tariff_scope_20261007\scripts\cbp_derive.py`.
- Primary complete-text stream: `D:\MLWork\tariff_scope_20261007\datasets\cbp_rulings_20261007T143403Z.jsonl`.
- Recall supplement stream: `D:\MLWork\tariff_scope_20261007\datasets\cbp_supplement_20261007T143907Z.jsonl`.
- Recovered transient requests: `D:\MLWork\tariff_scope_20261007\datasets\cbp_recovery_20261007T150232Z.jsonl`.
- Combined derived text and section view: `D:\MLWork\tariff_scope_20261007\datasets\cbp_rulings_derived.jsonl`.
- Search indexes preserve every query and every returned metadata record. Completed collection manifests record request URL, retrieval time, HTTP status, local path, byte length, and SHA-256 for each response.
- Final validation: `D:\MLWork\tariff_scope_20261007\datasets\cbp_validation.json` and `scripts/cbp_validate.py`.
- Lexical triage: `datasets/cbp_screening.tsv` and `scripts/cbp_screen.py`. The score prioritizes review and is never used as an adjudicated outcome label.

Network retrieval was throttled, with three workers at a shared minimum 0.60-second request-start interval in the primary collection and one slower worker in the recall supplement. No model training, cache, or processed output is stored in C: or in the F: raw repository.

## Text structure and limitations

HQ decisions often have FACTS, ISSUE(S), LAW AND ANALYSIS, and HOLDING headings. NY letters generally do not. PDF-derived text sometimes places headings in the middle of a long line, so the derived parser recognizes uppercase section labels without requiring a new line. The `text` field remains verbatim. Section extraction is a convenience view, not independent verification that every fact required for an answer was supplied before the analysis.

Metadata `rulingDate` is a decision date, not guaranteed to be the first public availability date. Some holdings specify later public release. It should not be described as publication time in a temporal evaluation without further evidence.

Official documents can contain clerical inconsistencies. For example, H335786 discusses heading 4819 but portions of the final Section 301 paragraph show 4918. Such source inconsistencies must be flagged rather than silently repaired by the dataset pipeline.

## Immediately useful evidence cases

- H332948, 2025-08-25: two silica-gel products under the same 2811.22.1000 classification; the holding grants the described exclusion only to Ultra Art Crystals and not the other product. Useful for product-level, within-code distinctions; split at product level only with common-case grouping.
- H338585 and H338459, 2025-07-21: tilapia cases involving the 115-gram condition and insufficient segregation/entry evidence. Both deny the claimed exclusion. Physical mixture does not mean the legal outcome is a mixed grant/denial.
- H342570, H342571, H344006, 2025-07-21: static-converter cases. Closely related reasoning requires family grouping rather than random independent splitting.
- H330938, 2024-03-05: electrical cable conductors. Needed product facts may appear in the analysis after the formal FACTS section, so a facts-only input can become unanswerable.
- H341677, 2025-02-14: breathalyzer exclusion involving a wireless-enabled condition.
- H319100: smart-display exclusion dispute; full record must distinguish asserted functionality from evidence that satisfies the legal description.
- N341609: surgical-gown letter potentially useful as a whole-code exclusion comparator, subject to independent eligibility annotation.

None of the foregoing notes is a model experiment or a numerical validation result. The actual JSON documents provide the evidence for subsequent protocol development and independent label review.
