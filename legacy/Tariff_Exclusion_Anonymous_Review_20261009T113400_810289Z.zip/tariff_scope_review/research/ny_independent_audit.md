# Independent source audit of NY reference cases

Audit date: 2026-10-07. Reviewer: tariff_design agent, independent of the NY coding agent but not an independent human customs expert. This is a source and construct audit, not a claim of legal certification.

## Scope and result

All 53 records in `ny_reference.jsonl` were mechanically checked against the official CBP source text after whitespace normalization. Every paragraph fragment used as facts, every rule quote, and every reference quote matched its source. No quote-match failures were observed.

The substantive audit read all 13 negative product-rule records and 11 additional multi-product, unresolved or source-conflict records. The extra records were N304766, both N309775 pairs, N314745_self, N316485, N336939, N332752, N312471, both N307251 pairs, and N344025. For the complicated N316485, N336939 and N332752 cases the full official ruling text was inspected in addition to the annotated passages. Negative dispositions were cross-checked against the quoted explicit CBP conclusions and their product identities, candidate provisions and stated reasons.

**Decision: GO for incorporation as source-grounded reference coding, conditional on maintaining the already documented exclusions and task boundaries.** No label reversal, fabricated quote or clear decision-conclusion contamination in retained product facts was found among the audited records. This does not establish inter-rater reliability: both coding and audit were performed by AI agents.

## Negative-label findings

| Cases | Verified distinction | Audit judgment |
|---|---|---|
| N307161 | Same code; physical dimensions differ from narrowly specified power-supply dimensions | Explicit ineligible reference is supported. |
| N311039_33 and N311039_63 | Contact voltage of 277 VAC versus coil voltage; second provision also has a different required code | Correctly grouped as two candidate provisions for the same four relays; no model-count inflation. |
| N312588 | Integrated circuits, transistors and diodes present in product description | Legal classification paragraph correctly excluded from facts; rule wording is the earlier no-electronics variant. |
| N307931, N311930 and N312986 | Skateboard category, power limits and in some cases different classification | Sources contain a 250 W quoted rule versus 1,000 W paraphrase discrepancy; annotations properly preserve the quote and flag source errors. |
| N307830 | Three-wheel vehicles fail the ruling's motorcycle construction despite being below power limit | Correct negative; motor power alone would incorrectly grant. |
| N314745_pedal | Pedal-assist-only products distinguished from three self-propelled products in the same ruling | Correct product split. Both sides must remain in the same group/split. |
| N319331 | Detachable S-Max hoverboard, not the full go-kart, is the reference subject | Correct negative reference. Alignment is supplied only in analysis and is not inserted into facts. |
| N327114 | Peak 3,000 W versus nominal 1,000 W | Correct negative. Source rule quote lacks closing punctuation; preserved as a source defect, not fabricated completion. |
| N329172 | Plastic soundbar housing versus steel carrier/rack attachments | Correct negative with both material and product-type mismatch. |
| N332207 | Rider must pedal to initiate motion despite a named throttle-only mode | Correct negative source disposition; crucial claimant reply is retained before case-specific legal analysis. |

## Remaining boundaries to preserve

1. **Official positive outcome does not imply sufficient retained text.** N316485 never expressly says the plywood is unfinished. N336939's exhaustive absence of non-LED goods of headings 8541/8542 is stated in analysis, not the retained product description. Their source references are positive, but a careful fact-only model can reasonably abstain. Evaluate official-disposition prediction and input-evidence completeness separately.
2. **Scenario is part of input.** N316485's `if imported individually and packaged in separate cartons` is a verbatim fragment of the applicant's requested scenario, not a fabricated shipping observation. A paper should call this a ruling scenario, not a verified historical shipment. Keep the requested wood components separate from metal and plastic components in the same letter.
3. **Unknown is an outcome class, not a model choice.** Both N307251 pairs explicitly lack price/length information. They are valid unresolved reference cases; do not coerce them into negative labels or claim a predictor's abstention proves legal ineligibility. N344025 is a procedural referral and correctly excluded from the primary set.
4. **Already quarantined source conflict must stay quarantined.** N332752 says 22.69 kg bags, quotes a 23 kg condition and calls 9903.88.03 an exclusion while stating a grant. Its positive textual label is real but internally inconsistent. `include_in_primary=False` is appropriate; no repair by rounding or silent code replacement.
5. **Version-specific rule text must stay attached.** N312588 and N336939 share a code but different electronic-component exclusions: the later quoted wording permits fan hubs/LEDs. Substituting one rule version for both would manufacture errors.
6. **Optional text tightening.** N332207's first paragraph includes a generic pedal-assist glossary after the initial product sentence. It does not disclose the final outcome, so it is not a blocking leakage defect; removing the generic glossary would make the descriptive-only input boundary cleaner. The later applicant reply already supplies the decision-relevant fact.

## Cross-file oracle-classification setting

The parent design supplies the adjudicated base product classification to every comparator to isolate exclusion applicability from HS-code prediction. This is a legitimate bounded task if disclosed. Keep `product_hts` distinct from candidate `rule_hts`; never compare the rule's code against itself. Compare exact ten-digit match separately from compatibility of an eight-digit product code, and do not fill missing suffixes with zeros. Report that the setting is retrospective applicability assessment conditional on oracle base classification, not a pre-entry end-to-end customs automation system.

## Audit interpretation

The checks support traceability and the correctness of the selected disposition readings. They do not show that facts were sampled without selection bias, that public rulings represent real import traffic, that model pretraining excluded these rulings, or that quoted clauses remain currently in force. Those are separate limits, not grounds for re-labelling the historical source decisions.
