"""Source-span extraction of agent-reviewed HQ reference cases. No predictive model.
All case selection, labels and spans are agent coding, not independent human annotation.
"""
import json,re,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D={x['rulingNumber']:x for x in map(json.loads,(ROOT/'datasets/cbp_rulings_derived.jsonl').open(encoding='utf-8'))}
N=lambda s:re.sub(r'\s+',' ',s).strip()
records=[];errors=[]

def span(s,start=None,end=None):
    a=0 if start is None else s.index(start)
    b=len(s) if end is None else s.index(end,a+len(start or ''))
    return s[a:b].strip()

def add(rid,product,y,rule_start,note,hts,*,starts=None,ends=None,facts=None,ref=None,ref_end=None,group=None,scope='product_specific',suff='not_audited',hard=False,annotation='',rule_end=None,benchmark=True):
    r=D[rid];t=N(r['text']);f=N(r['sections'].get('FACTS',''))
    try:
        fs=facts if facts is not None else [span(f,starts,ends)]
        if isinstance(fs,str):fs=[fs]
        if rule_start:
            matches=list(re.finditer(rule_start,t,re.I))
            if not matches:raise ValueError('RULE start '+rule_start)
            m=next((m for m in matches if re.search(r'\(described in [^)]*\)',t[m.start():m.start()+1200],re.I)),matches[0])
            if rule_end:
                b=t.index(rule_end,m.start())+len(rule_end)
            else:
                q=re.search(r'\(described in [^)]*\)',t[m.start():],re.I)
                if not q or q.end()>1800:raise ValueError('RULE end '+rule_start)
                b=m.start()+q.end()
            rule=t[m.start():b]
        else:rule=''
        if ref:
            a=t.index(ref)
            q=t[a:t.index(ref_end,a)+len(ref_end)] if ref_end else t[max(0,a-150):min(len(t),a+len(ref)+180)]
        else:q=N(r['sections'].get('HOLDING',''))
        if not q:raise ValueError('reference missing')
        loc=[]
        for text in fs:
            if not text:continue
            if text not in f:raise ValueError('FACT outside FACTS '+text[:70])
            loc.append({'section':'FACTS','normalized_section_offset':f.index(text),'length':len(text)})
        idx=1+sum(z['rulingNumber']==rid for z in records)
        out={'case_id':rid+'_'+str(idx),'rulingNumber':rid,'date':r['rulingDate'][:10],'product':product,'reference_disposition':y,'facts':fs,'rule_text':rule,'reference_quote':q,'hts':hts,'rule_note':note,'group_hint':group or rid,'scope_type':scope,'annotation_note':annotation,'substantive_eligibility':True,'benchmark_candidate':benchmark and bool(rule) and bool(fs),'evidence_sufficiency':suff,'hard_case':hard,'annotation_method':'AI-agent source-grounded coding; no independent human validation','official_url':r.get('official_url','https://rulings.cbp.gov/ruling/'+rid),'facts_locators':loc,'rule_locator':{'section':'full_text','normalized_text_offset':t.index(rule) if rule else None,'length':len(rule)},'reference_locator':{'section':'full_text','normalized_text_offset':t.index(q),'length':len(q)},'normalization':'Whitespace collapsed only; no substantive correction of source text.'}
        if hard:out['benchmark_candidate']=False
        records.append(out)
    except Exception as e:errors.append({'id':rid,'product':product,'error':str(e)})

add('H330938','Aluminum cable conductors','eligible',r'(?:Monopolar|\[M\]onopolar) conductors for a voltage','20(ttt)(ii)(28)','8544.60.6000',suff='insufficient_from_input',annotation='FACTS never says no connectors; that fact first appears in analysis. Voltage descriptions differ (35kV model name vs 2000V specification). Do not silently fill either discrepancy.')
for rid in ['H342570','H342571','H344006']:
    add(rid,'USB car and wall chargers','ineligible','Static converters of a kind used to charge','20(mmm)(32)','8504.40.8500',group='static_converters_20250721',suff='requires_tariff_interpretation',annotation='Three highly overlapping same-date decisions; keep in one group. Price absent from FACTS; classification to 8504.40.95 defeats requested exclusion.')
add('H341677','Five portable breathalyzer models','ineligible','Portable, wireless enabled, electrical gas monitors','20(ttt)(ii)(34)','9027.10.2000',suff='requires_tariff_interpretation',ref='the subject breathalyzers do not meet the terms',annotation='Internal battery operation without cables is not network wireless enablement. No model-level sample inflation.')
add('H317391','Traditional dry upright vacuums','eligible','Vacuum cleaners, bagless, upright, capable of operating','20(nn)(13)','8508.11.0000',starts='“Traditional”',ends='Carpet cleaners include',group='upright_vacuum_scope',suff='determinate_from_input',annotation='22 model numbers share one factual description and one label; one product group.')
add('H317391','Wet carpet cleaners','ineligible','Vacuum cleaners, bagless, upright, capable of operating','20(nn)(13)','8508.11.0000',starts='Carpet cleaners include',ends='These products are subject',group='upright_vacuum_scope',suff='requires_tariff_interpretation',annotation='11 models share one label. Injecting cleaning solution then suctioning it is not vacuum-cleaner operation under the ruling. Final document is mixed; this product-rule pair is negative.')
add('H323452','Infrared golf simulator pad','ineligible','Mouse input devices for automatic data processing','20(w)(22)','8471.60.9050',ends='The subject merchandise was entered',suff='requires_tariff_interpretation',annotation='Candidate rule requires both mouse function and value over $70; price is not supplied in retained facts. Negative outcome turns on function.')
add('H333110','Fluance Ai40/Ai60 speakers and RS61 Retro system','ineligible','Wireless communication apparatus that can receive audio','20(jjj)(60)','8518.22.0000',ends='The devices were entered',group='audio_distribution_scope',suff='insufficient_from_input',annotation='Receiving Bluetooth audio does not establish distribution to external wireless speakers; ruling treats missing evidence as failure of eligibility.')
add('H319100','Google smart speakers','ineligible','Wireless communication apparatus capable of receiving audio','20(zz)(8)','8517.62.0090',ends='The “Smart Displays”:',group='audio_distribution_scope',suff='requires_tariff_interpretation',ref='the smart speakers are subject to the additional 301 duties',annotation='Corrected heading 8518 defeats candidate requiring 8517.62.0090; final classification is label-side information.')
add('H319100','Nest Hub and Nest Hub Max smart displays','ineligible','Wireless communication apparatus capable of receiving audio','20(zz)(8)','8517.62.0090',starts='The “Smart Displays”:',group='audio_distribution_scope',suff='insufficient_from_input',ref='There is no evidence that the subject devices',annotation='Ruling explicitly finds no evidence of distributing audio to wireless speakers. Do not turn missing evidence into a fabricated negative product fact.')
add('H311957','Electric fireplace inserts','eligible','Electric fireplaces, weighing not more than 21 kg','20(ll)(53)','8516.29.0090',ends='It is stated that',suff='determinate_from_input',annotation='Published text renders note ll as capital II in places; note normalized in metadata only.')
add('H311978','Three tested plain woven fabrics','ineligible','Woven fabric sheeting of 65 percent polyester','20(w)(11)','5513.11.0040',starts='Three samples of the merchandise',suff='requires_tariff_interpretation',annotation='Lab measurements in FACTS retained; party request text copying exemption removed. Three samples share the same negative conclusion; one ruling group.')
add('H308870','Cast iron mini-excavator counterweights','ineligible','Counterweight castings of iron or steel','20(q)(90)','8431.49.9095',ends='The protestant provided the following picture',suff='requires_tariff_interpretation',annotation='Descriptive language matches; correct code 8431.49.9044 is outside required .9095. Do not use metadata final tariff code as predecision feature.')
add('H311151','Unicat SR-110CX zinc oxide catalyst','eligible',r'(?:Supported|\[s\]upported) catalysts with zinc oxide','20(qq)(25)','3815.19.0000',ends='The protested merchandise consists of one (1) entry',group='supported_catalyst_scope',suff='requires_tariff_interpretation',annotation='Supported catalyst classification requires interpreting chemical role; facts include supplemental information supplied before decision.')
add('H316154','Patch-clamp amplifiers','eligible','Programmable DC electronic load instruments capable','20(x)(90)','9030.33.3800',ends='At the time of entry',suff='determinate_from_input')
add('H320060','Rubber tracks for compact track loaders','ineligible','Vulcanized rubber tracks, each incorporating cords','20(i)(17)','8431.49.9095',suff='requires_tariff_interpretation',annotation='Technical product descriptor matches much of rule; correct loader-parts heading differs. FACTS should not be supplemented from final classification.')
add('H322923','Folding personal-shopping wagons','eligible',r'(?:Carts|\[C\]arts), not mechanically propelled','20(p)(7)','8716.80.5090',ends='Several styles of the subject wagons',suff='insufficient_from_input',annotation='Four-wheel property is clear in images and analysis but not expressly stated in retained textual FACTS. Separate chair mentioned only in analysis not made an extra fact-only case.')
add('H314080','Seventeen polyurethane-coated textile styles','ineligible',r'(?:Fabrics|\[f\]abrics) of man-made micro-denier fibers','20(ll)(18)','5903.20.2500',facts=[span(N(D['H314080']['sections']['FACTS']),end='The Protestant describes'),span(N(D['H314080']['sections']['FACTS']),start='The CBP Laboratories and Scientific Services Directorate')],suff='insufficient_from_input',hard=True,annotation='Party assertion copying rule removed. Decisive measured fiber diameter occurs only in analysis; cannot be recovered from retained FACTS. Hard case outside conclusive fact-only comparison.')
add('H330005','Four grill-tool sets','ineligible','Sets of flatware of stainless steel','20(pp)(31)','8215.20.0000',ends='The protested merchandise consist',suff='requires_tariff_interpretation',ref='no component of the item sets meets the definition',annotation='A partial protest allowance for reclassification is not a Section301 grant; all candidate exclusion requests denied.')
add('H316387','Suspension control-arm and ball-joint assemblies','ineligible','Torque rods, also known as torque arms','20(vv)(146)','8708.80.6590',ends='The subject control arms were entered',suff='requires_tariff_interpretation',ref='Therefore, control arms are not included',annotation='FACTS includes a prior decision after product description, removed. Holding has inconsistent 9903.88.43 report code despite denial: outcome must use substantive analysis rather than code-only label mining.')
add('H336040','Unfinished household metal cabinets without countertops','ineligible','Household furniture of metal and high-pressure laminated bamboo','20(ttt)(iii)(178)','9403.20.0050',suff='requires_tariff_interpretation',annotation='Metal and bamboo is conjunctive. Countertops added after import are not imported product composition; steel or bamboo later choice cannot satisfy at-entry facts.')
add('H342749','Organic polymer filter membrane rolls and flats','ineligible','Filter housings, covers, or couplings','20(ttt)(i)(28)','8421.99.0140',starts='The filter membrane rolls at issue',suff='determinate_from_input',annotation='Source holding has apparent code transposition 8421.99.1040, preserved only label-side; rule uses .0040 before 2022-01-27 and .0140 after.')
common=span(N(D['H332948']['sections']['FACTS']),end='The first package is for')
art=span(N(D['H332948']['sections']['FACTS']),start='The first package is for',end='The second package is for')
cat=span(N(D['H332948']['sections']['FACTS']),start='The second package is for',end='The protested merchandise consists')
for prod,specific,flower_y in [('Ultra Art Crystals',art,'eligible'),('Ultra Micro Crystals cat litter',cat,'ineligible')]:
    add('H332948',prod,flower_y,'Synthetic silica gel, in granules measuring','20(qq)(12)','2811.22.1000',facts=[common,specific],suff='requires_tariff_interpretation',annotation='Same material and size, different retail presentation and principal use. Two products by two rules are dependent pairs; mixed document does not imply unresolved pair.')
    add('H332948',prod,'ineligible','Synthetic silica gel, in amorphous granules','20(vv)(12)','2811.22.1000',facts=[common,specific],suff='insufficient_from_input',ref='Additionally, the remaining Carborundum factors',ref_end='because neither meets the use criteria.',annotation='No evidence establishes kind used as catalyst support. Four dependent product-rule pairs share one ruling group.')
add('H318593','Hybrid steel/aluminum hydraulic floor jack','eligible','Hydraulic floor jacks of steel','20(yy)(73)','8425.42.0000',ends='A representative photograph',suff='requires_tariff_interpretation',annotation='68.5% steel composition requires SectionXV predominant-metal rule; do not interpret of steel as 100% steel.')
add('H318593','Hybrid steel/aluminum hydraulic floor jack','ineligible','Hydraulic jacks of a kind for raising vehicles','20(vv)(103)','8425.42.0000',ends='A representative photograph',suff='determinate_from_input',ref='As U.S. note 20(vv)(103)',ref_end='the exclusion is inapplicable to the subject merchandise.',annotation='Same jack considered against different candidate provision: 6000-pound capacity exceeds 550kg. Positive on other rule cannot be reused here.')
add('H340899','Three Prolux backpack vacuum models','ineligible','Vacuum cleaners, bagless, upright, each with self-contained','20(ttt)(iii)(123)','8508.11.0000',ends='The subject vacuums were entered',group='upright_vacuum_scope',suff='requires_tariff_interpretation',annotation='Marketing title contains upright but backpack form does not meet upright vacuum category. Three models kept as one product group.')
add('H345780','Sand and cartridge swimming-pool filter systems','ineligible','Filtering or purifying machinery or apparatus of a kind used for waste water','20(ttt)(i)(23)','8421.21.0000',ends='The subject merchandise was entered',suff='requires_tariff_interpretation',annotation='Pool-water filtering and wastewater treatment are distinct use categories in ruling; same HS code is insufficient.')
add('H333371','Coated knit work gloves','ineligible','Gloves, containing less than 50 percent by weight','20(jjj)(33)','6116.10.6500',ends='On December 8, 2020',suff='disputed_fact',annotation='FACTS retains both importer composition claim and subsequent CBP laboratory measurement. Source provenance resolves conflict; do not treat the two measurements as equivalent.')
add('H317208','Separately packaged steel shelves and posts','eligible',r'(?:Parts|\[p\]arts) of counters, racks, display cases','20(vv)(173)','9403.90.8041',ends='The protested merchandise consists of one entry',suff='insufficient_from_input',annotation='Parts rather than kits; exclusion also excepts welded-wire rack decking. FACTS says both solid and wire shelves without stating welded-wire-decking status.')
add('H336964','SINAMICS DCM four-quadrant speed drive controllers','eligible','Regenerative speed drive controllers for controlling speed','20(ttt)(i)(59)','8504.40.4000',ends='The subject speed drive controllers were entered',suff='determinate_from_input',annotation='FACTS explains regenerative braking and elevator-motor control; does not require exclusive elevator use.')
add('H333673','Multifunction rain-light-solar-humidity vehicle sensor','ineligible','Apparatus using passive infrared detection sensors designed','20(ttt)(ii)(25)','8543.70.9860',ends='The protestant entered the subject merchandise',suff='requires_tariff_interpretation',annotation='One subcomponent meets passive-infrared lighting function but the entire device has other functions; eligibility assessed at imported-product level. Analysis misdescribes ambient-light purpose relative to FACTS; source discrepancy retained for review.')
add('H313009','CLX-13X and CLX-16E promoted zeolites','ineligible',r'(?:Supported|\[s\]upported) catalysts with alumina','20(qq)(25)','3815.19.0000',group='supported_catalyst_scope',suff='requires_tariff_interpretation',annotation='Product marketing calls catalysts; provided Na2O reaction consumes reactant, adsorption and pore trapping do not establish catalytic role. Scientific nomenclature and heading jointly matter.')
add('H327850','Furrion RV wall thermostat without internet connectivity','eligible','Thermostats designed for air conditioning or heating systems','20(ttt)(i)(88)','9032.10.0030',ends='The thermostats were entered',suff='determinate_from_input',annotation='RV wall is still wall mounting; physical mobility of the vehicle does not remove eligibility.')
for rid in ['H338585','H338459','H338586']:
    f=N(D[rid]['sections']['FACTS']);first=f[:f.index('.')+1]
    add(rid,'Commingled 3–5 oz frozen tilapia fillets','ineligible','Tilapias, frozen, each weighing not more than 115 g','20(vv)(2)','0304.61.0000',facts=[first],group='tilapia_commingling_20250721',scope='procedural',suff='insufficient_from_input',hard=True,annotation='Actual refusal concerns proof of eligible weights and segregation/commingling, not a negative label for every fillet. Only product descriptor kept; procedural evidence is not captured. Exclude from simple attribute-eligibility benchmark.')

# These were substantively read but are not complete product-description/rule pairs.
for rid,prod,y,reason in [
    ('H316644','Collapsible duffle bags','unresolved','Interpretation-only: measurements must be in unfolded use condition; no actual dimensions or final product eligibility disposition.'),
    ('H318221','Silex silicone-coated fabric','ineligible','Explicit exclusion denial under note20(qq)(38), but complete candidate exclusion text is absent from decision. Do not invent it.'),
    ('H323434','Industrial shredders and parts','ineligible','Explicit no-applicable-exclusion statement, but no complete positive candidate provision identified. Not a product-rule entailment pair.'),
    ('H310389','Absorbent rayon towels','eligible','Whole-code 5603.92.0090 exclusion under note20(aaa)(15); provision not quoted in full. Weight needed for final code occurs in analysis, not retained facts.'),
    ('H335786','Foldable paperboard cosmetic boxes','ineligible','Whole-code 4819.50.4060 exclusion under note20(sss)(iii) denied because final classification is 4819.20.0040. Requires separate classification test; full rule text not quoted as a product description.'),
    ('H324564','Clinical infrared temperature-screening devices','eligible','Holding explicitly grants note20(o)(63) eligibility; complete candidate exclusion provision not quoted in ruling. Retain source label but not benchmark pair.'),
    ('H330748','Bath rails and toilet grab rails','ineligible','Time-validity hard case: decision explicitly rejects current/future exclusion because note20(w) expired on 2020-08-07. No FACTS/HOLDING headings; full text retained as evidence, no fabricated fact section.'),
    ('H312651','Aluminum and brass plate-fin heat exchangers','unresolved','Ruling ALLOWs classification protest and quotes requested exclusions, but does not explicitly adjudicate their price conditions or independently state exclusion grant. Ambiguous disposition is not a positive gold label; excluded from benchmark.'),
    ('H310618','Sucker rods and couplings for oil pumps','unresolved','Ruling ALLOWs classification protest and quotes requested exclusion, but does not explicitly adjudicate API-grade condition or independently state exclusion grant. Ambiguous disposition is not a positive gold label; excluded from benchmark.')]:
    r=D[rid];t=N(r['text']);q=N(r['sections'].get('HOLDING','')) or t
    records.append({'case_id':rid+'_review','rulingNumber':rid,'date':r['rulingDate'][:10],'product':prod,'reference_disposition':y,'facts':[],'rule_text':'','reference_quote':q,'hts':'','rule_note':'','group_hint':rid,'scope_type':'whole_code' if rid in ['H310389','H335786'] else 'product_specific','annotation_note':reason,'substantive_eligibility':rid!='H316644','benchmark_candidate':False,'hard_case':True,'annotation_method':'AI-agent source-grounded coding; no independent human validation','official_url':r.get('official_url'),'evidence_sufficiency':'insufficient_from_input'})

PRODUCT_CODES={
 'H330938':['8544.60.6000'],'H342570':['8504.40.95'],'H342571':['8504.40.95'],'H344006':['8504.40.95'],
 'H341677':['9027.10.20'],'H317391_1':['8508.11.00'],'H317391_2':['8509.80.50'],
 'H323452':['8471.60.90'],'H333110':['8518.22.00'],'H319100_1':['8518.21.00','8518.22.00'],'H319100_2':['8517.62.00'],
 'H311957':['8516.29.0090'],'H311978':['5513.21.0020','5513.11.0020'],'H308870':['8431.49.9044'],
 'H311151':['3815.19.0000'],'H316154':['9030.33.3800'],'H320060':['8431.20.00'],'H322923':['8716.80.5090'],
 'H314080':['5903.20.25'],'H330005':['8215.20.0000','8215.99.5000'],'H316387':['8708.80.65'],
 'H336040':['9403.20.0050'],'H342749':['8421.99.1040'],'H332948':['2811.22.1000'],'H318593':['8425.42.00'],
 'H340899':['8508.11.00'],'H345780':['8421.21.00'],'H333371':['6116.10.65'],'H317208':['9403.90.8041'],
 'H336964':['8504.40.4000'],'H333673':['8543.70.98'],'H313009':['3824.99.3900'],'H327850':['9032.10.0030'],
 'H338585':['0304.61.00'],'H338459':['0304.61.00'],'H338586':['0304.61.00'],'H316644':[],
 'H318221':['3921.19.00'],'H323434':['8479.89.94','8479.90.94','8483.40.10'],'H310389':['5603.92.0090'],'H335786':['4819.20.0040'],
 'H324564':['9025.19.8040'],'H330748':[],'H312651':['8419.50.10','8419.50.50'],'H310618':['8413.91.90']}
for row in records:
    codes=PRODUCT_CODES.get(row['case_id'],PRODUCT_CODES.get(row['rulingNumber'],[]))
    holding=N(D[row['rulingNumber']]['sections'].get('HOLDING',''))
    refs=[]
    for code in codes:
        if code not in holding:errors.append({'id':row['case_id'],'error':'PRODUCT CODE absent from HOLDING: '+code});continue
        a=holding.index(code);refs.append({'code':code,'section':'HOLDING','quote':holding[max(0,a-110):min(len(holding),a+len(code)+170)],'normalized_section_offset':a})
    row['product_hts']=codes
    row['product_hts_provenance']=refs
    row['product_hts_digits']=[len(re.sub(r'\D','',c)) for c in codes]
    row['rule_hts']=row['hts']
    row['product_hts_task_assumption']='Oracle CBP base classification supplied; excludes HS classification from the predictive task. Eight-digit codes are not padded to ten digits.'
    row['product_hts_integrity']='verified_in_holding' if codes else 'not_available'
    if row['rulingNumber']=='H342749':
        row['product_hts_integrity']='published_holding_typographic_inconsistency'
        row['product_hts_alternative_analysis']=['8421.99.01']
        row['code_baseline_eligible']=False
        row['annotation_note']+=' Oracle code .1040 is quoted literally from holding but conflicts with .01 in final analysis and .0140 in FACTS; exclude from exact-code comparison unless independently reconciled.'
    else:row['code_baseline_eligible']=bool(codes)

out=ROOT/'datasets/hq_reference.jsonl'
if errors:
    print(json.dumps({'errors':errors,'successful':len(records)},ensure_ascii=False,indent=2))
else:
    out.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in records),encoding='utf-8')
    print(json.dumps({'written':str(out),'rows':len(records),'rulings':len(set(x['rulingNumber'] for x in records)),'labels':dict(collections.Counter(x['reference_disposition'] for x in records)),'benchmark_candidates':sum(x['benchmark_candidate'] for x in records)},ensure_ascii=False,indent=2))
