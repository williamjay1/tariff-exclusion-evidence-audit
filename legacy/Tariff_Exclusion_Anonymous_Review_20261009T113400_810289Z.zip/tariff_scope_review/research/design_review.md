# Tariff exclusion applicability: design and label validity review

Reviewed on 2026-10-07 (Asia/Shanghai). This report contains a proposed design and source-grounded feasibility findings, not experiment results. Ownership: tariff_design agent. Other agents own data, code, literature consolidation and manuscript.

## Route and defensible contribution

- Route: SCI primary, applied AI measurement and decision support.
- Primary standard: independently anchored outcome labels, equal-information comparisons, group/time generalization, selective prediction reliability and evidence traceability.
- Do not use: macroeconomic causal-effect claims, an imposed econometric identification exercise, or classifier accuracy as proof of legal deployment readiness.
- Next workflow: relevant SCI empirical validation modules only; current user explicitly prioritizes substantive content over formatting.

Suggested narrow research question: **Given a dated exclusion provision and a bounded description of product facts, can evidence-constrained applicability assessment reduce erroneous grants of product-specific tariff exclusions at comparable coverage, relative to code matching and textual similarity?**

Potential contribution: a reproducible applicability benchmark that separates product properties, temporal rules and evidentiary sufficiency; a CPU-feasible constrained decision procedure; an empirical account of when identical tariff codes conceal distinct exclusion eligibility. None of these is yet demonstrated. Do not claim the first tariff RAG/graph/abstention system: the literature agent identified ClearDeclare (2026) and HSGraphAgent (ACL 2026) as close prior work.

No mathematical novelty is necessary. Three-valued logic and abstention are established techniques; the scientific contribution must come from a useful task, trustworthy benchmark and a demonstrated increment beyond strong alternatives. A hand-coded rule solver with an end-to-end LLM label loop does not, by itself, establish such an increment.

## Ruling inspection and actual risks

The official web search index exposed full or substantial ruling text even when direct fetch returned 403. A Jina reader check exposed the dynamic site shell, not the ruling body; this is not a full-text retrieval success. Corpus files should be obtained and provenance recorded by the data agent before numerical use. Summary below stays short; the original sources are the reference.

| Ruling | Verified finding | Design implication |
|---|---|---|
| H338585, 2025-07-21 | Frozen tilapia in a 3–5 ounce size range; Section 301 exclusion has a per-fillet 115 g boundary. CBP denied eligibility because of commingling and insufficient entry-linked quantity evidence. | Real disposition is **excluded/denied**, not UNKNOWN or MIXED merely because fish differ in weight. Product conformity and legally adequate proof are separate. The FACTS section contains the protestant's legal arguments, so heading-based extraction alone is unsafe. |
| H330938, 2024-03-05 | Aluminum-core cable with protective copper conductors qualifies for a monopolar-conductor exclusion. The analysis supplies relevant connector and functional details beyond FACTS. | Material word matching would misread copper as disqualifying. A strict FACTS-only input may be insufficient even though the complete ruling resolves eligibility. Claiming autonomous prediction from the original application would be inaccurate. This was read through a secondary mirror; acquire official original before final coding. |
| N351625, 2025-08-13 | Anti-snoring ring classification dispute, 8517 versus 8543, with 9903.02.66. | Exclude from the principal Section 301 product-exclusion task. It is not a usable positive/negative Section 301 exclusion label merely because it contains Chapter 99 text. Official PDF search extract was accessible. |
| N341609, 2024-08-06 | Surgical gown classified in 6210.10.5010; the cited exclusion enumerates that statistical reporting number. | Include as a **whole-code exclusion** control. Code-only should work if code and date are valid. Do not claim every exclusion requires product-attribute reasoning. |
| H342570 and H342571, 2025-07-21 | Static-converter cases with near-identical sample brands, ratings and reasoning; both deny the relevant exclusion after classification analysis. | Group both together. Distinct ruling IDs, importers and protest numbers do not create independent information. Correct final HS code itself can reveal the decision and must not be treated as a predecision observable unless the experiment is explicitly conditional on a known classification. |
| H341677, 2025 | Battery-operated breathalyzers fail the wireless-enabled requirement because autonomous operation without a cable is not wireless communication. | Strong lexical-confound case, but use the factual description of communication capability, not CBP's legal conclusion, as model input. |
| H319100, 2025 | Smart displays fail the cited exclusion because the record does not establish imported-device capability to distribute audio to wireless speakers. | Distinguish a stated negative capability from lack of evidence. This case spans several products, so the display decision must not label all devices in the document. |

Sources:

- https://rulings.cbp.gov/ruling/H338585
- https://www.customsmobile.com/rulings/docview?doc_id=HQ+H330938&highlight=HTS+CODE+CABLE+WIRE (secondary mirror, official acquisition pending)
- https://rulings.cbp.gov/api/getdoc/ny/2025/N351625.pdf
- https://rulings.cbp.gov/ruling/N341609
- https://rulings.cbp.gov/ruling/H342570
- https://rulings.cbp.gov/ruling/H342571
- https://rulings.cbp.gov/api/getdoc/hq/2025/H341677.pdf
- https://rulings.cbp.gov/api/getdoc/hq/2025/H319100.pdf

## Unit of analysis and reference labels

The atomic record should be **product variant × candidate exclusion × relevant entry date or interval × ruling**, not the entire PDF. Multiple products from a ruling remain in one split group. Two different exclusions on the same product are two assessment instances, but share the source group and cannot inflate the count of independent cases.

Maintain two separate outcome objects:

1. `reference_disposition`: `APPLIES`, `DOES_NOT_APPLY`, `UNRESOLVED`, `MIXED_DOCUMENT`.
   - APPLIES requires an affirmative CBP statement linked to this product and provision.
   - DOES_NOT_APPLY requires an explicit rejection or unambiguous operative duty treatment for this provision; boilerplate saying Chinese goods are subject unless excluded is insufficient.
   - UNRESOLVED is used only if CBP expressly declines or defers an applicability decision, or a condition remains unresolved in its operative response. A missing extraction is not an unresolved legal ruling.
   - MIXED_DOCUMENT is a document-level bookkeeping flag for separately resolved products with differing outcomes. Split identifiable products; do not train it as an ordinary product-level fourth class. If products cannot be separated, retain only in a qualitative audit.
2. `evidence_sufficiency`: `DETERMINATE_FROM_INPUT`, `INSUFFICIENT_FROM_INPUT`, `DISPUTED_FACT`, `NOT_AUDITED`.
   - This records whether the permitted input supports a decision. It must not be derived mechanically from the prediction.
   - Unknown evidence is not a negative fact. An evidentiary burden rule may yield a legally negative disposition despite unresolved physical properties; model and label both layers explicitly.

The predictor may output `APPLIES`, `DOES_NOT_APPLY` or `ABSTAIN`. ABSTAIN is an action, not the reference outcome UNRESOLVED. Selective accuracy counts only accepted predictions, and coverage must be reported beside it. Never relabel wrong cases as unknown after seeing results.

Recommended fields: `ruling_id`, `product_id`, `rule_id`, `rule_family`, `rule_text_version`, `decision_date`, `publication_date_if_known`, `entry_date_min/max`, `source_span_offsets`, `fact_text`, `claim_text`, `rule_text`, `outcome_span`, `reference_disposition`, `evidence_sufficiency`, `denial_basis`, `near_duplicate_group`, `related_ruling_group`, `input_scope`, `annotation_method`, `audit_status`.

Denial bases should separate: outside product definition; out-of-code; time invalid; missing evidence/burden of proof; substantive legal interpretation; origin outside scope. This permits interpretable error analysis and prevents a numeric comparator from taking credit for difficult interpretive decisions.

## Information boundary: three tasks that must not be conflated

**Primary tractable task: retrospective applicability reconstruction from redacted ruling facts.** Keep only product descriptions and dated law available to all models; hide the target ruling's legal analysis and outcome. Ruling facts were written after adjudication and may selectively emphasize decisive features. Even with perfect redaction, this is not a prospective test on original importer applications. State this prominently.

**Secondary conditional task: rule application with supplied structured facts.** A source-grounded, AI-assisted fact table is supplied to every comparator. This isolates reasoning/execution from extraction. It can be scientifically useful, but may not be reported as end-to-end document understanding. If the constraint method receives an analyst-coded connector field, all competing classifiers receive that same field.

**Future practical task: prospective predecision product submissions.** Requires genuinely predecision data and later rulings. Do not claim to have performed this without such data.

For a natural-language candidate rule, strip the target ruling's reasoning. Retrieve the provision from independently dated USTR/HTS documents where possible. A provision quoted verbatim in a target decision can be copied into the evidence registry, but the system must not additionally use that decision's applicability reasoning. Record that provenance limitation.

Remove from model inputs: TARIFF NO header and metadata labels; HOLDING; LAW AND ANALYSIS; operative paragraphs in unheaded NY letters; explicit CBP statements of applicability; website titles that encode the ruling result; ruling IDs that enable memorized lookup. Claimant arguments should either be removed or tagged separately, never treated as adjudicated facts.

Do not extract arbitrary postdecision factual statements from analysis after inspecting errors. If a predefined extraction policy permits such factual statements, report a separate richer-input condition for every model. H330938 is a useful stress case for this distinction.

## Split design and contamination control

1. Freeze inclusion criteria before downloading an outcome-balanced sample. Searching only phrases such as eligible/not eligible creates ascertainment bias; document the search queries and treat the corpus as a retrieved applicability sample, not representative trade flows.
2. Normalize facts by removing boilerplate, company/address blocks and IDs. Create near-duplicate groups using character n-gram similarity or token shingles, then verify obvious pairs such as H342570/H342571. A threshold is an engineering choice, not an independently validated duplication detector.
3. Same ruling, same product family, closely related protest, amendment/revocation and near-duplicate groups remain together. Rule versions from reinstatement/extension notices share a stable `rule_family`.
4. Primary split, if sample permits: grouped chronological train/development/test. Once test results are inspected, no further test-guided rule edits may be called held-out. Retain a change log and label later analyses exploratory.
5. Secondary: leave-rule-family-out or leave-product-family-out evaluation. Whole-family exclusion tests transfer rather than merely applying a known rule to another very similar description. If a generic semantic system is evaluated on unseen rules, it still receives their legal texts at inference; no target labels are provided.
6. If the corpus is small, use grouped cross-validation with nested or fixed small hyperparameter choices and report uncertainty over independent groups. Do not market a very small holdout with one or two negative cases as conclusive validation.
7. Open pretrained encoders can have ruling pretraining contamination even with a chronological experimental split. Document model revision/training cutoff if provided; scrub IDs and compare non-pretrained TF-IDF baselines. Contamination cannot be ruled out solely by removing IDs.
8. Synthetic mutations all remain with their parent real case and are excluded from real-case headline metrics, model selection and sample-size claims.

## CPU-feasible baselines and fair information

| Model | Implementation | Why necessary |
|---|---|---|
| Whole-code / code-and-date | Exact applicable statutory code enumeration, official validity dates and origin | Honest lower-complexity alternative; should be strong for whole-code exclusions. Must not use a final adjudicated HS code unless all methods receive it and task is explicitly conditional. |
| TF-IDF or BM25 | Retrieve prior fact records or rule candidates; nearest-neighbor decision with score threshold | Controls for product vocabulary and lexical similarity. Retrieval ranking alone is not eligibility classification; specify aggregation and calibration. |
| Logistic regression / linear SVM | Word+character TF-IDF; optionally supplied attributes; class weights only on training folds | Competitive CPU text baseline. All vectorizers and hyperparameters fit on training data only. |
| Structured ML | Small logistic model, shallow tree or XGBoost on the same structured attributes used by rules | Tests whether transparent constraints improve over learned attribute combinations. Avoid high-dimensional tuning for tiny N. |
| Semantic encoder | Frozen small sentence-transformer embeddings + nearest neighbor or logistic regression | Provides a feasible pretrained semantic comparator. Pin repository revision and cache only on D; do not assume GPU. Sentence similarity does not entail legal compatibility. |
| Optional NLI | Small published NLI model on product evidence × atomic predicate, with neutral/contradiction/entailment aggregation | Adds a semantic entailment comparator only if runnable and its labels/config are verified; not mandatory to install a large model just for appearance. |
| Evidence-constrained method | Predicates linked to fact spans; exact unit/date arithmetic; three-valued evaluation; explicit burden-of-proof exception layer | Candidate method under test. A novel name does not turn established logic into a new algorithm. Evaluate both supplied-fact and end-to-end variants. |

Atomic values are TRUE/FALSE/UNKNOWN. For a conjunction, any supported false predicate defeats that candidate; all true permits applicability; otherwise abstain. This is a computational convention only for clauses faithfully represented as conjunctions. Alternatives, exceptions and scope must be parsed as an explicit expression tree; do not force all law into AND. Conflicting facts, unresolved term interpretation or missing rule provenance trigger abstention, not arbitrary precedence.

Use Python Decimal for money and thresholds, explicit unit conversion constants, half-open or closed date intervals matching official text, and a separate per-item versus shipment-average flag. A per-item ceiling cannot be validated from an average. Non-copper primary conducting medium cannot be reduced to absence of the token copper.

No hidden advantage: if rules are manually compiled by an AI agent with knowledge of all labels, the system is developer-informed and its evaluation is retrospective. Freeze generic predicate operators, hold out rule families where feasible and disclose which mappings were written after reading each ruling. An AI agent's annotations are not independent human expert labels, and agreement between agents is not expert validation.

## Metrics, uncertainty and analysis

Primary metrics: false applicability rate among accepted positive predictions; selective error at matched coverage; coverage; accepted positive and negative counts; full confusion matrix over decided reference cases. Give total independent rulings and rule families beside the expanded instance count.

Secondary metrics: macro-F1 and balanced accuracy for forced-choice comparisons; Brier score and calibration only for actual probability outputs; evidence-support rate and span correctness only where independently checked. Use paired group bootstrap intervals or exact paired tests appropriate to the small sample. Bootstrap clusters are ruling/duplicate groups, not synthetic rows. Zero observed error does not demonstrate zero error in deployment; report finite sample intervals.

Assess asymmetric errors through declared relative cost scenarios rather than claiming an actual customs penalty rate. Tariff-rate differences can express legal exposure per standardized import value; without real entry value and payment data they are not realized economic savings or nationally representative revenue estimates. Do not attribute duty reductions to the model.

Necessary ablations only: (a) remove date filter; (b) treat unknown as false versus abstain; (c) remove unit and per-item checks; (d) semantic similarity alone versus semantic retrieval plus constraints. Ablations must operate on a sufficiently broad test corpus; five hand-selected failure cases can explain mechanisms but cannot establish overall superiority.

Separate synthetic boundary suite: mutate exactly one numeric attribute, date, negation or unit at a time. Maintain semantic validity and a provenance link. Report these as generated metamorphic tests with expected rule consistency, not CBP-confirmed counterfactual rulings or additional real observations. A synthetic boundary test validates code execution, not the truth of a legal interpretation.

## Literature anchors checked for this review

These are scoped methodological checks rather than a systematic review. Original publisher/author pages were consulted, mostly metadata and abstracts; do not claim full-text reading where not performed.

1. Koreeda, Y., & Manning, C. (2021). **ContractNLI: A Dataset for Document-level Natural Language Inference for Contracts.** Findings of EMNLP, 1907–1919. https://doi.org/10.18653/v1/2021.findings-emnlp.164 . Supports evidence-linked entailed/contradicted/not-mentioned task formulation; it does not validate our legal annotations.
2. Hendrycks, D., Burns, C., Chen, A., & Ball, S. (2021). **CUAD: An Expert-Annotated NLP Dataset for Legal Contract Review.** https://arxiv.org/abs/2103.06268 . Shows expert-annotated document extraction as a distinct benchmark contribution; AI-generated coding cannot be described as the same annotation standard.
3. Chalkidis, I., Jana, A., Hartung, D., Bommarito, M., Androutsopoulos, I., Katz, D., & Aletras, N. (2022). **LexGLUE: A Benchmark Dataset for Legal Language Understanding in English.** ACL, 4310–4330. https://doi.org/10.18653/v1/2022.acl-long.297 . Supports standardized multi-baseline evaluation and the need to test legal domain generalization.
4. Vaudaux, O., Bazzoli, C., Coavoux, M., Vial, G., & Vergès, É. (2023). **Pretrained Language Models v. Court Ruling Predictions: A Case Study on a Small Dataset of French Court of Appeal Rulings.** NLLP, 38–43. https://doi.org/10.18653/v1/2023.nllp-1.5 . Their spoiler-cleaned prediction results differ substantially from decision extraction; directly relevant to avoiding outcome leakage.
5. Medvedeva, M., & Mcbride, P. (2023). **Legal Judgment Prediction: If You Are Going to Do It, Do It Right.** https://aclanthology.org/2023.nllp-1.9/ . Distinguishes the data and end-user task needed for actual decision prediction from convenient retrospective classification. DOI metadata should be rechecked by bibliography owner before finalization.
6. Liu, J., Tong, Y., Huang, H., Zheng, B., Hu, Y., Wu, P., Xiao, C., Onizuka, M., Yang, M., & Zheng, S. (2025). **Legal Fact Prediction: The Missing Piece in Legal Judgment Prediction.** https://aclanthology.org/2025.emnlp-main.322.pdf . Distinguishes evidence submitted by litigants from judicially determined legal facts. We do not have the original submissions in CROSS by default.
7. Reimers, N., & Gurevych, I. (2019). **Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks.** EMNLP-IJCNLP, 3982–3992. https://doi.org/10.18653/v1/D19-1410 . Supports efficient semantic representation; does not establish that cosine similarity is legal entailment.
8. Geifman, Y., & El-Yaniv, R. (2019). **SelectiveNet: A Deep Neural Network with an Integrated Reject Option.** ICML/PMLR 97, 2151–2159. https://proceedings.mlr.press/v97/geifman19a.html . Supplies the established risk–coverage framing. We should not claim selective prediction itself as novelty.

## Concrete execution decision

**Stage: design. CONDITIONAL, actively proceed.** The public rulings support a genuine, narrower method question, with clear positive, negative, semantic-confound and evidence-burden examples. Required repair is not more theoretical exposition: construct the source-separated case registry, count independent eligible cases/families, freeze permitted inputs and run equal-information baselines. A strong manuscript is possible only to the strength of those actual results.

Minimum immediate deliverables for the main agent: real-case case table with source-linked outcome spans; group membership and splits; benchmark runs; mismatch audit; a limitations-aware manuscript whose numerical claims come from saved outputs. If corpus coverage is too small for model superiority, retain useful source-grounded measurement findings and code validation, but do not disguise an illustrative engineering prototype as a broad externally validated model. A finished draft may be delivered with honest boundaries; acceptance is not a result that can be guaranteed by an agent.


## Completed HQ source coding (2026-10-07 update)

The official API corpus has now resolved the initial H330938 source uncertainty. The completed agent-coded reference file contains 45 product-rule/review records from 39 HQ rulings: 12 positive, 32 negative and one interpretation-only unresolved record. Thirty-six records from 30 rulings have complete quoted product facts and candidate exclusion language and are marked benchmark candidates; near-duplicate and related-rule grouping reduces these to 25 groups. The model-ready candidates have 11 positive and 25 negative references. A separate source-match audit verified all nonempty fact passages within the source FACTS section, every nonempty rule quote in the ruling, and every reference quote in the ruling. This is span verification, not independent legal-expert validation.

Facts were coded by an AI agent with access to the complete source. Labels are therefore source-grounded agent extraction of authoritative CBP dispositions, not independent human gold labels. Evidence-sufficiency assessments are agent judgments. The predictive model must receive only the fact passages and rule text; never receive disposition, source holding, sufficiency assessment, annotation notes or final metadata tariff codes. The hts field in this file is the candidate provision's required code and cannot be used as a predecision product classification.

Three commingled-fillet refusals and the micro-denier case are retained as evidence/procedure hard cases and excluded from the ordinary attribute benchmark. Five more rulings are separate review records: H316644 has interpretation without a final product disposition; H318221 and H323434 lack a complete quoted candidate provision; H310389 and H335786 concern whole-code eligibility requiring separate classification. No additional model rows were manufactured from repeated model numbers or physical sample counts. Multiple product-rule pairs within H317391, H332948 and H318593 remain clustered.

Expanded-corpus screening uncovered five additional substantive rulings beyond the initial set: H317208, H336964, H333673, H313009 and H327850. This demonstrates that subject/ISSUE screening alone misses decisions with the exclusion outcome located mainly in HOLDING. The screening was targeted, not a claim of exhaustive inclusion of every public CBP decision. Full quantitative claims should name the evaluated corpus snapshot and candidate formation procedure.


## Final coding and task update

Final targeted scan of the 2,482-record corpus added four review-only records (H324564, H330748, H312651, H310618). HQ reference file now has 49 records from 43 rulings (13 eligible, 33 ineligible, 3 unresolved), while the complete primary candidate pool remains 36 records from 30 rulings / 25 groups (11 eligible, 25 ineligible). The earlier 45-record count is superseded. H330748 is a genuine expired-rule time-validity refusal, not an attribute failure; H312651 and H310618 allow classification protests without explicitly deciding the requested exclusion attributes, so no positive exclusion labels were invented.

The parent adopted an explicit oracle-base-classification task: adjudicated product codes may be supplied equally to all methods to isolate exclusion applicability. This is a scoped retrospective task assumption, not stealth leakage. The earlier facts-plus-rule-only recommendation remains the appropriate setting for any claim of assessment without known base classification. Product codes now have exact HOLDING provenance and eight/ten-digit precision; candidate codes remain separate. H342749 has a literal holding typo (8421.99.1040) versus analysis 8421.99.01 and entry 8421.99.0140, and is excluded from exact-code comparison pending independent reconciliation.
