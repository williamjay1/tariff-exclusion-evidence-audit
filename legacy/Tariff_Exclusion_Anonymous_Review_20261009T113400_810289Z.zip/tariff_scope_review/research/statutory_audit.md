# Independent audit of the USTR 2024-01-17 exclusion index

Audit completed 2026-10-07. Read-only source: `F:\AcademicData\tariff_scope_20261007\raw\statutes\ustr_index_20240117_20261007.pdf`.

## Decision and evidence

**The corrected structural extraction passes this independent audit.** The auditor used a separate extraction path based on PDF table geometry (`pdfplumber.extract_tables`) over all 23 pages, rather than reusing the primary parser's regex segmentation or its page-text JSON. It found 397 product-description rows and compared each against the corrected primary `statutory_rules.jsonl`.

| Check | Independently observed | Primary corrected result |
|---|---:|---:|
| Product-description rows | 397 | 397 |
| Note aliases | 429 | 429 |
| Unique note aliases | 429 | 429 |
| Rows containing two note aliases | 32 | 32 |
| Whole-code descriptions | 41 | 41 |
| Distinct 10-digit HTS strings, including historical versions | 337 | 337 |
| Alias-group disagreements | 0 | — |
| Normalized description disagreements | 0 | — |
| HTS-set disagreements | 0 | — |
| Whole-code classification disagreements | 0 | — |
| Non-header table rows without any note | 0 | — |

The two note columns account for 352 reinstated aliases and 77 COVID aliases. Thirty-two table rows carry one of each; thus 352 + 77 - 32 = 397 product-description rows. Aliases are related references to a shared description, not independent observations of distinct product scope.

The audit found no dropped cross-page continuation and no incorrect adjacent-note grouping. Every non-header physical table row contains at least one note, and every extracted product-description row matches a corresponding primary-parser row. Representative page 12 was also rendered and inspected to verify the whole-code row and surrounding multi-line descriptions; page images are temporary audit aids, not new source files.

## Repaired issue

The initial primary extraction included all 23 page footers in the preceding row. Most footers followed the statutory-code parenthesis, but two followed whole-code descriptions: `20(ttt)(iii)(18)` and `20(ttt)(iv)(7)`. Those two rows were incorrectly classified as product descriptions containing additional numbers. The issue was reported before downstream testing. The primary agent removed page footers and reran its parser; the present audit validates the corrected result of 41 whole-code rows. Original PDF and downloaded text were preserved.

## Limits that must remain explicit

1. The PDF calls itself an **Index of Exclusions for Possible Extension**. It is a dated consolidated index, not proof that each exclusion remained in force on a later date. The structural census describes this index.
2. The 337 HTS strings include explicitly referenced historical code versions. They must not be described as 337 simultaneously current codes or 337 nonoverlapping product markets.
3. Text markers such as `quantitative_marker`, `negation_marker`, and `purpose_marker` are transparent lexical indicators. This audit validates structural extraction, not the semantic completeness or construct validity of those indicators.
4. `20(ttt)(iii)(179)` literally contains a width upper limit of **183 m**, adjacent to other dimensions expressed in centimetres. The page rendering confirms this is in the source, rather than a parser conversion error. The source also contains a question mark after a date in this row. The pipeline preserves the text; it is excluded from the local numeric stress-test gold rather than silently repaired.
5. Source conformity does not imply that every legal condition can be applied without customs classification, provenance, temporal eligibility, or product evidence.

## Independent numeric reference construction

The separate file `datasets/numeric_rule_gold.jsonl` contains **60 independently source-read numeric predicate annotations from 60 distinct actual index rows**. Bounds and endpoint inclusivity were manually specified as constants by this separate AI agent from the official descriptions, before access to evaluated model/parser results. The only programmatic validation was that every selected clause is an exact substring of the independent PDF table extraction and that each supplied interval is internally ordered.

The reference has 28 two-bound predicates, 29 upper-bound-only predicates, and 3 lower-bound-only predicates. It covers mass, length, width, thickness, power, current, voltage, transmission range, displacement, and capacity. Each record preserves the source page, full original product description, exact clause, property, unit, and note aliases. No missing lower limit is imputed as zero; absent endpoint inclusivity is null. Canonical unit spelling maps `KW` to `kW`, `liters` to `L`, and `cc` to `cm3` without changing numerical values.

This is **a reference for synthetic local numeric tests**, not 60 additional observed CBP decisions and not 60 complete product-eligibility validations. Other product, temporal, classification, and legal conditions are fixed and assumed satisfied when testing the isolated predicate. Ambiguous width-or-length disjunctions, unspecified range-endpoint semantics, and the 183 m source anomaly were excluded. The annotation was conducted by an AI agent; **there has been no independent human customs-expert review**.

Gold SHA-256 at initial creation: `55c9dd4f3636a2c9adfc74efcd87bfd507933149de06fcc32cb10115113af804`. Creation UTC: 2026-10-07T15:01:06.746230+00:00. The generator refuses to silently overwrite an existing gold file.

## Reproduction files

- `scripts/cbp_audit_statutory.py`: independent PDF-table audit, read-only with respect to the primary parser and source materials.
- `datasets/cbp_statutory_independent.jsonl`: independent table rows with page locators.
- `datasets/cbp_statutory_audit.json`: complete count and disagreement report.
- `scripts/cbp_build_numeric_gold.py`: explicit, source-read annotation constants.
- `datasets/numeric_rule_gold.jsonl` and `numeric_rule_gold_manifest.json`: frozen local-predicate reference and provenance.
