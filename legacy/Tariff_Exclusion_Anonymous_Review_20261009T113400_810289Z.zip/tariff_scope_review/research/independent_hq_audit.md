# HQ 产品—条款标注独立只读审查

审查日期：2026-10-07。审查对象为当时的 `datasets/hq_reference.jsonl`，本文不修改该文件。15 条配对覆盖肯定、否定、同案不同结果、同产品不同条款、缺失属性和冲突测量。本审查仍由 AI 代理执行，不得称为独立人类海关专家复核。

## 判定

**标注审查阶段：所审15条来源与配对核验通过；实验使用仍须满足任务边界。** 15 条的官方处置和产品—规则配对均有可核验依据；未发现把税收请求或处置结论放入所审 `facts` 的情况。将空白折叠后的事实逐项与原始 `FACTS` 节匹配，15/15 通过；条款与参考引文对原始全文匹配，15/15 均通过。发现的两种参考引文截断错误已由原标注代理修复，本审查代理随后重新读取三个相关条目，确认完整否定范围、句边界和原文匹配均正确。下文保留发现过程供审计。正式实验仍须补齐真实 `product_hts`、把参考标签与输入证据充分性分开评分。

## 已修复的问题

1. **H332948_2 与 H332948_4 的引文截断割掉否定范围。** 当前参考引文从 `Ultra Micro Crystals are of a kind used as a catalyst support.` 开始，实际上只是长句末尾，前文是 `do not weigh in favor of finding that either ...`。该截取虽然是源文子串，却呈现出反义孤句。应改为完整三句，从 `Additionally, the remaining Carborundum factors two, three, four, and five, addressed more fully above, do not weigh in favor of finding that either the Ultra Art Crystals or the Ultra Micro Crystals are of a kind used as a catalyst support.` 开始，接 `Therefore, CBP cannot determine whether either product is a catalyst support.` 和 `As such, this Section 301 exclusion is not applicable to either the Ultra Art Crystals or the Ultra Micro Crystals because neither meets the use criteria.`。标签保持 ineligible。
2. **H318593_2 引文首尾都是截断的。** 当前从 `8.43, HTSUS...` 开始，末尾截在另一条规则条件列表。应取完整句：`As U.S. note 20(vv)(103) under subheading 9903.88.43, HTSUS, is limited to hydraulic car jacks with a lifting capacity of not more than 550 kilograms (1,212.54 lbs), and does not cover floor jacks, the exclusion is inapplicable to the subject merchandise.`。标签保持 ineligible。

以上已即时告知 HQ 标注代理并完成修复复核，不需改标签或丢弃整案。引文截断问题说明“子串匹配为真”不保证引用语义完整。下表“引文需修复”为初审发现状态，当前三个相关条目均已修复。

## 逐条意见

| 配对 | 处置核验 | 事实与边界 |
|---|---|---|
| H330938_1 | eligible 正确 | 事实无 no-connectors 明示；不能用肯定裁定填入。35kV 型号与 2000V 规格均超过阈值但仍须保留原差异。 |
| H317391_1 | eligible 正确 | 干式吸尘器组事实有 bagless/upright、≤1500 W、≤4 L。22 型号合为一组合理。 |
| H317391_2 | ineligible 正确 | 湿式地毯清洁器与同案吸尘器不同；最终基础分类是 8509.80.50，候选规则是 8508.11.0000，应排除精确同码主样本而保留代码不同对照。不能零补位。 |
| H323452_1 | ineligible 正确 | 模拟器事实详尽，否定基于 mouse 类型解释；价格 >$70 未给出不妨碍另一必要条件已经失败。最终处置仅列 8471.60.90 八位，不能虚构十位实际码。 |
| H333110_1 | ineligible 正确 | 接收 Bluetooth 不等于把数据分发至无线扬声器。官方因缺乏相应证据而拒绝；严格输入证据任务可能应未决，不能把二者概念混同。 |
| H311957_1 | eligible 正确 | 电壁炉插入件与 <21 kg 在事实节明确；条款 ≤21 kg。源文 ll/II 字形异常已注明。 |
| H322923_1 | eligible 正确 | 三/四轮数量只在图像或分析而未在保留事实中；应保留 insufficient_from_input，不可将图像信息称为纯文本事实。 |
| H332948_1 | eligible 正确 | 花卉干燥用包装明确。事实尾部页码 `1` 是源残留，不属标签泄漏，可在明确记录纯格式清理后去掉。 |
| H332948_2 | ineligible 正确，引文需修复 | 催化剂载体类用途未证明，官方拒绝；不是物理上证明不可能用于载体。 |
| H332948_3 | ineligible 正确 | 同成分、粒径但猫砂主要展示/用途不同，包装上的次要干花说明不自动满足 kind-used 条件。须保留来源解释边界。 |
| H332948_4 | ineligible 正确，引文需修复 | 与 _2 一样为用途未证明。四个配对同一裁定分组，不能当作四个独立事件。 |
| H318593_1 | eligible 正确 | 68.5% 钢不是 100% 钢；规则解释需要 Section XV 金属占优条款，不能以严格字符串材料匹配推导法律属性。 |
| H318593_2 | ineligible 正确，引文需修复 | 6000 lb 显著超过550 kg，无需通过另一个 positive 规则反推。最终实际码只列 8425.42.00 八位。 |
| H333371_1 | ineligible 正确 | 保留了申请人48%聚酯声明和后续 CBP 实验室76%纺织份额测量；两者有来源层级，不能平均。该输入含审理过程中形成的实验室证据，必须明确研究并非进口前预测。 |
| H317208_1 | eligible 正确 | 单独包装部件与 kits 已分清；wire shelves 不足证明 other-than-welded-wire-rack-decking，保留证据不足标记合理。 |

## 对正式实验的具体影响

本阶段以实际基础码作为已知输入有明确研究意义，但应报告 **精确同十位码、已知八位码层级相容、码不相容** 三类。八位码与候选十位码前缀相同仅说明相容，不能默认最终统计后缀也相同。主“同码仍需产品语义”结论优先用精确同十位子样本，八位相容者单列敏感性。

官方 reference 是 adjudication disposition；证据状态是 retained-input entailment。H333110、H332948 的否定与 H330938、H322923、H317208 的肯定分别演示：官方拒绝可能来自举证不足，官方肯定也可能依赖公开事实片段之外材料。把规则核验器的 UNKNOWN 对照所有官方二分类直接记错会混淆任务。应并行报告裁定一致性与输入证据充分性，并且披露后者由本项目 AI 标注，未获独立专家金标准。

审核范围为15条有目的抽查，不能把“全部通过来源匹配”外推为整套数据100%标签准确率。裁定公开 FACTS 是裁决后撰写，并不等同于真正预先冻结的进口申请材料。
