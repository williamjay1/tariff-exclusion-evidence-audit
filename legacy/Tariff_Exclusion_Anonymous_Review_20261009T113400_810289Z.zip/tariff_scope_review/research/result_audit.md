# Independent frozen-result audit

Audit status: **PASS**. Independently checked 1277 recorded fields; discrepancies: 0.

Recomputed from benchmark labels and raw neural/classical prediction files using scalar decisions, Counter confusion counts, and Fraction arithmetic. Guard states read from frozen traces; parser not changed or rerun. Existing outputs not rewritten.

Predicted eligible is the positive class. FP means false exemption; FN means false denial. BA is balanced accuracy of the forced binary output. Answered errors and referral counts refer to the separate selective output.

## same_code

n = 73; eligible = 47; ineligible = 26; groups = 41; rulings = 67.

| Model | TP | FN | FP | TN | BA | Binary error rate | Answered | Answered errors | Referrals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Code matching | 47 | 0 | 26 | 0 | 0.500000000 | 0.356164384 | 73 | 26 | 0 |
| DeBERTa NLI | 13 | 34 | 8 | 18 | 0.484451718 | 0.575342466 | 31 | 15 | 42 |
| DeBERTa NLI + numeric guard | 13 | 34 | 8 | 18 | 0.484451718 | 0.575342466 | 21 | 11 | 52 |
| Qwen3 0.6B | 47 | 0 | 26 | 0 | 0.500000000 | 0.356164384 | 73 | 26 | 0 |
| Qwen3 0.6B + numeric guard | 46 | 1 | 26 | 0 | 0.489361702 | 0.369863014 | 52 | 15 | 21 |
| Word TFIDF LR | 19 | 28 | 12 | 14 | 0.471358429 | 0.547945205 | 73 | 40 | 0 |
| Word and character TFIDF LR | 17 | 30 | 6 | 20 | 0.565466448 | 0.493150685 | 73 | 36 | 0 |

## all_code_known

n = 85; eligible = 47; ineligible = 38; groups = 44; rulings = 76.

| Model | TP | FN | FP | TN | BA | Binary error rate | Answered | Answered errors | Referrals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Code matching | 47 | 0 | 26 | 12 | 0.657894737 | 0.305882353 | 85 | 26 | 0 |
| DeBERTa NLI | 13 | 34 | 8 | 30 | 0.533034714 | 0.494117647 | 43 | 15 | 42 |
| DeBERTa NLI + numeric guard | 13 | 34 | 8 | 30 | 0.533034714 | 0.494117647 | 33 | 11 | 52 |
| Qwen3 0.6B | 47 | 0 | 26 | 12 | 0.657894737 | 0.305882353 | 85 | 26 | 0 |
| Qwen3 0.6B + numeric guard | 46 | 1 | 26 | 12 | 0.647256439 | 0.317647059 | 64 | 15 | 21 |
| Word TFIDF LR | 19 | 28 | 12 | 26 | 0.544232923 | 0.470588235 | 85 | 40 | 0 |
| Word and character TFIDF LR | 17 | 30 | 6 | 32 | 0.601903695 | 0.423529412 | 85 | 36 | 0 |

## exact_ten_digit

n = 60; eligible = 45; ineligible = 15; groups = 31; rulings = 55.

| Model | TP | FN | FP | TN | BA | Binary error rate | Answered | Answered errors | Referrals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Code matching | 45 | 0 | 15 | 0 | 0.500000000 | 0.250000000 | 60 | 15 | 0 |
| DeBERTa NLI | 12 | 33 | 2 | 13 | 0.566666667 | 0.583333333 | 25 | 11 | 35 |
| DeBERTa NLI + numeric guard | 12 | 33 | 2 | 13 | 0.566666667 | 0.583333333 | 17 | 8 | 43 |
| Qwen3 0.6B | 45 | 0 | 15 | 0 | 0.500000000 | 0.250000000 | 60 | 15 | 0 |
| Qwen3 0.6B + numeric guard | 45 | 0 | 15 | 0 | 0.500000000 | 0.250000000 | 45 | 8 | 15 |
| Word TFIDF LR | 18 | 27 | 10 | 5 | 0.366666667 | 0.616666667 | 60 | 37 | 0 |
| Word and character TFIDF LR | 17 | 28 | 4 | 11 | 0.555555556 | 0.533333333 | 60 | 32 | 0 |

## NLI-untruncated shared subset

Same-code rows with NLI truncated=false; all models are evaluated on this identical subset.

n = 70; eligible = 47; ineligible = 23; groups = 39.

Excluded IDs: H336040_1, H333673_1, N307830.

| Model | TP | FN | FP | TN | BA | Binary error rate | Answered | Answered errors | Referrals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Code matching | 47 | 0 | 23 | 0 | 0.500000000 | 0.328571429 | 70 | 23 | 0 |
| DeBERTa NLI | 13 | 34 | 8 | 15 | 0.464384829 | 0.600000000 | 29 | 15 | 41 |
| DeBERTa NLI + numeric guard | 13 | 34 | 8 | 15 | 0.464384829 | 0.600000000 | 20 | 11 | 50 |
| Qwen3 0.6B | 47 | 0 | 23 | 0 | 0.500000000 | 0.328571429 | 70 | 23 | 0 |
| Qwen3 0.6B + numeric guard | 46 | 1 | 23 | 0 | 0.489361702 | 0.342857143 | 50 | 13 | 20 |
| Word TFIDF LR | 19 | 28 | 11 | 12 | 0.462997225 | 0.557142857 | 70 | 39 | 0 |
| Word and character TFIDF LR | 17 | 30 | 5 | 18 | 0.572155412 | 0.500000000 | 70 | 35 | 0 |

This is a restriction of the original same-code sample, not a model rerun or a new independent test set.

## Date-purged chronological sensitivity

Cutoff: 2023-01-01. Earlier training rows sharing a group with any later test row are removed. Results here use the separately fitted chronological word/character LR model, not grouped cross-validation predictions.

Training n = 41 (12 ineligible, 29 eligible), 25 groups. Later test n = 28 (22 ineligible, 6 eligible), 20 groups. Selected C = 0.1.

Same-code later test n = 22 (16 ineligible, 6 eligible), 17 groups.

| Model | TP | FN | FP | TN | BA | Binary error rate | Answered | Answered errors | Referrals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Chronological LR, all later raw | 3 | 3 | 18 | 4 | 0.340909091 | 0.750000000 | 28 | 21 | 0 |
| Chronological LR, all later common code gate | 3 | 3 | 13 | 9 | 0.454545455 | 0.571428571 | 28 | 16 | 0 |
| Chronological LR, same-code later | 3 | 3 | 12 | 4 | 0.375000000 | 0.681818182 | 22 | 15 | 0 |

The small number of positive later cases limits precision; this sensitivity is not evidence against pretraining contamination.

## Guard changes, cost arithmetic, and stress counts

{
  "DeBERTa NLI": {
    "corrected": 0,
    "new_errors": 0,
    "balanced_accuracy_delta": 0.0,
    "corrected_case_ids": [],
    "new_error_case_ids": []
  },
  "Qwen3 0.6B": {
    "corrected": 0,
    "new_errors": 1,
    "balanced_accuracy_delta": -0.010638297872340441,
    "corrected_case_ids": [],
    "new_error_case_ids": [
      "H317391_1"
    ]
  }
}

All recorded same-code normalized cost values match an independent per-case Fraction sum, including the refer-all comparator. These are assumed relative cost ratios, not observed money or a validated operational optimum.

| Stress method | Correct / 480 | Three-state accuracy |
|---|---:|---:|
| DeBERTa NLI | 119 / 480 | 0.247916667 |
| Qwen3 0.6B | 161 / 480 | 0.335416667 |
| Numeric predicate execution | 466 / 480 | 0.970833333 |

The synthetic test retains 480 scenario rows, 443 distinct rule/fact/label inputs, 60 source rules, 37 repeated rows, and eight identity-conversion controls. These counts do not represent additional real CBP cases.

## Source composition and source-only diagnostic

Post hoc source-selection/style diagnostic; uses HQ/NY metadata only, never product meaning. Not a semantic baseline.

| Sample | Source | n | Eligible | Ineligible | Groups |
|---|---|---:|---:|---:|---:|
| all_86 | HQ | 37 | 11 | 26 | 26 |
| all_86 | NY | 49 | 36 | 13 | 20 |
| same_code | HQ | 27 | 11 | 16 | 21 |
| same_code | NY | 46 | 36 | 10 | 20 |

### Same-code source: HQ

| Model | TP | FN | FP | TN | BA | Binary error rate | Answered | Answered errors | Referrals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Code matching | 11 | 0 | 16 | 0 | 0.500000000 | 0.592592593 | 27 | 16 | 0 |
| DeBERTa NLI | 6 | 5 | 7 | 9 | 0.553977273 | 0.444444444 | 12 | 6 | 15 |
| DeBERTa NLI + numeric guard | 6 | 5 | 7 | 9 | 0.553977273 | 0.444444444 | 9 | 5 | 18 |
| Qwen3 0.6B | 11 | 0 | 16 | 0 | 0.500000000 | 0.592592593 | 27 | 16 | 0 |
| Qwen3 0.6B + numeric guard | 10 | 1 | 16 | 0 | 0.454545455 | 0.629629630 | 17 | 11 | 10 |
| Word TFIDF LR | 4 | 7 | 7 | 9 | 0.463068182 | 0.518518519 | 27 | 14 | 0 |
| Word and character TFIDF LR | 2 | 9 | 4 | 12 | 0.465909091 | 0.481481481 | 27 | 13 | 0 |

### Same-code source: NY

| Model | TP | FN | FP | TN | BA | Binary error rate | Answered | Answered errors | Referrals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Code matching | 36 | 0 | 10 | 0 | 0.500000000 | 0.217391304 | 46 | 10 | 0 |
| DeBERTa NLI | 7 | 29 | 1 | 9 | 0.547222222 | 0.652173913 | 19 | 9 | 27 |
| DeBERTa NLI + numeric guard | 7 | 29 | 1 | 9 | 0.547222222 | 0.652173913 | 12 | 6 | 34 |
| Qwen3 0.6B | 36 | 0 | 10 | 0 | 0.500000000 | 0.217391304 | 46 | 10 | 0 |
| Qwen3 0.6B + numeric guard | 36 | 0 | 10 | 0 | 0.500000000 | 0.217391304 | 35 | 4 | 11 |
| Word TFIDF LR | 15 | 21 | 5 | 5 | 0.458333333 | 0.565217391 | 46 | 26 | 0 |
| Word and character TFIDF LR | 15 | 21 | 2 | 8 | 0.608333333 | 0.500000000 | 46 | 23 | 0 |

Within each existing outer fold, estimate each source majority using all outer training rows only. Ties predict 0; unseen source falls back to global training majority. No rule/fact text is used.

| Model | TP | FN | FP | TN | BA | Binary error rate | Answered | Answered errors | Referrals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Source-only diagnostic, full 86 | 36 | 11 | 13 | 26 | 0.716312057 | 0.279069767 | 86 | 24 | 0 |
| Source-only diagnostic, same-code 73 | 36 | 11 | 10 | 16 | 0.690671031 | 0.287671233 | 73 | 21 | 0 |

Source-conditioned binary and answered-case error rates are also stored numerically in the JSON audit (binary error rate = 1 − accuracy; answered error rate is explicit). A strong source-only result reveals an association of the curated source mix with outcomes. It does not validate a semantic/legal model or establish that source causes eligibility. Source or correlated writing style can be a shortcut even when the input omits the literal HQ/NY identifier.

## Audit boundaries

Bootstrap quantiles and descriptive risk-ranking curves were code-reviewed previously but not independently resampled here; source-label validity is outside arithmetic audit.

No predictions were regenerated, no threshold was selected from the results, and no existing data or result file was changed. The extra untruncated and chronological same-code summaries are descriptive post-result sensitivity summaries and should be labeled accordingly. The post hoc Qwen 4B comparison was not included because its outputs were not part of this frozen audit.

Input SHA-256 hashes and full exact numerical records are retained in `results/independent_result_audit.json`.
