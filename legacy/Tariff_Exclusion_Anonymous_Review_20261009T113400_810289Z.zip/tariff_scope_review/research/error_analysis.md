# Source-grounded analysis of observed benchmark errors

Status: actual saved NLI, grouped out-of-fold LR and Qwen predictions inspected on 2026-10-07. This is a post hoc, purposive diagnostic sample, not a random error sample or an estimate of mechanism prevalence. No model, prediction, benchmark input or reference label was changed by this analysis. The cases were selected after seeing NLI/LR errors to span missing information, legal category interpretation, numerical roles and negative scope conditions; Qwen outputs were added after its run finished.

The benchmark contains 86 product-rule pairs. The ten cases below all have `code_match=1`; the table explicitly distinguishes exact ten-digit matching from eight-digit prefix compatibility. The latter cannot be called verified identity at ten digits. Product codes are supplied as adjudicated oracle base classifications by the benchmark design. The NLI premise is retained product facts and its hypothesis is the candidate description, with code matching applied separately.

NLI scores are saved entailment/contradiction/unknown softmax outputs, not demonstrated calibrated legal probabilities. Forced binary prediction compares the two outcome scores; selective prediction can abstain when unknown wins. Thus a forced-binary error with a simultaneous selective abstention is not a confident legal recommendation. LR values close to 0.50 are also described as weak decisions, not strong beliefs.

| Case | Official | Code relation | NLI binary / selective | NLI eligible / ineligible / unknown | Word LR | Word+char LR |
|---|---|---|---|---|---|---|
| H330938_1 | eligible | exact 10-digit | ineligible / ineligible | 0.0004 / 0.9938 / 0.0058 | eligible (0.5006) | ineligible (0.4977) |
| H333110_1 | ineligible | 8-digit compatible | eligible / eligible | 0.9788 / 0.0049 / 0.0163 | ineligible (0.3985) | ineligible (0.3558) |
| H318593_2 | ineligible | 8-digit compatible | eligible / eligible | 0.6324 / 0.0701 / 0.2975 | ineligible (0.5000) | ineligible (0.4990) |
| H333371_1 | ineligible | 8-digit compatible | eligible / eligible | 0.4027 / 0.2678 / 0.3295 | ineligible (0.4974) | ineligible (0.4944) |
| H340899_1 | ineligible | 8-digit compatible | eligible / abstain | 0.4509 / 0.0442 / 0.5048 | eligible (0.5038) | eligible (0.5014) |
| H332948_2 | ineligible | exact 10-digit | ineligible / abstain | 0.0010 / 0.0012 / 0.9977 | eligible (0.5018) | eligible (0.5020) |
| N311039_33 | ineligible | exact 10-digit | ineligible / abstain | 0.0039 / 0.0214 / 0.9747 | eligible (0.5052) | eligible (0.5098) |
| N307161 | ineligible | exact 10-digit | eligible / abstain | 0.0586 / 0.0095 / 0.9319 | eligible (0.5432) | ineligible (0.4993) |
| N312588 | ineligible | exact 10-digit | ineligible / ineligible | 0.0010 / 0.9839 / 0.0151 | eligible (0.5010) | ineligible (0.4972) |
| N306552 | eligible | exact 10-digit | ineligible / ineligible | 0.0049 / 0.9270 / 0.0682 | ineligible (0.4955) | ineligible (0.4870) |

## 1. H330938_1: Missing connector evidence and a mixed-material description

Failure category: mixed: input insufficiency and unsupported contradiction.

The retained facts identify an aluminum conducting core and copper wires serving a protective rather than power-transmission role. They do not say whether connectors are fitted. The official positive outcome cannot be established from the full quoted exclusion and the retained facts alone. The NLI contradiction score is nevertheless very high, so its confident refusal is not equivalent to a cautious insufficiency finding. Confusion between copper anywhere in the assembly and the material of the conducting element is a plausible explanation, not an observed model rationale. The analysis quotes the no-connector requirement and asserts that the exclusion criteria are met, but contains no separate connector-specific factual finding. The grant therefore must not be converted into an invented connector observation.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.9497/0.0320/0.0182. This agrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: [M]onopolar conductors for a voltage exceeding 1,000 V, other than of copper and not fitted with connectors (described in statistical reporting number 8544.60.6000)

Exact CBP reference quote (normalized full-text offset 8383, length 242):

> The subject electrical cable conductors meet the criteria set forth in the exclusion language and therefore qualify for the claimed exclusion and are eligible to be entered under subheading 9903.88.67, HTSUS, instead of subheading 9903.88.02.

Official source: https://rulings.cbp.gov/ruling/H330938
Saved NLI input tokens: 240; recorded truncation: False.

## 2. H333110_1: Receiving audio versus distributing it to external wireless speakers

Failure category: unsupported positive decision; missing positive evidence.

The input says Bluetooth data are received and converted into sound. The rule additionally requires distribution to wireless speakers. The NLI system strongly predicts eligibility even though the recipient/source relationship required by the rule is not established. CBP expressly relies on the lack of evidence for distribution to external speakers. A missing capability is not logically equivalent to an expressly absent capability, so a fact-entailment model should be permitted to abstain; the observed grant is the unsupported step. The LR predictions agree with the disposition, but that agreement does not establish that LR learned this relational distinction.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.9305/0.0456/0.0239. This disagrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: Wireless communication apparatus that can receive audio data to be distributed to wireless speakers (described in statistical reporting number 8518.22.0000)

Exact CBP reference quote (normalized full-text offset 9075, length 482):

> There is no evidence that the subject devices, in their condition as imported, are capable of distributing audio data to wireless speakers. Any such data is simply converted into digital audio waves that are distributed to the speaker components housed within the devices themselves. We therefore conclude that the subject devices do not meet the terms of the Section 301 exclusion provided for in U.S. Note 20(jjj) to subchapter III of chapter 99, and subheading 9903.88.57, HTSUS.

Official source: https://rulings.cbp.gov/ruling/H333110
Saved NLI input tokens: 190; recorded truncation: False.

## 3. H318593_2: Lifting capacity versus own mass, with pound-to-kilogram conversion

Failure category: observable numerical and attribute-binding failure.

The facts separately give own mass (26.4 kg) and lifting capacity (6,000 pounds). The candidate rule limits lifting capacity to 550 kg. At the exact conversion 1 lb = 0.45359237 kg, 6,000 lb is 2,721.55422 kg, well above the limit. The NLI grant is inconsistent with an explicit numerical contradiction already available to the model. It is not possible to tell from NLI scores whether the cause was unit conversion, confusion with own mass, or neglect of the condition. The same physical jack is eligible under a different rule (H318593_1); that positive disposition cannot be transferred to this pair.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.9454/0.0351/0.0196. This disagrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: Hydraulic jacks of a kind for raising vehicles, with a lifting capacity of not more than 550 kg (described in statistical reporting number 8425.42.0000)

Exact CBP reference quote (normalized full-text offset 5138, length 255):

> As U.S. note 20(vv)(103) under subheading 9903.88.43, HTSUS, is limited to hydraulic car jacks with a lifting capacity of not more than 550 kilograms (1,212.54 lbs), and does not cover floor jacks, the exclusion is inapplicable to the subject merchandise.

Official source: https://rulings.cbp.gov/ruling/H318593
Saved NLI input tokens: 127; recorded truncation: False.

## 4. H333371_1: Competing claimant and laboratory composition measurements

Failure category: source-priority uncertainty plus threshold evaluation.

Both the importer composition claim (48% polyester) and the CBP laboratory finding (approximately 76% textile) are retained. The rule requires less than 50% textile. NLI selects eligibility, but its three scores are close enough that this is not a high-confidence example. With the stated CBP laboratory result, the threshold fails. The legal presumption given to the CBP laboratory is discussed in the excluded analysis, so a pure fact-entailment system without a source-priority convention can reasonably report conflicting evidence. The observed grant chooses a side without exposing a source-resolution rationale; no claim is made that it actually selected the 48% value internally.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.9435/0.0401/0.0164. This disagrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: Gloves, containing less than 50 percent by weight of textile fibers, coated with rubber or plastics designed for enhanced grip (described in statistical reporting number 6116.10.6500)

Exact CBP reference quote (normalized full-text offset 9855, length 172):

> The work gloves are not eligible for the exclusion from Section 301 duties under U.S. note 20(jjj)(33) to Chapter 99, HTSUS, and corresponding subheading 9903.88.57, HTSUS.

Official source: https://rulings.cbp.gov/ruling/H333371
Saved NLI input tokens: 233; recorded truncation: False.

## 5. H340899_1: Marketing word upright versus the legal/commercial vacuum category

Failure category: domain-category interpretation.

The product names contain Upright, but the physical description states that these are worn as backpacks. Both LR variants grant; forced binary NLI also grants, while selective NLI abstains. The relevant distinction is the commercial category of upright vacuums, not whether a backpack can be held vertically. The facts supply the backpack form; the interpretation that excludes it requires domain knowledge beyond string matching. Dust-receptacle volume (0.64 L) and bin volume (1.9 L) are also distinct, so treating every capacity as the same variable would manufacture a different reason for refusal.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.9182/0.0437/0.0381. This disagrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: Vacuum cleaners, bagless, upright, each with self-contained electric motor of a power not exceeding 1,500 W and having a dust receptacle capacity not exceeding 1 liter (described in statistical reporting number 8508.11.0000)

Exact CBP reference quote (normalized full-text offset 8221, length 386):

> The subject vacuums, however, are distinct from “upright” vacuums because they are designed to be worn on the back of the user, thereby not satisfying the commercial definition of an “upright” vacuum, while also not being “erect on the feet or end.” Therefore, the subject vacuums do not satisfy the criteria of Note 20(ttt)(iii)(123) and are not granted relief from Section 301 duties.

Official source: https://rulings.cbp.gov/ruling/H340899
Saved NLI input tokens: 319; recorded truncation: False.

## 6. H332948_2: Silica material identity versus evidence of catalyst-support use

Failure category: missing use evidence; appropriate NLI abstention.

Ultra Art Crystals satisfy a different flower-preservation exclusion in the same ruling. The audited pair concerns catalyst-support use. The retained description and packaging document drying flowers; they do not establish catalyst-support class or kind. Both LR variants give a weak eligibility decision near 0.50, while NLI puts almost all score on unknown and abstains. Its forced negative prediction agrees with the official refusal, but the selective output better reflects the incomplete evidence. This case must not be narrated as NLI proving that the material could never be a catalyst support. The official refusal is an evidentiary/use-category conclusion.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.9341/0.0433/0.0226. This disagrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: Synthetic silica gel, in amorphous granules, of a kind used as a catalyst support (described in statistical reporting number 2811.22.1000)

Exact CBP reference quote (normalized full-text offset 27046, length 232):

> Therefore, CBP cannot determine whether either product is a catalyst support. As such, this Section 301 exclusion is not applicable to either the Ultra Art Crystals or the Ultra Micro Crystals because neither meets the use criteria.

Official source: https://rulings.cbp.gov/ruling/H332948
Saved NLI input tokens: 252; recorded truncation: False.

## 7. N311039_33: Contact rating versus coil voltage in four relays

Failure category: attribute-role interpretation and numerical bound.

Each relay has a contact rating of 277 VAC, above the rule ceiling of 250 V. Coil voltages vary (12, 110 and 48 V) and must not replace the contact rating in the comparison. Both LR variants predict eligibility just above the decision threshold. NLI correctly refuses in forced binary mode but abstains in its three-way output. The numerical contradiction is explicit once the relevant electrical rating is identified; choosing the relevant rating is a domain interpretation. All four relays and the second candidate exclusion remain dependent observations, not independent replications.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.8924/0.0695/0.0381. This disagrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: Electromechanical relays, for a voltage exceeding 60 V but not over 250 V, with contacts rated at 10 A or more (described in statistical reporting number 8536.49.0075).

Exact CBP reference quote (normalized full-text offset 5701, length 376):

> Based on the pertinent facts, we find that each of the power relays under consideration are not accurately described as noted in enumeration (33) above. Specially, each of the relays are rated at 277 VAC, which exceeds the maximum voltage rating allowed. Therefore, Section XXII, Chapter 99, Subchapter III U.S. Note 20(k), HTSUS, is not applicable to the subject merchandise.

Official source: https://rulings.cbp.gov/ruling/N311039
Saved NLI input tokens: 407; recorded truncation: False.

## 8. N307161: Required dimensions versus broadly matching power-supply language

Failure category: fully observable dimensional mismatch.

The product measures 140 by 150 by 86 mm; the rule specifies 148 by 43 by 335 mm. These triples do not match even under axis permutation. The product power of 850 W satisfies the separate over-500-W condition, so one true attribute cannot make the conjunction true. Word LR grants and word-plus-character LR narrowly refuses. NLI has a weak binary grant but primarily selects unknown. This is an explicit, code-compatible dimensional mismatch; no extra measurement or legal fact is needed to identify it.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.9290/0.0384/0.0326. This disagrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: “Power supplies suitable for physical incorporation into automatic data processing (ADP) machines or units thereof of heading 8471, each with a power output exceeding 500 W, measuring 148mm in length, 43 mm in width and 335 mm in height (described in statistical reporting number 8504.40.6018).”

Exact CBP reference quote (normalized full-text offset 2620, length 310):

> With regard to your request for the applicability of the subject goods to exclusion from Section 301 Trade Remedies (i.e. classification under subheading 9903.88.03, above), it is the opinion of this office that the subject power supply does not meet the exclusionary parameters of Note 20 (w)(29) which reads:

Official source: https://rulings.cbp.gov/ruling/N307161
Saved NLI input tokens: 143; recorded truncation: False.

## 9. N312588: Negative scope condition excluding incorporated electronics

Failure category: negation/composition scope with an omitted tariff-heading mapping.

The facts list integrated circuits, diodes and transistors. The historical candidate rule excludes parts incorporating goods of headings 8541 or 8542. Word LR narrowly grants, while the character-augmented LR and NLI refuse. NLI supplies a useful contrast to its failures: it produces a strong contradiction score here. The mapping of named electronics into headings 8541/8542 is background tariff knowledge rather than an explicit product-fact label. A later rule quoted in N336939 permits fan hubs and LEDs; replacing the present historical wording with that later wording would change the task.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.8933/0.0590/0.0477. This disagrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: Parts and accessories of machines of heading 8471 not incorporating goods of headings 8541 or 8542 (described in statistical reporting number 8473.30.5100).

Exact CBP reference quote (normalized full-text offset 3499, length 472):

> Based on the pertinent facts, we find that the subject aluminum alloy enclosures do not satisfy the description as provided in Annex Enumeration (27) above. The exclusions provided under Note 20(w) are to be administered in their exact form. As you described in your submission, these articles incorporate goods of headings 8541 or 8542. Therefore in our opinion, the exclusion notated under Chapter 99, Subchapter III U.S. Note 20(w)(27) does not apply to these articles.

Official source: https://rulings.cbp.gov/ruling/N312588
Saved NLI input tokens: 144; recorded truncation: False.

## 10. N306552: Electric scooter terminology within an eligible motorcycle provision

Failure category: legal category broader than ordinary product naming.

The four Lime products are called scooters and have 250 or 300 W motors. CBP grants the motorcycle exclusion under the supplied matching code. NLI predicts a strong contradiction and both LR variants refuse. The prediction is consistent with a lexical distinction between scooter and motorcycle, but no internal model explanation was observed. It is a domain-category disagreement, not a numerical failure: the stated powers are below 1,000 W. The present audit does not infer additional wheel alignment or self-propulsion facts from the favorable outcome.

Qwen observation: eligible with conditional eligible/ineligible/unknown scores 0.9150/0.0585/0.0265. This agrees with the official disposition. These are restricted next-token scores, without an observed case-specific explanation; see the protocol-level caution below.

Candidate rule: (86) Motorcycles with electric power for propulsion, each of a power not exceeding 1,000 W (described in statistical reporting numbers 8711.60.0050 or 8711.60.0090)

Exact CBP reference quote (normalized full-text offset 5992, length 216):

> As the subject merchandise qualifies for exclusion from the additional duties imposed by subheading 9903.88.02 per Note 20(v) to Subchapter III, Chapter 99, HTSUS, it must also be entered under subheading 9903.88.17.

Official source: https://rulings.cbp.gov/ruling/N306552
Saved NLI input tokens: 431; recorded truncation: False.

## Findings that these cases support

The observed cases demonstrate that code compatibility is not sufficient for exclusion eligibility. Several contradictions are fully contained in the input (dimensional mismatch and lift-capacity bound), while others depend on legal category meaning or source priority. Missing positive evidence should be separated from an explicitly contradicted condition. A model can disagree with an official positive outcome because decisive information exists only in the later analysis; this does not make hallucinated completion acceptable.

The scores alone do not identify internal failure mechanisms. Statements about attribute binding, literal matching or category semantics above are source-grounded diagnostic interpretations of input/output patterns, not causal findings about model reasoning. A correct label also does not establish a correct rationale, particularly for LR outputs near 0.50.

None of the ten selected NLI inputs is marked truncated. For the additional context-window audit of H336040_1, the exact pinned local tokenizer and the saved only_first truncation setting were replayed without running or modifying the model. The original pair has 746 tokens and the retained pair has 512. Its retained premise ends mid-description at the fourth Pro Series cabinet; the later imported-without-countertops statement is absent. NLI nevertheless refuses, but that correct label cannot demonstrate use of the missing at-entry composition fact. Source availability and model-window availability are separate checks.

## Qwen: an observed single-option collapse under the specified scoring protocol

The completed Qwen/Qwen3-0.6B run uses revision c1899de289a04d12100db370d81485cdf75e47ca, CPU float32 and prompt scope-v1. All 86 raw binary predictions and all 86 selective predictions are eligible; none abstains. Eligible-option scores range from 0.830919 to 0.968914. The raw decisions agree with 47 of 86 official outcomes. Among the 73 code-compatible pairs, the identical grant decision agrees with all 47 positives and falsely grants all 26 negatives. A separately applied code gate can correct code mismatches, but this Qwen run adds no discrimination within code-compatible pairs.

The implementation does not generate and parse a rationale. It obtains the next-token logits for the three single-token letters A, B and C and applies softmax over those three values only. The mapping is fixed: A means all description requirements are established, B means at least one is contradicted, and C means missing facts prevent a decision. Consequently, the saved values are conditional option scores under a restricted scoring protocol, not validated legal probabilities and not the full-vocabulary probability of an instruction-compliant answer. A first-letter or option-position preference is a possible explanation of the collapse; the saved run alone does not establish that explanation.

Eight of the ten diagnostic cases are official negatives and are granted by Qwen. They include the explicit 6,000-lb versus 550-kg lifting-capacity contradiction (H318593_2), the mismatched dimension triples (N307161), the contact-rating ceiling (N311039_33), the negative electronics condition (N312588), and the nonnumerical use and category restrictions. The two positive agreements are H330938_1 and N306552. Agreement on H330938_1 cannot establish complete rule entailment because connector status is not in the retained facts. A uniform positive response is therefore evidence of failure of this particular evaluation configuration to discriminate eligibility, not evidence that every underlying legal distinction was independently reasoned through and misunderstood.

No claim that the small model is representative of larger generative models is supported. The following separately executed check diagnoses this configuration; it does not select a new prompt or replace the main results.

## Executed Qwen protocol audit

This post hoc diagnostic uses the same ten previously selected cases, the same model revision, six CPU threads and float32. The original stored prompts were reused exactly. Thirty forward evaluations cover three cyclic semantic maps; the product facts, candidate rule and all other prompt text are unchanged. Six original prompts were additionally decoded greedily with max_new_tokens=8. This is a sensitivity analysis on a purposive diagnostic sample, not an independently selected generalization set.

The original-map restricted scores replay exactly (maximum absolute difference 0.0). All six greedy completions are the literal letter A followed by the end-of-message token, agreeing with the original restricted-score choice. The bare letter tokens are A=32, B=33 and C=34; leading-space variants are distinct single tokens (space-A=362, space-B=425 and space-C=356). On the original mapping, bare A/B/C account for 0.995729–0.998361 of the full next-token probability. These results do not indicate a scoring-extraction or leading-space omission error on the checked cases. They still do not make the scores calibrated probabilities of legal correctness.

| Rotation | Meaning of A / B / C | Winning bare letters (10 cases) | Semantic decisions | Winning leading-space letters |
|---|---|---|---|---|
| Original | eligible / ineligible / unknown | A: 10 | eligible: 10 | A: 10 |
| First cycle | unknown / eligible / ineligible | A: 10 | unknown: 10 | A: 10 |
| Second cycle | ineligible / unknown / eligible | A: 9; C: 1 | ineligible: 9; eligible: 1 | A: 10 |

Nine of ten cases keep the same letter across all three maps, and zero keep the same semantic decision. The sole changed letter is N312588 under the second cycle, where C still maps to eligible. Thus the diagnostics support strong dependence on the answer-letter/first-option configuration. Because letter A and first presentation position stay coupled, this audit cannot distinguish letter identity from presentation position as the cause. It also does not test alternative instructions, reasoning-enabled generation, model scale or fine-tuning.

The six generation cases are H330938_1, H333110_1, H318593_2, H333371_1, N307161 and N306552. The ten-case mapping test is deliberately not used to choose a favorable rotation. Any manuscript table should keep the original run and identify this audit as post hoc. The most defensible description is that the selected small generative baseline was protocol-sensitive and failed to discriminate under the fixed prompt, while the local score extraction was consistent with generated answers on the checked cases.

## Provenance of this analysis

- datasets/benchmark.jsonl: SHA-256 8e33bb2381212c5a29b63ce1c9fdbcbb1a0ae6c3d228097c748529934589a3f9
- results/benchmark_nli.jsonl: SHA-256 445f425e33ad11e76faf756eeb5b829e1e0ef406691f975ef07d23498288c998
- results/benchmark_classical.jsonl: SHA-256 ec6088c73c4d643462408e6173b46c388e0d720e169b087dc89ad585dc944b36
- results/benchmark_qwen.jsonl: SHA-256 2220987e0f1a90acccc3fb8d154b00c33ce1e58ee2957069d1e822649eddd1c7
- scripts/run_neural.py: SHA-256 c771c0a822b8212552ab89cfbe8f265340502166782b53d6a4a8d04a2ba6f673
- results/qwen_protocol_audit.json: SHA-256 7f7d6adbda5d8ca0cf3a9c124cb231079a6d35db328d982b5a40588e6e90221f
- scripts/audit_qwen_protocol.py: SHA-256 6874dd38cc37675840d426aff663c97300bcd117bb001df656151d549393c2b8

Audit performed by an AI agent with access to reference outcomes and full rulings. It is post-result source analysis and must not be described as blinded independent human annotation.
