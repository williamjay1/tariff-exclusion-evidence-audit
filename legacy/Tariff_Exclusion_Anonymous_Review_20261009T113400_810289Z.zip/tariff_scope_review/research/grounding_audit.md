# Frozen-engine grounding and numerical stress audit

Post hoc diagnostic, 2026-10-07. The constraint engine, benchmark inputs and primary model outputs were not changed. The numeric engine was independently rerun on all 480 synthetic stress cases. Saved NLI and Qwen outputs were complete at 480 cases each. All neural comparisons below use their saved three-way selective prediction, because unknown is a reference state in this task. No new neural training or inference was needed.

## Real-source false refusal: H317391_1

CBP grants the exclusion to the traditional dry vacuum group. The frozen numeric engine instead returns fail: it treats the substring `72600W` inside model identifier `UH72600W` as a 72,600-watt physical measurement and compares it against the 1,500-watt ceiling.

The offending match occupies fact-string offsets [653, 659); the preceding characters are `UH`. The point-value regex at engine line 99 has no left alphanumeric boundary. Its trailing `(?![A-Za-z])` checks only what follows the match, and therefore does not exclude digits inside model identifiers. This is an observed lexical-grounding defect, not a unit-conversion or legal-interpretation disagreement.

The actual statement that motor power does not exceed 1,500 W is a bound and is deliberately omitted by the point-value extractor. The volume statement is also a bound and yields no point candidate. The fabricated power violation therefore takes precedence over an unknown volume predicate. Returning a deterministic refusal is unsafe in this real case even though the engine performs well on clean templated measurements.

Exact official quote:

> All subject merchandise described as traditional vacuum cleaners are accurately described under U.S. Notes 20(nn)(13), while a few subject traditional vacuum cleaner models are also accurately described under U.S. Notes 20(nn)(14). Thus, all subject vacuum cleaner products fall under the scope of the exclusions under subheading 9903.88.35, HTSUS.

Source: https://rulings.cbp.gov/ruling/H317391

The engine remains frozen to preserve the primary comparison. A future repair would need explicit rejection or classification of identifier spans and regression tests on genuine measurements as well as model names. No repaired-performance claim is made. The optional 26 toy identifier examples were not added: the actual observed failure and exact code path already identify the defect, and extra toys would not estimate its real frequency.

## Stress errors: 14 unnecessary unknowns, no wrong determinate decision

Independent replay gives 466/480 correct three-state outputs. The 14 discrepancies are all unknown on determinate cases: nine required pass and five required fail. There are zero false passes, zero false fails and zero unwarranted determinate answers on the 120 truly unknown inputs. Thus these discrepancies are coverage failures, not incorrect binary certainty. This statement applies only to the synthetic single-predicate stress set; H317391_1 shows why it cannot be generalized to real-source safety.

Two unsupported constructions explain the errors. The postposed upper bound `6.5 mm or less in thickness` is left unparsed: the grammar implements `or more`, but not `or less`. This creates six discrepancies under rule 20(ttt)(i)(87). The phrase `not longer than 16 m` is outside the recognized comparator vocabulary: the lower bound is parsed, but the upper quantity remains unparsed. This creates four discrepancies each under rules 20(ttt)(iii)(142) and 20(ttt)(iii)(143). Inputs below a parsed lower bound can still correctly fail; inputs satisfying that lower bound are referred because the upper clause is unresolved.

| Case | Rule | Scenario | Reference | Actual | Unsupported source syntax |
|---|---|---|---|---|---|
| S013_0 | 20(ttt)(i)(87) | inside | pass | unknown | or less |
| S013_1 | 20(ttt)(i)(87) | boundary | pass | unknown | or less |
| S013_2 | 20(ttt)(i)(87) | outside_lower_or_upper | fail | unknown | or less |
| S013_3 | 20(ttt)(i)(87) | outside_upper_or_lower | fail | unknown | or less |
| S013_4 | 20(ttt)(i)(87) | converted_inside | pass | unknown | or less |
| S013_5 | 20(ttt)(i)(87) | converted_outside | fail | unknown | or less |
| S052_0 | 20(ttt)(iii)(142) | inside | pass | unknown | not longer than |
| S052_1 | 20(ttt)(iii)(142) | boundary | pass | unknown | not longer than |
| S052_3 | 20(ttt)(iii)(142) | outside_upper_or_lower | fail | unknown | not longer than |
| S052_4 | 20(ttt)(iii)(142) | converted_inside | pass | unknown | not longer than |
| S053_0 | 20(ttt)(iii)(143) | inside | pass | unknown | not longer than |
| S053_1 | 20(ttt)(iii)(143) | boundary | pass | unknown | not longer than |
| S053_3 | 20(ttt)(iii)(143) | outside_upper_or_lower | fail | unknown | not longer than |
| S053_4 | 20(ttt)(iii)(143) | converted_inside | pass | unknown | not longer than |

The clauses are source-coded in the numeric gold file: thickness appears on source page 5 and both extension-cord length clauses on source page 10. The JSON audit retains each full synthetic fact, exact rule clause and complete execution trace. The source-coded bounds were created separately from the evaluated parser; this audit also checked all 480 template labels with a separate Decimal implementation against those bounds. Reference-label disagreements: 0.

## Duplicate and unit-change sensitivity

Exact deduplication uses (rule_id, facts, y), retaining the first occurrence. It removes 37 repeated rows, leaving 443 distinct rule–fact–outcome triples. The same-input predictions are consistent within all duplicate groups. Deduplication addresses row repetition, not the correlation among cases sharing one of the 60 rules. One repeated thickness failure is removed, leaving 13 numeric errors in the deduplicated set.

| Set | n | NLI correct | Qwen correct | Numeric correct |
|---|---:|---:|---:|---:|
| All synthetic cases | 480 | 119 | 161 | 466 |
| Exact deduplication | 443 | 119 | 157 | 430 |
| Actual unit representation changes | 112 | 0 | 56 | 108 |
| Identity transformations | 8 | 0 | 4 | 8 |
| Scale-changing conversions | 110 | 0 | 55 | 106 |
| Equivalent-unit alias changes | 2 | 0 | 1 | 2 |

The NLI model returns unknown on 474/480 cases, and Qwen returns pass on all 480. Always predicting unknown would score 120/480 and always predicting pass scores 161/480. Consequently, the neural scores primarily expose failure to discriminate under these fixed zero-shot task formulations. In particular, NLI zero correct out of 112 changed-unit cases mostly means abstention (111 cases), not 112 incorrect numerical calculations. The stress comparison should not be generalized into a claim that all neural models cannot perform unit conversion.

The generator labels 120 cases converted_inside or converted_outside. Eight retain V or A unchanged and are identity transformations, so they must not be counted as conversion evidence. The other 112 change the unit representation; the table further separates a numerical scale change from an equivalent-unit alias change, such as cubic centimetres to millilitres. These are controlled synthetic perturbations with all other requirements stipulated as satisfied, not new observed products.

These results support bounded execution of the implemented comparison grammar on clean scalar inputs. They do not establish full statutory coverage, extraction reliability in free text, or reliable complete eligibility decisions. The sharp contrast between the identifier failure and the clean-template results is itself a useful test-design lesson: arithmetic checks and source grounding require separate validation.

## Reproducibility

Frozen engine SHA-256: d1baf202365a737751294db4003ed05660f2499d6135e06684410bf75741a568
Independent numeric replay elapsed time including file reads and report preparation: 0.260 seconds.
Audit code: scripts/audit_grounding.py. Machine-readable output: results/grounding_audit.json. The report and JSON are diagnostic outputs; no principal results were replaced.
Agreement with saved primary numeric traces: 0 state disagreements across 480 available saved cases.
