# Evaluation protocol (recorded before model evaluation)

## Claim and setting
The empirical question is whether explicit condition handling changes decisions about Section 301 product exclusions when the base HTS classification and a candidate exclusion are supplied. The study does not claim new HS classification, causal trade effects, realized tax payments, or first use of selective prediction in tariff work. Main journal route: Expert Systems with Applications (SCIE), backup Applied Intelligence (SCIE).

## Sources and observation units
Search official CROSS for 301 AND exclusion/exclusions/exempt/exclude, dated 2018-01-01 through 2026-10-07. Preserve search responses, original full ruling responses and source manifests. Screen for an actual decision about a Chapter 99 Section 301 exclusion; discard generic 'unless specifically excluded' boilerplate, country-of-origin-only cases, Section 232/337 decisions, and unrelated Chapter 98 relief. Each observation is a ruling-product-candidate exclusion pair. Multi-product rulings can contribute multiple observations but retain one ruling group. Distinct product outcomes must not be collapsed. Explicitly unresolved determinations are retained for descriptive audit, not forced into binary truth labels.

Model inputs contain only quoted product facts from pre-analysis factual passages plus the literal candidate exclusion description and supplied base HTS code where unambiguous. Exclude ruling ID, title, outcome, legal reasoning, parties' legal conclusions, and quoted precedent outcomes. If decisive facts appear only in legal analysis, record the evidence gap; do not silently supply them. Curation is AI assisted, with separate source checking. No human expert annotation is claimed. Reference decisions remain CBP's public determinations; evidence sufficiency is a separate coded variable.

## Comparisons
1. Code match (explicitly supplied relevant candidate rule): admits candidate when code agrees; this is a deliberately coarse practice comparator, not a competitive learned model.
2. Word/character TF-IDF + regularized linear models, fitted only on training data; tune C over 0.1,1,10 using development data.
3. Frozen DeBERTa-v3-small NLI (SNLI/MNLI checkpoint), full scope entailment against product facts; record actual pinned checkpoint, truncation and latency.
4. Frozen Qwen3-0.6B with fixed answer instructions and non-thinking mode, conditioned on the same product facts and scope. This is a resource-constrained generative baseline, not a frontier-model substitute.
5. Condition-aware decision support: semantic matching plus explicit checks for extracted quantitative bounds, exclusions and missing facts. Rule execution is not a novel theorem. The evaluated increment is handling these constraints within the same applicability task. Keep complete audit traces and distinguish automation from assisted rule preparation.

If the corpus is small or highly clustered, prefer transparent grouped cross-validation to a poorly supported single holdout claim. Choose the split after corpus screening and before any outcome-based model fitting. Preserve clusters for duplicate/near-duplicate rulings and shared rule families. Report chronological sensitivity only with adequate class support. Source date does not guarantee no pretraining contamination.

## Primary and supplementary outcomes
Primary: balanced accuracy and false exemption rate (predicted eligible among reference ineligible), with eligibility recall and confusion counts. For abstention: coverage, error among answered cases, false exemptions among all reference negatives, and positive/negative coverage; do not improve accuracy by confusing ABSTAIN with reference UNKNOWN. Compare paired errors and cluster bootstrap intervals; report sample sizes and number of independent clusters. Non-asymptotic binomial intervals are descriptive when dependence is present, not a substitute for clustered uncertainty.

Costs: transparent asymmetric loss over false exemption, false denial and referral; show sensitivity over cost ratios rather than invent operational dollar savings. If surcharge rates are constant, state that rate-weighted error is only a rescaling. No representative population prevalence or trade totals inferred from selected public rulings.

## Rule-boundary stress tests
Separately label any generated products, altered dimensions or missing-fact variants as synthetic. Ground legal predicates in verbatim official descriptions; evaluate numeric boundary crossings, unit conversions and fact deletion without suggesting these are additional real CBP decisions. Split variants by source rule, not rows. Validate the generator's expected labels against an independent arithmetic implementation and source excerpts. Synthetic success supports constraint execution, not real-world legal validity.

## Integrity
Report all pre-specified comparators, including failures. Log changed decisions and their reasons here. Inspect errors only after storing the frozen primary predictions; any revisions require a separate exploratory label. No legal validity claim beyond the selected rule and stated assumptions about origin, timing, classification, and procedure. Publication potential is a design goal, not guaranteed acceptance.

## Recorded supplementary analyses after frozen primary outputs

The fixed Qwen3-0.6B A/B/C protocol returned the eligible option for all 86 observed pairs. An explicitly post hoc audit used ten already selected error-analysis cases with three cyclic option mappings and six greedy short generations. It does not replace the original predictions or optimize a prompt. Following this failure, add one capacity/instruction-model sensitivity: Qwen/Qwen3-4B-Instruct-2507 revision cdbee75f17c01a7cc42f958dc650907174af0554, the exact same user prompt and A/B/C scoring rule, no task fine-tuning, CPU float32. Run the full frozen observed and synthetic sets and preserve both model outputs. This is a post hoc stronger-model sensitivity, not a preregistered comparison or claim of frontier-model coverage. No other candidate checkpoints will be selected by held-out performance.

Stress-design audit found 480 scenario rows but 443 unique rule/fact/state specifications, because 29 upper-only rules repeat the same outside value and four V/A rules have identity conversions. Keep frozen primary scenario weights and also report deduplicated and actual-conversion sensitivity. The gold labels passed independent Fraction arithmetic validation (zero mismatch). Source-rule bootstrap accounts for within-rule repetition.

The primary numeric guard produced a real-case grounding error on H317391_1: product identifier UH72600W was parsed as 72600 W. Preserve this frozen error rather than patch the evaluated engine. It is evidence of an entity/measurement-grounding defect, not incorrect threshold arithmetic. A new engine could be developed separately; none is substituted in the reported experiment.

### Resource amendments and final task framing

The proposed float32 setting for the 4B sensitivity was changed to bfloat16 weights before its observed-case inference, following the documented RAM and CPU checks. The three selected logits are promoted to float32 for softmax. The recorded actual settings, rather than the earlier intended precision, govern reproducibility. The original compact model and NLI runs remain float32. Model version, post-training, native chat template and precision all differ, so this sensitivity cannot isolate a parameter-count effect.

After the unchanged single-case 86-pair run, stress-only batching was selected through an outcome-blind preflight: fixed indices 0, 127, 254 and 479; binary and selective argmax agreement; maximum conditional-score difference at most 0.01; throughput gain at least 1.10. Batch size four, left padding, attention masks and explicit position identifiers met these criteria. The maximum score difference was 0.000044756 and throughput ratio 1.6402. Full stress evaluation retains all 480 slots and original outcomes. Per-row batch timing is allocated throughput, not single-request latency.

The article's main contribution follows the observed evidence: evaluation validity across code screening, product-scope agreement, and local condition execution. The primary journal target is now Artificial Intelligence and Law, whose official page verifies SCIE and SSCI inclusion and whose scope includes legal-AI evaluation and auditing. This change does not erase initial performance comparisons or relabel supplementary analyses as prespecified.

A post hoc single-case input intervention on H317391_1 was additionally recorded with the original engine unchanged. Masking UH72600W changes fail to unknown; explicitly calling the unchanged token a model identifier and not a power measurement leaves fail. This local diagnostic is reported separately and adds no independent observation to the main benchmark.
