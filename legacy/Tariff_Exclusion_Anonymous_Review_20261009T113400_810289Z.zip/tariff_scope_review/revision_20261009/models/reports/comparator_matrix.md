# Comparator matrix

All numerical results must be read from the completed output files and their summaries. The new comparisons below are post hoc revision experiments.

| Comparator | Checkpoint and representation | Input | Decision interface | Role and comparability |
|---|---|---|---|---|
| Frozen NLI | `cross-encoder/nli-deberta-v3-small`, FP32 | Fact premise and exclusion-scope hypothesis | Entailment/contradiction/neutral logits; original binary and selective rules | Existing entailment baseline; no new checkpoint training |
| Frozen Qwen0.6 | `Qwen/Qwen3-0.6B`, FP32 | Frozen scope-v1 fact–rule prompt | Conditional A/B/C next-token scores | Preserve all original outcomes and old protocol diagnostic |
| Frozen Qwen4 | `Qwen/Qwen3-4B-Instruct-2507`, BF16 | Identical scope-v1 user prompt | Conditional A/B/C next-token scores | Existing checkpoint sensitivity; not an isolated parameter-count effect |
| Revised Qwen0.6 semantic | Same frozen 0.6B checkpoint, FP32 | Common revised semantic instruction, unchanged facts and scope | Strict semantic JSON, 48-token cap | Within-checkpoint joint instruction/output sensitivity; not a pure output-format effect; completed on 86 observed pairs |
| Qwen14 ABC | Official `Qwen/Qwen3-14B-GGUF`, Q4_K_M | Exactly the original scope-v1 user prompt | Unmodified next-token A/B/C log probabilities, conditional normalization; binary E≥I and native three-state argmax | Larger-capacity checkpoint under different training/quantization/runtime; binary metrics are compatible with the original decision rule |
| Qwen14 semantic | Same Qwen14 checkpoint and CPU configuration | Common revised semantic instruction, unchanged facts and scope | Strict semantic JSON, 48-token cap | Native three-state interpretation; unknown/invalid never silently mapped to ineligible |
| Granite8 ABC | Official `ibm-granite/granite-3.3-8b-instruct-GGUF`, Q4_K_M | Exactly the original scope-v1 user prompt | Same A/B/C scoring and binary rule | Independent model family; no claim that family, size and precision have been isolated |
| Granite8 semantic | Same Granite8 checkpoint and CPU configuration | Common revised semantic instruction, unchanged facts and scope | Strict semantic JSON, 48-token cap | Paired direct comparator for condition decomposition |
| Granite8 facts-only / rules-only | Same Granite8 configuration | One input component replaced with an empty string; all instruction text unchanged | Original A/B/C scoring | Genuine within-configuration input ablation, compared with Granite8 full input |
| Granite8 condition decomposition | Same Granite8 configuration | Rule-only condition extraction, then facts plus extracted atomic requirements | JSON tree and evidence states; deterministic three-valued AND/OR/NOT combination | Auditable pipeline comparator; source quote validity does not imply semantic validity; structural/quote failures separately flagged |

The two new GGUF checkpoints are additionally evaluated on the same 96 independently frozen constructed mechanism cases under the semantic JSON interface. The original 480 templates are retained without being relabelled as this new diagnostic set. The nine independent protocol probes are excluded from all formal task datasets. New models use native chat templates with thinking disabled, one CPU model resident at a time, six inference threads, 4,096-token context, greedy decoding, and no prompt-cache reuse. We do not compare native three-state agreement or selective risk to forced full-coverage binary balanced accuracy as if they were the same endpoint.
