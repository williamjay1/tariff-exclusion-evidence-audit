# Revision model and protocol results

Status: complete. This file reports completed outputs only.

The independent Qwen0.6 protocol audit crossed six semantic-to-letter mappings with six option orders across nine constructed probes. Restricted next-token decisions were correct in 115 of 324 evaluations (35.5%). The selected letters were A in 210 evaluations, B in 28, and C in 86. Selected display positions were first in 131, second in 64, and third in 129. These repeated probes diagnose the interface and are not 324 independent legal cases.

Complete greedy answers on the nine independent displayed-option probes were all invalid under the one-letter requirement and all reached the eight-token output limit. The observed output was `A: every rule requirement is established by`, the beginning of the displayed option-A explanation. This failure is not omitted or repaired. The earlier six legal-case generation checks used a different, prose-form scope-v1 prompt and returned a single A. Both implementations disabled thinking using the same cached native tokenizer template; their difference cannot be attributed to a thinking-mode change or isolated as a pure case-content effect. Restricted token preference and complete-answer format compliance are distinct measurements.

Under the alternative semantic-JSON instruction, the small checkpoint answered four of nine independent probes correctly, with no invalid or truncated outputs. On all 86 administrative fact–rule pairs, it produced a valid eligible decision; total measured inference time was 350.688 seconds. Consequently, semantic output names did not eliminate the all-eligible behavior of this checkpoint in this experiment. This does not establish a universal limitation of language models.

New comparisons use the official Qwen3-14B and IBM Granite 3.3 8B instruction-tuned GGUF checkpoints with Q4_K_M quantization, local CPU inference, native templates and disabled thinking. Model, training and numerical implementation differences are retained as limitations; they are not a parameter-count causal experiment. The original ABC user instruction is retained for forced binary comparisons, while semantic JSON is evaluated separately as a native three-state response. Unknown and invalid JSON responses are not converted to ineligible. ABC requests deliberately use a one-token scoring budget; their expected limit stops are not full-answer truncation failures.

## qwen14
- Independent abc_original preflight: 6/9 correct restricted first-token decisions. These are fixed simple probes, not administrative-case accuracy estimates.
- Independent semantic_json preflight: 7/9 correct complete generated JSON answers. These are fixed simple probes, not administrative-case accuracy estimates.
- Preflight JSON formatting: 0 invalid answers and 0 output-cap hits.
- abc_original: 86 completed rows; 0 invalid outputs; 86 output-cap hits; 1759.206 measured seconds.
- semantic_json: 86 completed rows; 0 invalid outputs; 0 output-cap hits; 1611.965 measured seconds.
- mechanism: 96 completed rows; 0 invalid outputs; 0 output-cap hits; 770.174 measured seconds.
- Constructed diagnostic agreement: 69/96. Diagnostic references are AI-authored, not human expert gold.
- Recorded execution sessions, including loading and shutdown: 4432.125 seconds. Request-only latency is reported separately above; acquisition is not included.

## granite8
- Independent abc_original preflight: 5/9 correct restricted first-token decisions. These are fixed simple probes, not administrative-case accuracy estimates.
- Independent semantic_json preflight: 4/9 correct complete generated JSON answers. These are fixed simple probes, not administrative-case accuracy estimates.
- Preflight JSON formatting: 0 invalid answers and 0 output-cap hits.
- abc_original: 86 completed rows; 0 invalid outputs; 86 output-cap hits; 707.832 measured seconds.
- semantic_json: 86 completed rows; 0 invalid outputs; 0 output-cap hits; 915.842 measured seconds.
- mechanism: 96 completed rows; 0 invalid outputs; 0 output-cap hits; 514.678 measured seconds.
- facts_only: 86 completed rows; 0 invalid outputs; 86 output-cap hits; 619.551 measured seconds.
- rules_only: 86 completed rows; 0 invalid outputs; 86 output-cap hits; 237.325 measured seconds.
- decomposition: 86 completed rows; 72 invalid outputs; 0 output-cap hits; 416.721 measured seconds.
- Constructed diagnostic agreement: 66/96. Diagnostic references are AI-authored, not human expert gold.
The decomposition comparator made 55 unique rule-extraction calls, of which 12 passed the frozen schema and exact-quotation checks and 43 failed. Cached invalid rules resulted in 72 case-level system abstentions. Only 14 cases proceeded to fact-evidence calls. Among these, 12 triggered the quotation guard and 2 passed without that guard. These are interface and source-integrity outcomes, not independent judgments of legal correctness.
The case file contains operational decisions {'unknown': 82, 'ineligible': 4}. Quotation-guard decisions were {'unknown': 10, 'ineligible': 2}; unguarded valid decisions were {'ineligible': 2}. Invalid-rule fallback unknowns must be excluded from correct native unknown judgments. Guarded unknowns must be identified separately from a model successfully recognizing missing evidence.
Rule extraction consumed 1685.326 completion-request seconds and case evidence consumed 416.721 seconds, for 2102.047 total request seconds. Rule calls had 0 generation-cap hits and 0 input truncations; case evidence had 0 generation-cap hits and 0 input truncations. Thus the observed rejections were not generated-output budget truncations. Strict schema or verbatim-quotation rejection does not by itself prove that the rejected paraphrase or legal interpretation was incorrect.
- Recorded execution sessions, including loading and shutdown: 5198.266 seconds. Request-only latency is reported separately above; acquisition is not included.

The decomposition comparator uses rule-only condition extraction followed by fact-only evidence assessment and deterministic three-valued aggregation, with AND, OR and NOT preserved in the saved tree. Exact quote validation checks source integrity, not semantic correctness. Invalid rule/evidence parses cause separately identified system abstention; unsupported quotations are forced to missing and flagged. Its complete trace is retained for auditing. Completion-request times exclude the separate local template/tokenization calls; whole-session times include those steps, model loading and shutdown. The shared host load varied, and these are observed execution costs rather than controlled model-efficiency comparisons.
