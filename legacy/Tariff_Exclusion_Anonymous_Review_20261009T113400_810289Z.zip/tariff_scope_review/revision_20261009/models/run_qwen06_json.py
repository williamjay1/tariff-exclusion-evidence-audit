"""Same new semantic protocol applied to the old 0.6B checkpoint; frozen old outputs untouched."""
import os,sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent;PROJ=ROOT.parents[1]
sys.path.insert(0,str(PROJ/'deps'))
os.environ.update(HF_HOME=str(ROOT/'cache'/'hf'),HF_HUB_OFFLINE='1',TOKENIZERS_PARALLELISM='false',TEMP=str(ROOT/'temp'),TMP=str(ROOT/'temp'),PYTHONDONTWRITEBYTECODE='1')
import torch
from transformers import AutoTokenizer,AutoModelForCausalLM
from protocols import json_prompt,parse_json,PREFLIGHT,MAPS,ORDERS,letter_prompt
def main():
 torch.set_num_threads(6);torch.set_num_interop_threads(2);torch.manual_seed(20261009)
 p=PROJ/'cache'/'models'/'qwen';tok=AutoTokenizer.from_pretrained(p,local_files_only=True);m=AutoModelForCausalLM.from_pretrained(p,local_files_only=True,dtype=torch.float32,attn_implementation='sdpa');m.eval()
 pre=ROOT/'outputs'/'qwen06_preflight_greedy_letters.jsonl';pre_done={x['case_id'] for x in map(json.loads,pre.read_text(encoding='utf8').splitlines())} if pre.exists() else set()
 for r in PREFLIGHT:
  if r['case_id'] in pre_done:continue
  u=letter_prompt(r,MAPS[0],ORDERS[0]);prompt=tok.apply_chat_template([{'role':'user','content':u}],tokenize=False,add_generation_prompt=True,enable_thinking=False);inp=tok(prompt,return_tensors='pt');st=time.monotonic()
  with torch.inference_mode():g=m.generate(**inp,max_new_tokens=8,do_sample=False,pad_token_id=tok.eos_token_id)
  tail=g[0,inp['input_ids'].shape[1]:].tolist();raw=tok.decode(tail,skip_special_tokens=True);letter=raw.strip() if raw.strip() in 'ABC' and len(raw.strip())==1 else None
  a={'case_id':r['case_id'],'user_prompt':u,'raw_output':raw,'parsed_letter':letter,'parsed_semantic':MAPS[0].get(letter),'invalid_output':letter is None,'stopped_limit':len(tail)>=8 and tail[-1]!=tok.eos_token_id,'expected':r['y'],'seconds':time.monotonic()-st,'output_token_ids':tail}
  with pre.open('a',encoding='utf8') as f:f.write(json.dumps(a,ensure_ascii=False)+'\n')
 data=list(map(json.loads,(PROJ/'datasets'/'benchmark.jsonl').read_text(encoding='utf8').splitlines()));out=ROOT/'outputs'/'benchmark_qwen06_semantic_json.jsonl';done={x['case_id'] for x in map(json.loads,out.read_text(encoding='utf8').splitlines())} if out.exists() else set()
 for i,r in enumerate(data):
  if r['case_id'] in done:continue
  u=json_prompt(r);prompt=tok.apply_chat_template([{'role':'user','content':u}],tokenize=False,add_generation_prompt=True,enable_thinking=False);inputs=tok(prompt,return_tensors='pt');nt=inputs['input_ids'].shape[1];assert nt+48<=8192;st=time.monotonic()
  with torch.inference_mode():g=m.generate(**inputs,max_new_tokens=48,do_sample=False,pad_token_id=tok.eos_token_id)
  tail=g[0,nt:].tolist();raw=tok.decode(tail,skip_special_tokens=True);pred=parse_json(raw)
  a={'case_id':r['case_id'],'model':'qwen06','protocol':'semantic_json','user_prompt':u,'prompt':prompt,'raw_output':raw,'parsed':pred,'selective_prediction':{'eligible':1,'ineligible':0,'unknown':-1}.get(pred),'invalid_output':pred is None,'truncated':False,'stopped_limit':len(tail)>=48 and tail[-1]!=tok.eos_token_id,'output_tokens':len(tail),'output_token_ids':tail,'input_tokens':nt,'seconds':time.monotonic()-st}
  with out.open('a',encoding='utf8') as f:f.write(json.dumps(a,ensure_ascii=False)+'\n')
  if i%10==0:print('qwen06 semantic',i+1,'/',len(data),'seconds',round(a['seconds'],2),flush=True)
 (ROOT/'outputs'/'qwen06_semantic_run.json').write_text(json.dumps({'checkpoint':str(p),'revision':json.loads((p/'provenance.json').read_text())['revision'],'dtype':'float32','threads':6,'temperature':'greedy','max_new_tokens':48,'context':8192,'torch':torch.__version__,'protocol_sha256':hashlib.sha256((ROOT/'protocols.py').read_bytes()).hexdigest(),'benchmark_sha256':hashlib.sha256((PROJ/'datasets'/'benchmark.jsonl').read_bytes()).hexdigest()},indent=2),encoding='utf8')
 print('COMPLETE qwen06 semantic',flush=True)
if __name__=='__main__':main()
