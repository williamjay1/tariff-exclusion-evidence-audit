"""Post-hoc cross-checkpoint scope evaluation; localhost-only CPU llama.cpp."""
import argparse,hashlib,json,math,os,re,subprocess,time,urllib.request,collections,ctypes,socket
from pathlib import Path
from protocols import PREFLIGHT,LABELS,MAPS,ORDERS,letter_prompt,json_prompt,parse_json,scope,RULE_PARSE_PROMPT,evidence_prompt,aggregate
from decomposition_protocol import RULE_PARSE_PROMPT
ROOT=Path(__file__).resolve().parent;PROJ=ROOT.parents[1]
os.environ.update(TEMP=str(ROOT/'temp'),TMP=str(ROOT/'temp'),HF_HOME=str(ROOT/'cache'/'hf'),PYTHONDONTWRITEBYTECODE='1')
PORT=18973;URL=f'http://127.0.0.1:{PORT}'
def memory_status():
 class Mem(ctypes.Structure):
  _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ('total_physical','available_physical','total_pagefile','available_pagefile','total_virtual','available_virtual','available_extended_virtual')]
 m=Mem();m.length=ctypes.sizeof(m);ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));return {k:getattr(m,k) for k,_ in m._fields_ if k!='length'}
def call(endpoint,obj=None,timeout=1800):
 data=None if obj is None else json.dumps(obj).encode()
 req=urllib.request.Request(URL+endpoint,data=data,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=timeout) as r:return json.load(r)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,p.read_text(encoding='utf8').splitlines())) if p.exists() else []
def write(p,a):
 with p.open('a',encoding='utf8') as f:f.write(json.dumps(a,ensure_ascii=False)+'\n')
def old_prompt(r):
 return ('Evaluate only whether the stated product facts satisfy the supplied exclusion description. '
  'This is a historical product-scope task. Origin, timing and any separately checked tariff code are held fixed. '
  'Use only the stated facts. A means all description requirements are established; '
  'B means at least one requirement is contradicted; C means missing facts prevent a decision. '
  'Answer with exactly one letter: A, B or C.\n\nPRODUCT FACTS:\n'+r['facts']+'\n\nEXCLUSION DESCRIPTION:\n'+scope(r['rule_text']))
def formatted(u):
 p=call('/apply-template',{'messages':[{'role':'user','content':u}],'add_generation_prompt':True,'chat_template_kwargs':{'enable_thinking':False,'thinking':False}})['prompt']
 # A disabled Qwen thinking template may include an empty, closed think block,
 # but an open block would invalidate first-answer-token scoring.
 assert p.count('<think>')==p.count('</think>'),'Native template left an open thinking block'
 return p
def generate(u,n=48,n_probs=0):
 p=formatted(u);tok=call('/tokenize',{'content':p,'add_special':False})['tokens']
 if len(tok)+n>4096:raise ValueError(f'Context would truncate: {len(tok)}+{n}')
 st=time.monotonic();a=call('/completion',{'prompt':p,'n_predict':n,'temperature':-1,'seed':20261009,'n_probs':n_probs,'post_sampling_probs':False,'cache_prompt':False,'return_tokens':True,'repeat_penalty':1.0})
 return {'user_prompt':u,'prompt':p,'input_tokens':len(tok),'raw_output':a['content'],'output_tokens':a.get('tokens_predicted'),'truncated':a.get('truncated',False),'stopped_limit':a.get('stop_type')=='limit' or a.get('stopped_limit',False),'seconds':time.monotonic()-st,'llama_response':a}
def get_abc(u,letter_ids):
 a=generate(u,1,2000)
 probs=a['llama_response'].get('completion_probabilities',a['llama_response'].get('probs'))
 if not probs:raise RuntimeError('Missing completion probabilities: '+str(a['llama_response'].keys()))
 top=probs[0]['top_logprobs'];byid={x['id']:x['logprob'] for x in top}
 if not all(i in byid for i in letter_ids):
  # Outcome-blind extraction fallback: request complete vocabulary, not a replacement prompt.
  a=generate(u,1,200000);probs=a['llama_response'].get('completion_probabilities',a['llama_response'].get('probs'));top=probs[0]['top_logprobs'];byid={x['id']:x['logprob'] for x in top}
 if not all(i in byid for i in letter_ids):raise RuntimeError('Cannot recover all three single-letter logits')
 lp=[byid[i] for i in letter_ids];z=max(lp);v=[math.exp(x-z) for x in lp];den=sum(v);p=[x/den for x in v]
 a.update(prob_eligible=p[0],prob_ineligible=p[1],prob_unknown=p[2],binary_prediction=int(p[0]>=p[1]),selective_prediction=[1,0,-1][max(range(3),key=lambda i:p[i])],letter_logprobs=dict(zip('ABC',lp)),bare_letter_mass=sum(math.exp(x) for x in lp),n_returned_logprobs=len(top),score_only_one_token=True)
 # Retain relevant logits and top ten rather than 200k vocab entries per row.
 a['llama_response']['probs_summary']=probs[0].copy();a['llama_response']['probs_summary']['top_logprobs']=top[:10]
 a['llama_response'].pop('completion_probabilities',None);a['llama_response'].pop('probs',None)
 return a
def valid_logic(obj,rule):
 assert isinstance(obj,dict) and set(obj)=={'conditions','logic'}
 cs=obj['conditions'];assert isinstance(cs,list) and 0<len(cs)<=25
 ids=[c['id'] for c in cs];assert len(set(ids))==len(ids)
 for c in cs:assert c['rule_quote'] and c['rule_quote'] in rule and isinstance(c['requirement'],str)
 used=[]
 def walk(x):
  if isinstance(x,str):assert x in ids;used.append(x);return
  assert set(x)=={'op','args'} and x['op'] in ('AND','OR','NOT') and isinstance(x['args'],list) and len(x['args'])>0
  if x['op']=='NOT':assert len(x['args'])==1
  for a in x['args']:walk(a)
 walk(obj['logic']);assert set(used)==set(ids)
 return True
def decompose(data,name):
 ruleout=ROOT/'outputs'/f'{name}_decomposition_rules.jsonl';out=ROOT/'outputs'/f'benchmark_{name}_decomposition.jsonl'
 stored={x['rule_sha256']:x for x in rows(ruleout)};done={x['case_id'] for x in rows(out)}
 for n,r in enumerate(data):
  if r['case_id'] in done:continue
  rule=scope(r['rule_text']);key=hashlib.sha256(rule.encode()).hexdigest()
  if key not in stored:
   rec=generate(RULE_PARSE_PROMPT+rule,768);rec.update(rule_sha256=key,rule_text=rule,model=name)
   try:obj=json.loads(rec['raw_output']);valid_logic(obj,rule);rec.update(parsed=obj,valid=True)
   except (ValueError,KeyError,TypeError,AssertionError) as e:rec.update(parsed=None,valid=False,validation_error=type(e).__name__)
   write(ruleout,rec);stored[key]=rec
  definition=stored[key];record={'case_id':r['case_id'],'model':name,'rule_sha256':key,'rule_parse_valid':definition['valid'],'logic':definition.get('parsed',{}),'conditions':[],'selective_prediction':-1,'parsed':'unknown','pipeline_status':'invalid_rule_parse' if not definition['valid'] else 'pending_evidence'}
  if definition['valid']:
   obj=definition['parsed'];rec=generate(evidence_prompt(r['facts'],obj['conditions']),768);record.update(rec)
   try:
    ev=json.loads(rec['raw_output']);assert set(ev)=={'conditions'};li=ev['conditions'];byid={c['id']:c for c in li};assert len(byid)==len(li) and set(byid)=={c['id'] for c in obj['conditions']}
    states={};trace=[]
    for c in obj['conditions']:
     e=byid[c['id']];assert e['state'] in ('established','contradicted','missing');q=e['fact_quote'];valid=isinstance(q,str) and (q in r['facts'] if q else e['state']=='missing')
     st={'established':1,'contradicted':-1,'missing':0}[e['state']] if valid else 0
     states[c['id']]=st;trace.append({**c,**e,'quote_valid':valid,'effective_state':st,'fact_quote_start':r['facts'].find(q) if q else None})
    val=aggregate(obj['logic'],states);label={1:'eligible',-1:'ineligible',0:'unknown'}[val]
    record.update(parsed=label,selective_prediction={'eligible':1,'ineligible':0,'unknown':-1}[label],conditions=trace,evidence_parse_valid=True,deterministic_aggregate=val,pipeline_status='valid' if all(x['quote_valid'] for x in trace) else 'invalid_quote_forced_missing')
   except (ValueError,KeyError,TypeError,AssertionError) as e:record.update(evidence_parse_valid=False,validation_error=type(e).__name__,pipeline_status='invalid_evidence_parse')
  write(out,record);print('decomposition',name,n+1,'/',len(data),flush=True)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--model',choices=['qwen14','granite8'],required=True);ap.add_argument('--decompose',action='store_true');ap.add_argument('--ablations',action='store_true');ap.add_argument('--preflight-only',action='store_true');args=ap.parse_args();name=args.model
 meta=next(x for x in json.loads((ROOT/'outputs'/'model_manifest.json').read_text()) if x['name']==name)
 minimum_free=(6 if name=='qwen14' else 4)*1024**3;gate_start=time.monotonic();gate_checks=0
 while memory_status()['available_physical']<minimum_free:
  if gate_checks%6==0:
   ms=memory_status();print('RAM_GATE_WAIT',name,round(ms['available_physical']/1024**3,2),'GiB available; minimum',minimum_free/1024**3,flush=True)
   write(ROOT/'outputs'/'resource_gate_log.jsonl',{'model':name,'state':'waiting','minimum_free_bytes':minimum_free,'memory':ms,'waited_seconds':time.monotonic()-gate_start})
  gate_checks+=1;time.sleep(10)
 gate_seconds=time.monotonic()-gate_start
 write(ROOT/'outputs'/'resource_gate_log.jsonl',{'model':name,'state':'passed','minimum_free_bytes':minimum_free,'memory':memory_status(),'waited_seconds':gate_seconds})
 cmd=[str(ROOT/'runtime'/'llama-server.exe'),'-m',meta['inference_path'],'--host','127.0.0.1','--port',str(PORT),'-t','6','-tb','6','-c','4096','-np','1','-b','512','-ub','128','-ngl','0','--fit','off','--jinja','--reasoning','off','--chat-template-kwargs',json.dumps({'enable_thinking':False,'thinking':False}),'--no-webui']
 log=(ROOT/'outputs'/f'{name}_server.log').open('a',encoding='utf8')
 with socket.socket() as probe:probe.bind(('127.0.0.1',PORT))
 initial_memory=memory_status();st=time.monotonic();proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);run_status='started';failure=None
 try:
  for i in range(240):
   if proc.poll() is not None:raise RuntimeError('llama-server exited; inspect log')
   try:
    if call('/health',timeout=2).get('status')=='ok':break
   except Exception:pass
   time.sleep(1)
  else:raise TimeoutError('Server not ready')
  props=call('/props');provenance={'model':meta,'server_command':cmd,'server_pid':proc.pid,'load_seconds':time.monotonic()-st,'resource_gate_wait_seconds':gate_seconds,'resource_gate_minimum_free_bytes':minimum_free,'memory_before_load':initial_memory,'memory_after_load':memory_status(),'llama_props':props,'protocol_sha256':sha(ROOT/'protocols.py'),'decomposition_protocol_sha256':sha(ROOT/'decomposition_protocol.py'),'runner_sha256':sha(Path(__file__)),'benchmark_sha256':sha(PROJ/'datasets'/'benchmark.jsonl'),'sampling':{'temperature':-1,'seed':20261009,'repeat_penalty':1.0,'cache_prompt':False},'context':4096,'dtype':'GGUF Q4_K_M; default FP16 KV','status':'post-hoc revision sensitivity, not a controlled parameter-count experiment'}
  rp=ROOT/'outputs'/f'{name}_run.json'
  if rp.exists():
   old=json.loads(rp.read_text());assert old['model']['sha256']==provenance['model']['sha256'] and old['protocol_sha256']==provenance['protocol_sha256'] and old['benchmark_sha256']==provenance['benchmark_sha256'],'Input/checkpoint/protocol changed: refuse to resume'
  else:rp.write_text(json.dumps(provenance,indent=2),encoding='utf8')
  write(ROOT/'outputs'/f'{name}_run_sessions.jsonl',provenance)
  variants={s:call('/tokenize',{'content':s,'add_special':False})['tokens'] for s in ['A','B','C',' A',' B',' C','\nA','\nB','\nC']};assert all(len(variants[x])==1 for x in 'ABC');letter_ids=[variants[x][0] for x in 'ABC']
  (ROOT/'outputs'/f'{name}_tokenization.json').write_text(json.dumps(variants,indent=2),encoding='utf8')
  pf=ROOT/'outputs'/f'{name}_preflight.jsonl';done={x['key'] for x in rows(pf)}
  # Fixed three permutations paired with orders so every letter/position is seen;
  # full orthogonal diagnostic is independently run on Qwen0.6, not claimed here.
  for r in PREFLIGHT:
   for protocol in ['abc_original','semantic_json']:
    key=r['case_id']+'_'+protocol
    if key in done:continue
    a=get_abc(old_prompt(r),letter_ids) if protocol=='abc_original' else generate(json_prompt(r),48)
    pred={1:'eligible',0:'ineligible',-1:'unknown'}[a['selective_prediction']] if protocol=='abc_original' else parse_json(a['raw_output'])
    a.update(key=key,case_id=r['case_id'],model=name,protocol=protocol,parsed=pred,invalid_output=pred is None,expected=r['y']);write(pf,a)
    print('preflight',name,key,'seconds',round(a['seconds'],2),flush=True)
  if args.preflight_only:run_status='preflight_complete';return
  data=rows(PROJ/'datasets'/'benchmark.jsonl')
  for protocol in ['abc_original','semantic_json']:
   out=ROOT/'outputs'/f'benchmark_{name}_{protocol}.jsonl';done={x['case_id'] for x in rows(out)}
   for n,r in enumerate(data):
    if r['case_id'] in done:continue
    a=get_abc(old_prompt(r),letter_ids) if protocol=='abc_original' else generate(json_prompt(r),48)
    if protocol=='semantic_json':
     pred=parse_json(a['raw_output']);a.update(parsed=pred,invalid_output=pred is None,selective_prediction={'eligible':1,'ineligible':0,'unknown':-1}.get(pred))
    a.update(case_id=r['case_id'],model=name,protocol=protocol);write(out,a)
    if n%5==0:print('benchmark',name,protocol,n+1,'/',len(data),'seconds',round(a['seconds'],2),flush=True)
  numeric=PROJ/'revision_20261009'/'evidence_numeric'/'constructed_diagnostics.jsonl'
  if numeric.exists():
   out=ROOT/'outputs'/f'mechanism_{name}_semantic_json.jsonl';done={x['case_id'] for x in rows(out)}
   for n,r in enumerate(rows(numeric)):
    cid=r.get('case_id',r.get('id'))
    if cid in done:continue
    # Only facts and literal rule enter the prompt; no gold or mechanism tags.
    a=generate(json_prompt({'facts':r['facts'],'rule_text':r['rule_text']}),48);pred=parse_json(a['raw_output'])
    a.update(case_id=cid,model=name,protocol='semantic_json',parsed=pred,invalid_output=pred is None,selective_prediction={'eligible':1,'ineligible':0,'unknown':-1}.get(pred));write(out,a)
    if n%10==0:print('mechanism',name,n+1,'/',96,flush=True)
  if args.ablations:
   for kind in ['facts_only','rules_only']:
    out=ROOT/'outputs'/f'benchmark_{name}_{kind}.jsonl';done={x['case_id'] for x in rows(out)}
    for n,r in enumerate(data):
     if r['case_id'] in done:continue
     reduced={'facts':r['facts'] if kind=='facts_only' else '', 'rule_text':r['rule_text'] if kind=='rules_only' else ''}
     a=get_abc(old_prompt(reduced),letter_ids);a.update(case_id=r['case_id'],model=name,protocol='abc_original',input_ablation=kind);write(out,a)
     if n%10==0:print('ablation',name,kind,n+1,'/',len(data),flush=True)
  if args.decompose:decompose(data,name)
  run_status='complete'
 except BaseException as e:
  run_status='failed';failure=type(e).__name__+': '+str(e);raise
 finally:
  memory_before_shutdown=memory_status()
  if proc.poll() is None:proc.terminate();proc.wait(timeout=30)
  log.close()
  write(ROOT/'outputs'/f'{name}_execution_sessions.jsonl',{'model':name,'status':run_status,'failure':failure,'wall_with_load_and_shutdown_seconds':time.monotonic()-st,'memory_before_shutdown':memory_before_shutdown,'server_pid':proc.pid,'runner_sha256':sha(Path(__file__)),'decomposition_protocol_sha256':sha(ROOT/'decomposition_protocol.py')})
if __name__=='__main__':main()
