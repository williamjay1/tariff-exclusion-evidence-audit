"""Pinned official GGUF downloads. Raw F copies immutable; inference copies D."""
import concurrent.futures as cf
import hashlib,json,os,shutil,time,urllib.request,zipfile,ssl
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RAW=(ROOT/'external_raw_weights')
for p in (ROOT/'cache',ROOT/'outputs',ROOT/'reports',ROOT/'temp',RAW):p.mkdir(parents=True,exist_ok=True)
os.environ['TEMP']=os.environ['TMP']=str(ROOT/'temp')
MODELS=[('qwen14','Qwen/Qwen3-14B-GGUF','530227a7d994db8eca5ab5ced2fb692b614357fd','Qwen3-14B-Q4_K_M.gguf'),('granite8','ibm-granite/granite-3.3-8b-instruct-GGUF','e40e9dd739c7be00fa965c16ce167088190ce114','granite-3.3-8b-instruct-Q4_K_M.gguf')]
TLS=ssl.create_default_context()
def get(url,headers=None):
 for attempt in range(8):
  try:return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'tariff-scope-research/1.0',**(headers or {})}),timeout=90,context=TLS)
  except Exception:
   if attempt==7:raise
   time.sleep(attempt+1)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(16*1024*1024):h.update(b)
 return h.hexdigest()
def raw_write(path,b):
 if path.exists():assert path.read_bytes()==b,'Immutable raw conflict'
 else:path.write_bytes(b)
def main():
 release=json.loads((RAW/'llama_release.json').read_text()) if (RAW/'llama_release.json').exists() else json.load(get('https://api.github.com/repos/ggml-org/llama.cpp/releases/tags/b11516'))
 asset=next(a for a in release['assets'] if a['name']=='llama-b11516-bin-win-cpu-x64.zip')
 raw_write(RAW/'llama_release.json',json.dumps(release,indent=2).encode())
 z=RAW/asset['name']
 if not z.exists():
  with get(asset['browser_download_url']) as r,z.open('wb') as f:shutil.copyfileobj(r,f)
 assert digest(z)==asset['digest'].split(':')[1]
 with zipfile.ZipFile(z) as f:f.extractall(ROOT/'runtime')
 manifest=[]
 for name,repo,rev,file in MODELS:
  meta=json.loads((RAW/(name+'_metadata.json')).read_text()) if (RAW/(name+'_metadata.json')).exists() else json.load(get(f'https://huggingface.co/api/models/{repo}/revision/{rev}?blobs=true'))
  raw_write(RAW/(name+'_metadata.json'),json.dumps(meta,indent=2).encode())
  card=(RAW/(name+'_README.md')).read_bytes() if (RAW/(name+'_README.md')).exists() else get(f'https://huggingface.co/{repo}/raw/{rev}/README.md').read()
  raw_write(RAW/(name+'_README.md'),card)
  s=next(s for s in meta['siblings'] if s['rfilename']==file);size=s['lfs']['size'];expected=s['lfs']['sha256']
  url=f'https://huggingface.co/{repo}/resolve/{rev}/{file}?download=true'
  dest=RAW/file;parts=ROOT/'temp'/name;parts.mkdir(exist_ok=True)
  t=time.monotonic();chunk=4*1024*1024
  if not dest.exists():
   # Resolve the official time-limited CDN link once; its policy covers the file,
   # not one byte range. Reuse avoids repeated HF redirects on every small part.
   with get(url+'&resolve_for_ranges=1',{'Range':'bytes=0-0'}) as rr:
    range_url=rr.url
   def fetch(i):
    lo=i*chunk;hi=min(size,lo+chunk)-1;p=parts/f'{i:05d}.part'
    if p.exists() and p.stat().st_size==hi-lo+1:return 0
    for attempt in range(8):
     try:
      req=urllib.request.Request(range_url,headers={'Range':f'bytes={lo}-{hi}','User-Agent':'tariff-scope-research/1.0'})
      with urllib.request.urlopen(req,timeout=120,context=TLS) as r:
       assert r.status==206,(r.status,i)
       assert r.headers.get('Content-Range')==f'bytes {lo}-{hi}/{size}',(i,r.headers.get('Content-Range'))
       b=r.read()
      assert len(b)==hi-lo+1,(i,len(b),hi-lo+1)
      p.write_bytes(b);return len(b)
     except Exception:
      if attempt==7:raise
      time.sleep(min(10,attempt+1))
   with cf.ThreadPoolExecutor(max_workers=32) as pool:
    futures=[pool.submit(fetch,i) for i in range((size+chunk-1)//chunk)]
    for n,future in enumerate(cf.as_completed(futures),1):
     future.result()
     if n%100==0:print(name,n,'parts',round(time.monotonic()-t,1),'s',flush=True)
   tmp=ROOT/'temp'/(file+'.assembled')
   with tmp.open('wb') as f:
    for i in range((size+chunk-1)//chunk):
     with (parts/f'{i:05d}.part').open('rb') as x:shutil.copyfileobj(x,f)
   assert tmp.stat().st_size==size and digest(tmp)==expected
   shutil.copy2(tmp,dest)
  assert dest.stat().st_size==size and digest(dest)==expected
  target=ROOT/'cache'/file
  if not target.exists():shutil.copy2(dest,target)
  assert digest(target)==expected
  record={'name':name,'repo':repo,'revision':rev,'file':file,'bytes':size,'sha256':expected,'official_sha256_matches':True,'source':'official publisher GGUF','quantization':'Q4_K_M','raw_path':str(dest),'inference_path':str(target),'download_verify_seconds':time.monotonic()-t}
  manifest.append(record)
  (ROOT/'outputs'/'model_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
  print('MODEL_READY',name,json.dumps(record),flush=True)
 print('ALL_MODELS_READY',flush=True)
if __name__=='__main__':main()
