"""v2 rule decomposition interface, clarified before any GGUF inference.

Independent code review identified a double-negation ambiguity in the original
rule-only prompt. This module leaves the earlier semantic/ABC protocol file and
its completed Qwen0.6 hashes unchanged.
"""
RULE_PARSE_PROMPT='''Decompose the exclusion description into a logical expression without using product facts or outside information. Preserve all mandatory conditions, alternatives, nested groups, and conditional exceptions. Do not turn OR into AND. Represent logical negation with NOT in the logic tree. Every atomic requirement must be an affirmative proposition: if the source contains "not X", the leaf requirement is X and the logic applies NOT to that leaf. Do not put a negative requirement under NOT, which would negate it twice. A rule quote remains an exact contiguous source span and may contain the source's negation even when the requirement is its affirmative proposition. Preserve any guard on an exception: an exception applying only when Y holds is NOT(AND(X,Y)), not simply NOT(X).

Example unrelated to the study: "Red objects, except objects with handles" has affirmative conditions c1="The object is red" and c2="The object has handles", with logic AND(c1,NOT(c2)). This example only illustrates the tree convention; do not add these conditions to other rules.

Return exactly one JSON object with keys conditions and logic. conditions is a list of objects with id (c1, c2, ...), requirement (brief affirmative proposition), and rule_quote (verbatim source span). logic is either a leaf id or an object with op (AND, OR, NOT) and args (list of subexpressions; NOT has exactly one argument). No other keys, commentary, or markdown.

EXCLUSION DESCRIPTION:
'''
