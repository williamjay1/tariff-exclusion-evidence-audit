"""Independent 6 semantic mappings x 6 orders x 9 unambiguous probes."""
import os,sys,json,time,hashlib,itertools,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent;PROJ=ROOT.parents[1]
sys.path.insert(0,str(PROJ/'deps'))
os.environ.update(HF_HOME=str(ROOT/'cache'/'hf'),HF_HUB_OFFLINE='1',TOKENIZERS_PARALLELISM='false',TEMP=str(ROOT/'temp'),TMP=str(ROOT/'temp'),PYTHONDONTWRITEBYTECODE='1')
import torch
from transformers import AutoTokenizer,AutoModelForCausalLM
from protocols import *
def main():
 torch.set_num_threads(6);torch.set_num_interop_threads(2);torch.manual_seed(20261009)
 p=PROJ/'cache'/'models'/'qwen';tok=AutoTokenizer.from_pretrained(p,local_files_only=True)
 t=time.monotonic();m=AutoModelForCausalLM.from_pretrained(p,local_files_only=True,dtype=torch.float32,attn_implementation='sdpa');m.eval()
 out=ROOT/'outputs'/'qwen06_protocol_factorial.jsonl'
 done={x['key'] for x in map(json.loads,out.read_text().splitlines())} if out.exists() else set()
 tokens=[tok.encode(l,add_special_tokens=False)[0] for l in 'ABC']
 design={'status':'post-hoc independent protocol diagnostic','mappings':MAPS,'display_orders':ORDERS,'probes':PREFLIGHT,'dtype':'float32','threads':6,'torch':torch.__version__,'revision':json.loads((p/'provenance.json').read_text())['revision'],'protocol_sha256':hashlib.sha256((ROOT/'protocols.py').read_bytes()).hexdigest()}
 (ROOT/'outputs'/'protocol_design.json').write_text(json.dumps(design,indent=2),encoding='utf8')
 jobs=[(f'{r["case_id"]}_m{i}_o{j}',r,i,j) for r in PREFLIGHT for i in range(6) for j in range(6)]
 for n,(key,r,i,j) in enumerate(jobs):
  if key in done:continue
  u=letter_prompt(r,MAPS[i],ORDERS[j]);prompt=tok.apply_chat_template([{'role':'user','content':u}],tokenize=False,add_generation_prompt=True,enable_thinking=False)
  ids=tok(prompt,return_tensors='pt');st=time.monotonic()
  with torch.inference_mode():
   logits=m(**ids).logits[0,-1];p3=torch.softmax(logits[tokens],-1).tolist();rawbest=int(torch.argmax(logits));mass=float(torch.softmax(logits,-1)[tokens].sum())
  chosen='ABC'[max(range(3),key=lambda k:p3[k])]
  rec={'key':key,'case_id':r['case_id'],'mapping_index':i,'display_order_index':j,'mapping':MAPS[i],'display_order':ORDERS[j],'user_prompt':u,'prompt':prompt,'restricted_scores':dict(zip('ABC',p3)),'chosen_letter':chosen,'chosen_semantic':MAPS[i][chosen],'chosen_display_position':ORDERS[j].index(chosen)+1,'full_vocabulary_argmax_token':tok.decode([rawbest]),'bare_letter_mass':mass,'expected':r['y'],'seconds':time.monotonic()-st}
  with out.open('a',encoding='utf8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
  if n%36==0:print('factorial',n+1,'/',len(jobs),flush=True)
 jout=ROOT/'outputs'/'qwen06_protocol_json.jsonl'
 done={x['case_id'] for x in map(json.loads,jout.read_text().splitlines())} if jout.exists() else set()
 for r in PREFLIGHT:
  if r['case_id'] in done:continue
  u=json_prompt(r);prompt=tok.apply_chat_template([{'role':'user','content':u}],tokenize=False,add_generation_prompt=True,enable_thinking=False);ids=tok(prompt,return_tensors='pt');st=time.monotonic()
  with torch.inference_mode():g=m.generate(**ids,max_new_tokens=48,do_sample=False,pad_token_id=tok.eos_token_id)
  tail=g[0,ids['input_ids'].shape[1]:].tolist();raw=tok.decode(tail,skip_special_tokens=True);pred=parse_json(raw)
  rec={'case_id':r['case_id'],'user_prompt':u,'prompt':prompt,'raw_output':raw,'output_token_ids':tail,'output_tokens':len(tail),'parsed':pred,'invalid_output':pred is None,'truncated':len(tail)>=48 and tail[-1]!=tok.eos_token_id,'expected':r['y'],'seconds':time.monotonic()-st}
  with jout.open('a',encoding='utf8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
 a=list(map(json.loads,out.read_text().splitlines()));b=list(map(json.loads,jout.read_text().splitlines()))
 summary={'n':len(a),'correct':sum(x['chosen_semantic']==x['expected'] for x in a),'letter_distribution':dict(collections.Counter(x['chosen_letter'] for x in a)),'display_position_distribution':dict(collections.Counter(x['chosen_display_position'] for x in a)),'by_mapping':{i:sum(x['chosen_semantic']==x['expected'] for x in a if x['mapping_index']==i) for i in range(6)},'by_order':{i:sum(x['chosen_semantic']==x['expected'] for x in a if x['display_order_index']==i) for i in range(6)},'semantic_json_n':len(b),'semantic_json_correct':sum(x['parsed']==x['expected'] for x in b),'semantic_json_invalid':sum(x['invalid_output'] for x in b),'semantic_json_truncated':sum(x['truncated'] for x in b),'wall_seconds':time.monotonic()-t}
 (ROOT/'outputs'/'protocol_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print('COMPLETE',summary,flush=True)
if __name__=='__main__':main()
