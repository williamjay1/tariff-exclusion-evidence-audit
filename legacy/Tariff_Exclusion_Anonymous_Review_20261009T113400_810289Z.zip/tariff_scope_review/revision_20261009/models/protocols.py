"""Fixed post-hoc revision protocols, written before new model outcomes."""
import itertools,json,re
LABELS=('eligible','ineligible','unknown')
DEFS={'eligible':'every rule requirement is established by the stated facts','ineligible':'at least one mandatory requirement is explicitly contradicted by the stated facts','unknown':'no requirement is contradicted, but missing facts prevent establishing every requirement'}
PREFLIGHT=[
 {'case_id':'P01','facts':'The object is a red cube.','rule_text':'The object must be red.','y':'eligible'},
 {'case_id':'P02','facts':'The object is a blue cube. It is not red.','rule_text':'The object must be red.','y':'ineligible'},
 {'case_id':'P03','facts':'The object is a cube. Its color is not stated.','rule_text':'The object must be red.','y':'unknown'},
 {'case_id':'P04','facts':'The object weighs 12 kg.','rule_text':'The object must weigh more than 10 kg.','y':'eligible'},
 {'case_id':'P05','facts':'The object weighs 8 kg.','rule_text':'The object must weigh more than 10 kg.','y':'ineligible'},
 {'case_id':'P06','facts':'The object is made of steel. Its weight is not stated.','rule_text':'The object must weigh more than 10 kg.','y':'unknown'},
 {'case_id':'P07','facts':'The device uses 80 W and operates at 220 V.','rule_text':'The device must use at most 100 W and operate at at least 200 V.','y':'eligible'},
 {'case_id':'P08','facts':'The device uses 120 W and operates at 220 V.','rule_text':'The device must use at most 100 W and operate at at least 200 V.','y':'ineligible'},
 {'case_id':'P09','facts':'The device uses 80 W. Its voltage is not stated.','rule_text':'The device must use at most 100 W and operate at at least 200 V.','y':'unknown'}]
MAPS=[dict(zip('ABC',p)) for p in itertools.permutations(LABELS)]
ORDERS=list(itertools.permutations('ABC'))
def scope(rule):return re.split(r'\(\s*(?:as )?described',rule,flags=re.I)[0].strip()
def base_prompt(facts,rule):
 return ('Evaluate only whether the stated product facts satisfy the supplied exclusion description. '
         'This is a historical product-scope task. Origin, timing and any separately checked tariff code are held fixed. '
         'Use only the stated facts. Do not infer an unstated property from a ruling outcome, product name, or general expectation. '
         'Respect AND, OR, and exceptions in the description.\n\nPRODUCT FACTS:\n'+facts+'\n\nEXCLUSION DESCRIPTION:\n'+scope(rule))
def letter_prompt(row,mapping,order):
 return base_prompt(row['facts'],row['rule_text'])+'\n\nDecision options:\n'+'\n'.join(l+': '+DEFS[mapping[l]]+'.' for l in order)+'\nAnswer with exactly one option letter, without explanation.'
def json_prompt(row):
 return base_prompt(row['facts'],row['rule_text'])+'\n\nDecision definitions:\n'+'\n'.join(l+': '+DEFS[l]+'.' for l in LABELS)+'\nReturn exactly one JSON object with one key, decision, and value eligible, ineligible, or unknown. Do not add explanation or markdown.'
def parse_json(text):
 try:
  a=json.loads(text.strip())
  if isinstance(a,dict) and set(a)=={'decision'} and a['decision'] in LABELS:return a['decision']
 except (ValueError,TypeError):pass
 return None
RULE_PARSE_PROMPT='''Decompose the exclusion description into a logical expression without using product facts or outside information. Preserve all mandatory conditions, alternative conditions, nested groups, and exceptions. Do not turn OR into AND. Represent an exception as NOT applied to its excluded condition. Each leaf must retain an exact contiguous quote from the description. Return exactly one JSON object with keys conditions and logic. conditions is a list of objects with id (c1, c2, ...), requirement (brief plain text), and rule_quote (verbatim). logic is either a leaf id or an object with op (AND, OR, NOT) and args (list of subexpressions; NOT has exactly one argument). No other keys, commentary, or markdown.\n\nEXCLUSION DESCRIPTION:\n'''
def evidence_prompt(facts,conditions):
 return ('For each supplied atomic requirement, evaluate ONLY the stated product facts. '
         'Use established when the facts establish it, contradicted when the facts explicitly contradict it, and missing when the facts do not decide it. '
         'Absence of a property in the text is missing, not proof of its negation. Do not use external knowledge. '
         'For established and contradicted, give one exact contiguous quote from the PRODUCT FACTS as evidence. For missing use an empty quote. '
         'Return exactly one JSON object with key conditions, a list of objects each with id, state (established, contradicted, missing), and fact_quote. '
         'No commentary or markdown.\n\nPRODUCT FACTS:\n'+facts+'\n\nREQUIREMENTS:\n'+json.dumps(conditions,ensure_ascii=False))
def aggregate(logic,states):
 if isinstance(logic,str):return states[logic]
 op=logic['op'];a=[aggregate(x,states) for x in logic['args']]
 if op=='NOT':return -a[0] if a[0] else 0
 if op=='AND':return -1 if -1 in a else (0 if 0 in a else 1)
 if op=='OR':return 1 if 1 in a else (0 if 0 in a else -1)
 raise ValueError(op)
