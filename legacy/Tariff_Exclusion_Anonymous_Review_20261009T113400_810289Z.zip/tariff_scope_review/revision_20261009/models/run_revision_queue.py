"""Wait for verified official checkpoints then run sequential CPU jobs."""
import json,os,subprocess,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def ready(name):
 p=ROOT/'outputs'/'model_manifest.json'
 try:return any(x['name']==name and x['official_sha256_matches'] for x in json.loads(p.read_text()))
 except (FileNotFoundError,ValueError):return False
def main():
 for name in ['qwen14','granite8']:
  while not ready(name):time.sleep(5)
  print('QUEUE_READY',name,flush=True)
  cmd=[sys.executable,'-B','-u',str(ROOT/'run_gguf_models.py'),'--model',name]
  if name=='granite8':cmd+=['--ablations','--decompose']
  p=subprocess.run(cmd,check=False)
  if p.returncode:raise RuntimeError(f'{name} failed with {p.returncode}; preserve outputs and inspect before restart')
  print('QUEUE_COMPLETE',name,flush=True)
if __name__=='__main__':main()
