# Revision interface audit

This is a bounded read-only replay and code review, not an independent external validation.

The final v2 implementation was independently rerun on the already evaluated 33 restricted-text numerical cases and 96 constructed inputs. Every saved prediction was reproduced: **24/33**, **73/96**, and **66/88 exact unique constructed inputs**. No source file was altered. The final numerical-reference hash is `85675a17300559c6830ddb8471611a65f1933767a9eb55e2f53efaf4fe0b49e6`.

These are same-suite post hoc repairs, including a second correction after the initial repair run. They cannot be described as held-out generalization. The parser retains a limited lexical grammar; identifier boundaries and motor/lamp binding are not general entity resolution. General quantifiers, legal scope, exceptions and compound-unit reasoning remain outside its claim.

For the new model runner, the three recovered letter log probabilities are renormalized correctly; forced binary scoring and native three-state scoring are separate. Strict JSON failure remains invalid. Invalid rule/evidence parsing defaults operationally to referral, but the statistics explicitly scores it as invalid rather than a correct unknown. The AND/OR/NOT combination is internally coherent.

One substantive interface ambiguity was identified before new inference: negated requirements under NOT could produce double negation. The model agent clarified the decomposition prompt to use affirmative leaves and logic-level negation, with guarded exceptions, in a separately hashed module before any new GGUF result. Literal quote matching and schema validation still establish provenance and syntax only, not entailment or requirement completeness.

The semantic JSON comparison is a joint instruction/output-protocol sensitivity analysis, because its instructions also clarify missing facts and logical scope. The bounded audit found no remaining fatal code discrepancy; it does not certify legal applicability or external model reliability.
