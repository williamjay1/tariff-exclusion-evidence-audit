"""Sensitivity only: exclude documented NLI-truncated cases, retain AI references."""
from common import *
from analyze_new_models import assess
from collections import Counter
from sklearn.metrics import f1_score
E=ROOT/'revision_20261009/evidence_numeric'
allrows=load_rows();raw=read(ROOT/'results/benchmark_nli.jsonl');q={r['case_id']:r for r in raw}
primary=[r for r in allrows if r['code_match']==1]
removed=[r for r in primary if q[r['case_id']]['truncated']]
rows=[r for r in primary if not q[r['case_id']]['truncated']]
assert len(removed)==3 and len(rows)==70
refpath=E/'evidence_operational_reference.jsonl'
refs={r['case_id']:{**r,'aggregate_evidence_state':r['operational_evidence_state']} for r in read(refpath)}
pm={r['case_id']:{'native':r['selective_prediction']} for r in raw}
metric,boots=assess(rows,pm,refs,bootstrap_plan(rows))
# Independent point and explicit-row resampling verification.
mapping={'support':1,'refute':0,'unknown':-1}
def rates(sample):
    y=[mapping[refs[r['case_id']]['aggregate_evidence_state']] for r in sample]
    p=[pm[r['case_id']]['native'] for r in sample];acc=sum(a==b for a,b in zip(y,p))/len(sample)
    result={'evidence_accuracy':acc}
    if len(set(y))==3:
        ct=Counter(y);pc=Counter(p);tp={k:sum(a==b==k for a,b in zip(y,p)) for k in [1,0,-1]}
        result['three_class_balanced_accuracy']=sum(tp[k]/ct[k] for k in tp)/3
        result['macro_f1']=sum(2*tp[k]/(ct[k]+pc[k]) for k in tp)/3
    return result
for k,v in rates(rows).items():assert np.isclose(v,metric['metrics'][k]['value'])
groupnames=sorted({r['group'] for r in rows});rng=np.random.default_rng(BOOT_SEED)
ind={k:[] for k in rates(rows)}
for _ in range(B):
    draw=rng.choice(groupnames,len(groupnames),replace=True)
    sample=[r for g in draw for r in rows if r['group']==g]
    for k,v in rates(sample).items():ind[k].append(v)
for k,v in ind.items():
    c=metric['metrics'][k];assert np.allclose(np.quantile(v,[.025,.975]),[c['lower'],c['upper']])
result={'protocol':'Post hoc sensitivity removing only documented NLI truncations from primary73; unchanged native predictions and operational AI reference. Main73 unchanged.',
 'reference_target':'Complete retained-input AI evidence reference, not model-specific truncated-text coding',
 'removed':[{'case_id':r['case_id'],'group':r['group'],'source':r['source'],
             'input_tokens':q[r['case_id']]['input_tokens'],'AI_reference':refs[r['case_id']]['aggregate_evidence_state']} for r in removed],
 'sample_reference_counts':dict(Counter(refs[r['case_id']]['aggregate_evidence_state'] for r in rows)),
 'metrics':metric,'independent_verification':{'point_metrics':True,'literal_group_resampling':True,'B':B},
 'source_hashes':{str(p):sha(p) for p in [ROOT/'results/benchmark_nli.jsonl',refpath]}}
dump(OUT/'nli_untruncated_sensitivity.json',result)
print(json.dumps(result,indent=2))
