from common import *
E=ROOT/'revision_20261009/evidence_numeric'
a=json.loads((E/'numeric_paired_differences.json').read_text('utf8'))
z=read(E/'numeric_paired_case_indicators.jsonl');ids={r['case_id'] for r in z}
rows=[r for r in load_rows() if r['case_id'] in ids];lookup={r['case_id']:r for r in z}
assert len(rows)==33
groups,u,mult=bootstrap_plan(rows)
assert len(u)==16 and max(sum(groups==g) for g in u)==15
for r in rows:assert r['group']==lookup[r['case_id']]['group']
checks=[]
for key,q in a['comparisons'].items():
    dif=np.array([lookup[r['case_id']]['agreement'][q['comparison_A']]-lookup[r['case_id']]['agreement'][q['comparison_B']] for r in rows])
    total=np.array([dif[groups==g].sum() for g in u]);size=np.array([sum(groups==g) for g in u])
    draws=(mult@total)/(mult@size)
    assert np.isclose(dif.mean(),q['A_minus_B_agreement_rate'])
    assert np.allclose(np.quantile(draws,[.025,.975]),q['percentile_95_interval_rate'],atol=1e-12)
    checks.append(key)
report={'passed':True,'comparisons_verified':checks,'n':len(rows),'groups':len(u),
 'method':'Independent multiplicity-matrix calculation matched source explicit-index row resampling; same original group labels and shared draws.'}
dump(OUT/'numeric_paired_independent_verification.json',report);print(json.dumps(report))
