"""Create independent audit findings without modifying source/reference data."""
from common import *

def main():
    q=json.loads((OUT/'independent_numeric_computational_audit.json').read_text())
    issues=[
      {'id':'NUM-A1','severity':'high','status':'resolved_verified','case_id':'H318593_1',
       'issue':'Dimensions explicitly exclude the handle, while the candidate scope does not restrict its measurement to the enclosure.',
       'resolution':'Three dimensions changed to unknown/unavailable source-coded fields. Own mass remains supported. Final reference fields and execution checked.'},
      {'id':'NUM-A2','severity':'high','status':'resolved_verified','case_id':'N311039_33',
       'issue':'Continuous hull over different products and alternative voltage roles erased definite per-product violations.',
       'resolution':'Per-product coil/contact alternatives retained. Subject states fail/unknown/fail/fail; the all-listed-products claim is fail. A disclosed test-only binding adapter invokes the frozen comparator for each alternative.'},
      {'id':'NUM-A3','severity':'medium','status':'reporting_boundary_required',
       'issue':'Reference-rule/reference-fields 33/33 compares an executor with the same source coding that defines its input and target.',
       'resolution':'Call it execution/internal consistency, not independent legal accuracy or end-to-end validation. No human/expert annotations exist.'},
      {'id':'NUM-A4','severity':'medium','status':'reporting_boundary_required',
       'issue':'96 constructed rows include only 88 exact unique fact-rule inputs, 48 paired comparisons and 12 purposively chosen mechanism families.',
       'resolution':'Do not present 96 independent trials. Report family/pair counts and shared controls. Point correctness is design-weighted. Do not use iid row confidence intervals.'},
      {'id':'NUM-A5','severity':'medium','status':'reporting_boundary_required',
       'issue':'Input scripts omit outcomes, but coding agents had prior project exposure; final 8 component-binding rules were also revised after an initial engine run.',
       'resolution':'Use outcome-masked, source-coded AI diagnostic references. Preserve post-run grammar erratum. Do not claim blinded experts or an independently sampled external validation set.'},
      {'id':'NUM-A6','severity':'medium','status':'reporting_boundary_required',
       'issue':'Layer interventions supply attribute/subject bindings, disambiguation and sometimes conversion/hulls, not only numerical extraction. One layer now includes an added reference-only binding adapter.',
       'resolution':'Describe supplied source-coded representations, not a deployable extractor improvement or unchanged whole engine. Equal auto-fact layer scores do not establish absence of rule-parsing errors.'},
      {'id':'NUM-A7','severity':'low','status':'disclosed_assumption',
       'issue':'Unbounded approximations, conflicting reports, inclusive simple ranges, granule-size interpretation and two-motor summation depend on the explicit diagnostic coding policy.',
       'resolution':'Keep these assumptions visible; their correctness here is relative to the specified task semantics, not a general statement of tariff law or metrology.'}
    ]
    audit={'stage':'Independent AI evidence/method audit after two source-semantic corrections',
           'decision':'PASS_WITH_EXPLICIT_SCOPE_LIMITS','human_expert_review':False,
           'completed_readonly':True,'input_hashes':q['input_hashes'],'issues':issues,
           'open_high_severity_data_errors':0,
           'constructed':{k:v for k,v in q['constructed'].items() if k!='independent_review_rows'},
           'numeric_layers':q['numeric_layers'],
           'computational_details_file':'independent_numeric_computational_audit.json',
           'unwarranted_claims':['Independent human/expert gold','Population error frequency','96 independent tests','33/33 independent accuracy','Pure arithmetic ablation','Pure preplanned external validation']}
    dump(OUT/'independent_numeric_audit.json',audit)
    text='''# 独立数值与方法审计

审计结论：**限定通过**。两项会改变证据状态的源语义问题已由数据代理修复，本次已对最终版本限定复算。最终 96 条构造标签未发现算术或三值逻辑错误；四层诊断适合作为源编码表示与自动处理之间差距的检验，不能称为法律正确性验证。

本审计由另一 AI 代理完成，未修改源数据、参照标签或主稿。没有人类、领域专家标注或真正无先验暴露的审查。审核范围包括全部构造题的事实—规则标签，48 对的配对类型，33 案 43 个数值条件，源引文跨度、四层输出、冻结程序及两个修复分支。

## 已解决的实质问题

1. **H318593_1 的尺寸范围。** 事实原文给出的三维尺寸明确排除手柄。规则中的整件尺寸未给出相同排除。原本把三轴均视为满足，隐含了不充分的测量范围假设；现三项均改为 unknown，并保留事实引文及限定说明。重量条件保持 pass。整体证据未知不变。
2. **N311039_33 的主体与解释绑定。** 第 1、3、4 种继电器的线圈/接点电压分别为 {12,277}、{48,277}、{48,277} V；这些离散备选全部超出 (60,250] V。第 2 种的 {110,277} V 仍为 unknown。此前把四种产品与两种额定角色混成连续 [12,277] 区间，丢失了确定反例。修复后先按产品计算备选状态，再对所有列出的产品作 AND，得到 fail。参照字段层新增的主体绑定适配器已明确标作 test-only；它不是旧提取器本来具备的功能。

两项修复均从可见事实和候选条件推导，没有用行政最终裁定反推标签。第三轮校正不并入初始两轮 AI 一致率。

## 构造题逐条核对

独立核算通过 **96/96** 条参照标签。核算未使用冻结解析器生成参照答案；另行按照显式主语、严格/非严格边界、单位转换、AND/OR、条件例外、离散报告及测量不确定性计算。

| 机制 | n | 标签核对结论 |
|---|---:|---|
| 标识符插入 | 8 | 型号中的数字不是测量；缺少功率仍未知 |
| 部件绑定 | 8 | 只检查 motor，灯具功率与条款次序不改变状态 |
| 自重与载重 | 8 | lifting capacity 与 jack weight 分离 |
| 比较式事实 | 8 | 边界及跨阈值区间的 pass/fail/unknown 一致 |
| 冲突报告 | 8 | 同侧备选保留状态，跨阈值备选未知 |
| 单位等价 | 8 | kg/g、lb/kg、inch/mm、kW/W 精确转换正确 |
| 复合单位 | 8 | 面密度作为质量/面积，非普通质量 |
| 双侧界限 | 8 | (4,8) kg 严格端点判定正确 |
| 三轴绑定 | 8 | 对命名长、宽、高分别比较；次序不改变绑定 |
| 析取 | 8 | 真支足以满足 OR；假支与缺失支组合为未知 |
| 嵌套例外 | 8 | 电池状态选择 7/10 kg 分支；未明状态比较两个可能分支 |
| 测量不确定性 | 8 | 显式误差范围计算正确；无容差的 approximately 按声明政策保留未知 |

等价对的两条金标签一致，decisive-change 对的标签不同，same-state-control 对的标签一致，48 对全部符合其配对类型。20 个 equivalence 对应同时报告相同预测与两条都正确；相同输出可能是稳定地错，不能替代正确性。26 个 decisive-change 对要求两条都正确，不能把任意输出变化当作正确响应。

**独立性边界：**96 行只有 **88 个完全相同事实—规则输入去重后的唯一项**。7 个重复簇包含共享控制，其中一个有 3 行，其余各 2 行。还有更多语义相近项未做语义去重；48 对嵌套于 12 个有意选择的机制，不是 96 次独立取样。冻结引擎行加权结果为 54/96（56.25%）；仅作权重敏感性核对，完全相同输入去重后为 47/88（53.41%）。主表应保留预定成对设计权重，同时说明控制复用，不应以去重结果取代原结果或使用逐行 iid 区间。

## 33 案分层诊断

最终数值参照：23 pass、7 unknown、3 fail。四层的三态一致数如下：

| 规则表示 | 事实表示 | 一致数 / 33 |
|---|---|---:|
| 源编码参照 | 源编码参照 | 33 |
| 自动规则 | 源编码参照 | 30 |
| 源编码参照 | 自动事实 | 17 |
| 自动规则 | 自动事实 | 17 |

核对了 **154 个引文/跨度**，全部与可见文本逐字一致；独立计数与各层 confusion/状态数量一致。另行重执行冻结引擎的 96 构造例与 33 真实文本数值例，均复现已保存结果。源输入、参照字段、预测与汇总哈希记录在 JSON 中。

**33/33 是内部执行一致性。** 源编码字段和状态由相同证据阅读产生，且代码对 reference/reference 设有一致性断言。该结果证明这些供给字段经过指定比较器后得到参照状态，不能作为独立预测准确率或法律正确率。29→30、18→17 等中间版本不得混入最终主表。

**层间干预并非仅替换一个数值。** 参照字段还提供了属性、主体、额定角色、测量范围、单位、保守区间等解释。继电器补丁又明确增加主体/离散解释聚合。因此可以说 supplied source-coded representations reveal the limits of automatic extraction and binding；不能说保持整个引擎完全不变、只纠正了数字识别。两个 auto-fields 层都为 17/33，也不能推论规则解析没有错误；事实错误可能遮蔽规则表示差异。

数值 pass 只针对列出的数值条件，不完成类别、用途、材质或外部援引定义。数值 fail 作为拒绝证据的效力以所编码的条件确为该分支的必要条件、主体绑定与 ALL 量词正确为前提。这里只诊断当前配对材料，不推导实际征税、实缴税额或一般法律适用准确率。

## 需进入正文或补充方法的披露

- 采用 outcome-masked source coding，而非此前从未见过裁定的 blind coding。编码脚本和供给视图未读标签或预测，不足以证明编码者没有先前项目记忆。
- 96 构造集针对已知失败机制有意设计。8 条 component-binding 规则在首次冻结引擎实验后替换为受支持的措辞；事实与标签未变，初始版本保留。必须披露这一事后设计修订，不能笼统声称最终数据全部在任何输出之前独立冻结。
- 模糊近似量、同侧冲突报告和简单范围端点的处理是明示的诊断语义。测试它们的遵从性与证明所有真实报关文本的唯一解释是不同问题。
- 参照状态和双人读法分歧的保守消解是 AI 的操作性证据政策，不是独立法律金标准。所有人类/专家审查措辞应排除。

这些边界均可通过精确写法处理，不要求再扩大样本。两项源语义错误修复后，当前没有待解决的高严重度数值数据错误；外部有效性与专家法律判定仍不能由本审计替代。
'''
    (OUT/'independent_numeric_audit.md').write_text(text,encoding='utf8')
    print('Independent numeric audit written; final reference sha256:',q['input_hashes']['numeric_reference_fields.jsonl'])

if __name__=='__main__':main()
