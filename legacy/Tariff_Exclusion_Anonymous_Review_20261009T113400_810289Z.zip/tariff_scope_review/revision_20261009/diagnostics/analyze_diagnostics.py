"""Statistics for frozen original predictions and post hoc classical diagnostics."""
from common import *
import csv,time
from collections import Counter,defaultdict
def collect():
    rows=load_rows();byid={r["case_id"]:r for r in rows};out=[]
    frozen=read(ROOT/"results/all_observed_predictions.jsonl")
    title={"Code matching":"Code_only","DeBERTa NLI":"NLI","DeBERTa NLI + numeric guard":"NLI_guard",
           "Qwen3 0.6B":"Qwen06","Qwen3 0.6B + numeric guard":"Qwen06_guard",
           "Word TFIDF LR":"Frozen_LR_word","Word and character TFIDF LR":"Frozen_LR_word_char"}
    traces={r["case_id"]:r for r in read(ROOT/"results/numeric_traces.jsonl")}
    # Recover saved pre-code-gate predictions, then verify their gated form
    # against the already frozen analysis. Never label gated values as raw.
    for r in rows:
        out.append(record(r,"Code_only",1,selective_raw=-1 if r["code_match"] is None else 1,
                          prediction_origin="original_code_gate_policy"))
    for filename,name in [("benchmark_nli.jsonl","NLI"),("benchmark_qwen.jsonl","Qwen06")]:
        for q in read(ROOT/"results"/filename):
            r=byid[q["case_id"]];b=q["binary_prediction"];s=q["selective_prediction"]
            out.append(record(r,name,b,q["prob_eligible"],s,prediction_origin="original_frozen_raw"))
            state=traces[q["case_id"]]["state"]
            if state=="fail":b=s=0
            elif state=="unknown":s=-1
            out.append(record(r,name+"_guard",b,q["prob_eligible"],s,prediction_origin="original_frozen_raw_guard"))
    for q in read(ROOT/"results/benchmark_classical.jsonl"):
        name={"word_lr":"Frozen_LR_word","word_char_lr":"Frozen_LR_word_char"}[q["model"]]
        out.append(record(byid[q["case_id"]],name,q["binary_prediction"],q["prob_eligible"],
                          prediction_origin="original_frozen_raw"))
    reconstructed={(q["case_id"],q["model"]):q for q in out}
    for q in frozen:
        for name,p in q["models"].items():
            rr=reconstructed[q["case_id"],title[name]]
            assert (rr["binary"],rr["selective"])==(p["binary"],p["selective"]),(q["case_id"],name)
    for q in read(ROOT/"results/benchmark_qwen4.jsonl"):
        r=byid[q["case_id"]];out.append(record(r,"Qwen4",q["binary_prediction"],q["prob_eligible"],q["selective_prediction"],prediction_origin="original_posthoc_frozen"))
        state=traces[q["case_id"]]["state"];b=q["binary_prediction"];s=q["selective_prediction"]
        if state=="fail":b=s=0
        elif state=="unknown":s=-1
        out.append(record(r,"Qwen4_guard",b,q["prob_eligible"],s,prediction_origin="original_posthoc_frozen_guard"))
    slog=[]
    for fold in range(5):
        train=[r for r in rows if r["fold"]!=fold];globalcounts=Counter(r["y"] for r in train)
        globalmajor=int(globalcounts[1]>globalcounts[0])
        for source in ["HQ","NY"]:
            tr=[r for r in train if r["source"]==source];ct=Counter(r["y"] for r in tr)
            pred=int(ct[1]>ct[0]) if tr else globalmajor;prob=ct[1]/len(tr) if tr else globalcounts[1]/len(train)
            slog.append({"fold":fold,"source":source,"training_n":len(tr),"negative":ct[0],"positive":ct[1],
                         "prediction":pred,"fallback_global":not bool(tr)})
            for r in rows:
                if r["fold"]==fold and r["source"]==source:
                    out.append(record(r,"Source_majority",pred,prob,prediction_origin="training_fold_source_majority"))
    dump(OUT/"source_majority_training.json",slog)
    out.extend(read(OUT/"classical_predictions.jsonl"))
    # Only complete new ABC files enter forced binary analysis. Native semantic
    # JSON/decomposition never enter this path: U/invalid cannot become denial.
    newroot=ROOT/'revision_20261009/models/outputs'
    new_sources={};pending=[]
    for model,title in [('qwen14','Qwen14'),('granite8','Granite8')]:
        suffixes=['abc_original']+(['facts_only','rules_only'] if model=='granite8' else [])
        for suffix in suffixes:
            name=title+'_'+suffix;p=newroot/f'benchmark_{model}_{suffix}.jsonl'
            if not p.exists():pending.append({'model':name,'status':'not_available'});continue
            h=sha(p);rr=read(p)
            if len(rr)!=86 or {r['case_id'] for r in rr}!=set(byid):
                pending.append({'model':name,'status':'incomplete','n':len(rr)});continue
            for q in rr:
                assert q['binary_prediction'] in [0,1] and q['selective_prediction'] in [0,1,-1]
                out.append(record(byid[q['case_id']],name,q['binary_prediction'],q['prob_eligible'],
                    q['selective_prediction'],prediction_origin='posthoc_complete_ABC_raw'))
            assert sha(p)==h
            new_sources[name]={'path':str(p),'sha256':h,'n':len(rr),
                'inference_seconds':sum(q.get('seconds',0) for q in rr),
                'input_tokens':sum(q.get('input_tokens',0) for q in rr)}
    dump(OUT/'new_binary_inputs.json',{'complete':new_sources,'pending':pending})
    # Optional older neural ablations use the common per-case format.
    extra=OUT/"neural_ablation_predictions.jsonl"
    if extra.exists():out.extend(read(extra))
    assert len({(x["case_id"],x["model"]) for x in out})==len(out)
    write_jsonl(OUT/"all_diagnostic_predictions.jsonl",out)
    return rows,out
def group_summary(rows):
    groups=defaultdict(list)
    for r in rows:groups[r["group"]].append(r)
    entries=[{"group":g,"n":len(rr),"positive":sum(r["y"] for r in rr),"negative":sum(r["y"]==0 for r in rr),
              "sources":dict(Counter(r["source"] for r in rr)),"folds":sorted(set(r["fold"] for r in rr)),
              "case_ids":[r["case_id"] for r in rr]} for g,rr in sorted(groups.items())]
    return {"n":len(rows),"positive":sum(r["y"] for r in rows),"negative":sum(r["y"]==0 for r in rows),
            "groups":len(groups),"max_group_n":max(map(len,groups.values()),default=0),
            "group_size_distribution":dict(sorted(Counter(map(len,groups.values())).items())),
            "sources":dict(Counter(r["source"] for r in rows)),"group_entries":entries}
def split_summary(rows,preds):
    out={}
    for name,mask in subset_masks(rows).items():
        rr=[r for r,m in zip(rows,mask) if m];d=group_summary(rr);d["folds"]=[]
        for fold in range(5):
            te=[r for r in rr if r["fold"]==fold];tr=[r for r in rows if r["fold"]!=fold]
            d["folds"].append({"fold":fold,"test":group_summary(te),"actual_training_all86":group_summary(tr),
                               "group_overlap":sorted({r["group"] for r in te}&{r["group"] for r in tr})})
        out[name]=d
    extra=read(OUT/"seed_split_assignments.jsonl")
    out["additional_seed_folds"]={}
    for seed in sorted({x["evaluation_seed"] for x in extra}):
        mapping={x["case_id"]:x["new_fold"] for x in extra if x["evaluation_seed"]==seed}
        out["additional_seed_folds"][str(seed)]={}
        for sub,mask in subset_masks(rows).items():
            rr=[r for r,m in zip(rows,mask) if m];z=[]
            for fold in range(5):
                te=[{**r,"fold":mapping[r["case_id"]]} for r in rr if mapping[r["case_id"]]==fold]
                z.append({"fold":fold,"test":group_summary(te)})
            out["additional_seed_folds"][str(seed)][sub]=z
    dump(OUT/"split_diagnostics.json",out)
    return out
PAIRS=[("Qwen4","Source_majority"),("Qwen4_guard","Source_majority"),("NLI","Source_majority"),
       ("Frozen_LR_word_char","Source_majority"),("NLI_guard","NLI"),("Qwen06_guard","Qwen06"),("Qwen4_guard","Qwen4"),
       ("LR_full","LR_fact_only"),("LR_full","LR_rule_only"),("LR_full","LR_source_only"),
       ("LR_full","Source_majority")]
def main():
    start=time.perf_counter();rows,preds=collect();models=defaultdict(list)
    newinputs=json.loads((OUT/'new_binary_inputs.json').read_text('utf8'))
    for p in preds:models[p["model"]].append(p)
    split=split_summary(rows,preds);out={"protocol":{"post_hoc":True,"bootstrap_B":B,"bootstrap_seed":BOOT_SEED,
         "resampling_unit":"Original connected source groups within each displayed subset",
         "conditional_inference":"Predictions held fixed; no training-uncertainty or population representativeness claim",
         "pair_difference":"A minus B using identical cluster multiplicities; corrected/new_errors refer to A vs B",
         "code_gate":"Identical known-mismatch gate on all models, including source-only; one missing-code case remains only in all_86",
         "source_majority":"Unweighted training-fold majority, tie=0; not the same estimator as balanced source-only logistic regression",
         "training_scope":"Ablations and group seeds train on all outer-training members of original 86, then report specified subsets",
         "neural_ablation_completed":all(k in newinputs['complete'] for k in ['Granite8_abc_original','Granite8_facts_only','Granite8_rules_only'])},
         "new_inputs":newinputs,"subsets":{},"cross_source":{}}
    flat=[]
    fullmodels={k:v for k,v in models.items() if not k.startswith("Cross_")}
    # Additional same-configuration neural ablation names can be added without changing primary inputs.
    pairs=list(PAIRS)
    for title in ['Qwen14','Granite8']:
        name=title+'_abc_original'
        pairs.extend([(name,'Source_majority'),(name,'Qwen4'),(name,'NLI')])
    pairs.extend([('Granite8_abc_original','Qwen14_abc_original'),
                  ('Granite8_abc_original','Granite8_facts_only'),
                  ('Granite8_abc_original','Granite8_rules_only')])
    for suffix in ["fact_only","rule_only"]:
        name="Qwen4_"+suffix
        if name in models:pairs.append(("Qwen4",name))
    for subset,mask in subset_masks(rows).items():
        selected=[r for r,m in zip(rows,mask) if m];out["subsets"][subset]={}
        for source in ["all","HQ","NY"]:
            rr=selected if source=="all" else [r for r in selected if r["source"]==source]
            plan=bootstrap_plan(rr);d={"sample":group_summary(rr),"models":{},"paired_differences":{}}
            for name,rec in fullmodels.items():
                assert {r["case_id"] for r in rr} <= {r["case_id"] for r in rec},name
                m,*_=evaluate(rr,rec,plan);d["models"][name]=m
                ci=m["cluster_bootstrap_95ci"]["balanced_accuracy"]
                flat.append({"subset":subset,"source":source,"model":name,
                    **{k:m[k] for k in ["n","groups","positive","negative","tp","fn","fp","tn","balanced_accuracy","false_exemption_rate","eligible_recall","coverage","answered_error_rate"]},
                    "balanced_accuracy_lower":ci["lower"],"balanced_accuracy_upper":ci["upper"]})
            for a,b in pairs:
                if a in fullmodels and b in fullmodels:
                    d["paired_differences"][a+" MINUS "+b]={"A":a,"B":b,**paired(rr,models[a],models[b],plan)}
            out["subsets"][subset][source]=d
    logs=json.loads((OUT/"classical_training_log.json").read_text(encoding="utf-8"))
    for name,recs in models.items():
        if not name.startswith("Cross_"):continue
        ids={p["case_id"] for p in recs};rr=[r for r in rows if r["case_id"] in ids]
        d={"training":[l for l in logs if l["model"]==name][0],"subsets":{}}
        for sub,mask in subset_masks(rows).items():
            target=[r for r,m in zip(rows,mask) if m and r["case_id"] in ids]
            if not target:continue
            plan=bootstrap_plan(target);m,*_=evaluate(target,recs,plan)
            d["subsets"][sub]=m
            ref="Frozen_LR_word" if name.endswith("_word") else "Frozen_LR_word_char"
            d["subsets"][sub]["cross_minus_grouped_oof_same_test"]=paired(target,recs,models[ref],plan)
        out["cross_source"][name]=d
    out["execution_seconds"]=time.perf_counter()-start
    out["source_hashes"]={str(p.relative_to(ROOT)):sha(p) for p in [
        ROOT/"datasets/benchmark.jsonl",ROOT/"results/all_observed_predictions.jsonl",ROOT/"results/benchmark_qwen4.jsonl",
        ROOT/"results/numeric_traces.jsonl",OUT/"classical_predictions.jsonl",OUT/"protocol.md"]}
    for v in newinputs['complete'].values():
        assert sha(Path(v['path']))==v['sha256'],'New prediction file changed during analysis'
        out['source_hashes'][str(Path(v['path']).relative_to(ROOT))]=v['sha256']
    dump(OUT/"diagnostic_analysis.json",out)
    with (OUT/"metrics.csv").open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
    pf=[]
    for sub,ss in out["subsets"].items():
        for source,d in ss.items():
            for name,r in d["paired_differences"].items():
                for metric,v in r["metrics"].items():
                    pf.append({"subset":sub,"source":source,"comparison":name,"n":r["n"],"groups":r["groups"],
                               "metric":metric,**v,"corrected":r["corrected"],"new_errors":r["new_errors"]})
    with (OUT/"paired_differences.csv").open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(pf[0]));w.writeheader();w.writerows(pf)
    m=out["subsets"]["compatible_code_73"]["all"]
    print(json.dumps({"complete":True,"seconds":out["execution_seconds"],
        "source_only":m["models"]["Source_majority"],
        "qwen4_minus_source":m["paired_differences"]["Qwen4 MINUS Source_majority"]["metrics"]["balanced_accuracy"],
        "ablation_BA":{k:v["balanced_accuracy"] for k,v in m["models"].items() if k in ["LR_full","LR_fact_only","LR_rule_only","LR_source_only"]}},indent=2))
if __name__=="__main__":main()
