# Final integrated content audit

Read-only content audit, 9 October 2026. The reviewed integrated manuscript was `manuscript/tariff_exclusion_revised.md` (SHA-256 `0776f1d28a5fe06e1134ad5932690756055ce8538f5dc121704e07fa5a35b402`). This audit read the complete article, the original review attachment and revision ledger, the completed manuscript result blocks, the saved decomposition integrity report, and the relevant earlier coverage, source/numeric, citation-claim and decomposition-method audits. It did not rerun inference, statistical tests, numerical benchmarks or literature verification. The statistics agent owns the separate numerical reconciliation; archive and DOCX preparation are outside this content-only decision.

## Two required corrections

### 1. Narrow the historical preservation claim in Section 5.5

**Location:** paragraph beginning “The separately developed revision parser matches 24 of 33…” (reviewed line 336).

**Current:** “The initial revision run matched 23 cases before an additional approximation-handling repair. Both runs are preserved.”

The first revision retains its aggregate analysis, not its complete source snapshot and case-level outputs. The Methods already reports this accurately. The result paragraph must not imply that both executions are fully reproducible from their original preserved artifacts.

**Replace the second sentence with:**

> The initial run's aggregate summary and the final source code and case-level outputs are retained.

This is a provenance correction; no historical files should be reconstructed and no new experiment is needed.

### 2. Distinguish decomposition validation failure from invalid JSON

**Locations:** Abstract (reviewed line 5) and Table D3 note (reviewed line 586).

The abstract says the workflow “fails parsing in 61 primary cases”; the table note says “JSON invalid counts use strict parsing of the complete generated object.” In combination these descriptions can suggest that all rejected decompositions were malformed JSON. The completed integrity report records only six `invalid_json` rule outputs among 43 rejected cached rules. Other failures concern logical-node structure, coverage or definition of leaves, object keys, or exact rule quotations. These reasons can overlap. Their case-level effects are inherited through the documented cache; they are not 61 independent failed rule generations.

**Replace the abstract sentence with:**

> A fixed condition-decomposition workflow leaves 61 primary cases invalid after rule validation, exposing an interface failure distinct from valid-format overcommitment.

**Replace the Table D3 sentence with:**

> Direct JSON invalid counts use strict decision-object parsing; decomposition invalid counts additionally include rule-schema, tree and literal-quotation validation failures.

The detailed Methods and Results already distinguish invalid rule/evidence parses from factual quotation protection. Preserve that distinction and all existing scores. The generator of the table note should receive the same textual correction so a later assembly does not restore the obsolete wording.

## No additional material content issue found

The manuscript's main increment over Holzenberger and Van Durme (2023) is now assessable: it separates administrative agreement, retained-input evidence support and numerical representation/execution on linked ruling pairs. It does not claim that extracting legal conditions before symbolic aggregation is itself new. The primary claims no longer depend on a checkpoint winning a pooled ranking.

The administrative and AI evidence targets remain distinct in the definitions, tables, source examples and direct cross-tabulation. The 47 unresolved cases represent the restricted-input policy, not demonstrated agency errors. Model-specific NLI truncation and input-removal controls are not silently equated with the complete retained-text reference. Parse failures are not rewarded as correct unknown answers, while a quotation-protected valid tree keeps its actual aggregated state.

AI-only coding is disclosed with same-lineage passes, prior project exposure, preserved initial disagreement, conservative reconciliation and source-based later corrections. The second pass is accurately case-level, rather than a second complete condition annotation. Neither agreement nor literal quotation checks are promoted into independent expert or legal validation. The revised parser is described as development on inspected diagnostics; source-coded fields remain test-only representations and reference/reference agreement remains an internal consistency check.

The original review's substantive requests are either implemented or transparently narrowed. The record does not invent the missing retrieval-to-curation reading log, an expert annotation exercise, a new held-out test, actual review productivity, a public repository DOI or complete autonomous eligibility. Larger and different-family models, alternate interfaces, the fixed decomposition workflow, source/input diagnostics, paired contrasts, numeric layer controls, uncertainty causes and referral costs are integrated. No additional expert requirement or experiment is raised by this audit. The anonymous archive still has to be supplied with the delivery, as the root task is already preparing; its existence is not certified here.

## Stage-specific readiness

**Integrated content stage: CONDITIONAL solely on the two bounded wording corrections above.** Once those sentences are synchronized with their source fragments/generator, the article is content-ready to proceed as the explicitly scoped diagnostic resource. This does not guarantee journal acceptance or independently certify the archive, document rendering, human author approval, expert validity or generalization of the development repair. No broader rewrite, repeated old audit or enlarged experiment is required by these findings.
