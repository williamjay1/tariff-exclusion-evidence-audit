"""Independent scalar verification of fixed constructed-family statistics."""
from common import *
from collections import defaultdict
from sklearn.metrics import f1_score

def recorded_path(value):
    """Resolve redacted package-relative provenance without changing its digest."""
    p=Path(value.replace('\\','/'))
    return p if p.is_absolute() else ROOT/p

a=json.loads((OUT/'mechanism_model_analysis.json').read_text('utf8'))
rows=read(ROOT/'revision_20261009/evidence_numeric/constructed_diagnostics.jsonl')
preds=read(OUT/'mechanism_model_predictions.jsonl');pm=defaultdict(dict)
for q in preds:pm[q['model']][q['case_id']]=q
truth={'pass':'eligible','fail':'ineligible','unknown':'unknown'};pointchecks=[]
for name,m in a['models'].items():
    y=[truth[r['gold']] for r in rows];p=[pm[name][r['case_id']]['prediction'] for r in rows]
    assert sum(aa==bb for aa,bb in zip(y,p))==m['correct']
    assert np.isclose(f1_score(y,p,labels=['eligible','ineligible','unknown'],average='macro',zero_division=0),m['metrics']['macro_f1']['value'])
    families=defaultdict(list);pairs=defaultdict(list);unique=defaultdict(list)
    for r,t,z in zip(rows,y,p):
        families[r['group']].append(t==z);pairs[r['pair_id']].append((r,t,z))
        unique[r['facts'],r['rule_text']].append(t==z)
    assert len(unique)==88
    assert np.isclose(np.mean([sum(v)/len(v) for v in unique.values()]),m['exact_unique_weight_sensitivity']['mean_accuracy'])
    for family,v in families.items():assert sum(v)==m['by_family'][family]['correct']
    for kind,z in m['pairs'].items():
        v=[v for v in pairs.values() if v[0][0]['pair_type']==kind]
        assert len(v)==z['n'] and sum(all(t==p for r,t,p in ps) for ps in v)==z['both_correct']
        assert sum(ps[0][2]==ps[1][2] for ps in v)==z['same_prediction']
    pointchecks.append(name)
families=sorted({r['group'] for r in rows});rng=np.random.default_rng(BOOT_SEED);values={name:[] for name in pm}
for _ in range(B):
    choices=rng.choice(families,len(families),replace=True)
    sample=[r for family in choices for r in rows if r['group']==family]
    for name in pm:
        values[name].append(sum(pm[name][r['case_id']]['prediction']==truth[r['gold']] for r in sample)/len(sample))
for name,v in values.items():
    q=a['models'][name]['metrics']['evidence_accuracy'];assert np.allclose(np.quantile(v,[.025,.975]),[q['lower'],q['upper']])
for pair,q in a['paired_differences'].items():
    aa,bb=pair.split(' MINUS ');v=np.array(values[aa])-np.array(values[bb]);z=q['evidence_accuracy']
    assert np.allclose(np.quantile(v,[.025,.975]),[z['lower'],z['upper']])
assert all(sha(recorded_path(v['path']))==v['sha256'] for v in a['inputs'].values())
report={'passed':True,'model_point_pair_unique_checks':pointchecks,'literal_family_resampling_B':B,
        'literal_paired_accuracy_checks':list(a['paired_differences']),
        'claim_boundary':'Conditional resampling of the 12 chosen mechanism families, not IID legal-case or population inference.'}
dump(OUT/'mechanism_metrics_verification.json',report);print(json.dumps(report))
