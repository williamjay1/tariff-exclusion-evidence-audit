"""Read-only audit of fully written new-model files, prompts, scoring and costs.

Does not score incomplete formal outputs or infer from a generated first token
when the protocol is explicitly conditional three-letter logit scoring.
"""
from common import *
from collections import Counter
import math,sys,importlib.util
M=ROOT/'revision_20261009/models';O=M/'outputs'
sys.path.insert(0,str(M))
from protocols import PREFLIGHT,json_prompt,scope,aggregate,evidence_prompt
from decomposition_protocol import RULE_PARSE_PROMPT
from run_gguf_models import old_prompt

def strict_json(raw):
    try:
        x=json.loads(raw)
        if type(x) is dict and set(x)=={'decision'} and x['decision'] in ['eligible','ineligible','unknown']:
            return x['decision']
    except (ValueError,TypeError):pass
    return None

def audit_direct(row,expected_prompt,kind):
    assert row['user_prompt']==expected_prompt and expected_prompt in row['prompt']
    assert not row.get('truncated',False)
    cap=48 if kind=='semantic_json' else 1
    assert row['input_tokens']+cap<=4096
    assert math.isfinite(row['seconds']) and row['seconds']>=0
    if kind=='semantic_json':
        parsed=strict_json(row['raw_output']);assert parsed==row['parsed']
        assert (parsed is None)==row['invalid_output']
        if 'selective_prediction' in row:assert row['selective_prediction']=={'eligible':1,'ineligible':0,'unknown':-1}.get(parsed)
    else:
        probs=[row[k] for k in ['prob_eligible','prob_ineligible','prob_unknown']]
        logits=[row['letter_logprobs'][c] for c in 'ABC']
        assert all(math.isfinite(x) for x in logits+probs)
        assert all(0<=x<=1 for x in probs) and np.isclose(sum(probs),1,atol=1e-10)
        exp=np.exp(np.array(logits)-max(logits));check=exp/sum(exp)
        assert np.allclose(probs,check,atol=1e-10)
        assert row['binary_prediction']==int(logits[0]>=logits[1])
        assert row['selective_prediction']==[1,0,-1][int(np.argmax(logits))]
        assert np.isclose(row['bare_letter_mass'],sum(math.exp(x) for x in logits),atol=1e-10)
    return True

def main():
    bench={r['case_id']:r for r in load_rows()}
    mech={r['case_id']:r for r in read(ROOT/'revision_20261009/evidence_numeric/constructed_diagnostics.jsonl')}
    pre={r['case_id']:r for r in PREFLIGHT}
    result={'protocol':'Only complete, ID-exact fixed files are audited. Partial formal files are listed pending without scores.',
        'formal':{},'preflight':{},'pending':[],'issues':[]}
    for model in ['qwen14','granite8']:
        pp=O/f'{model}_preflight.jsonl'
        if pp.exists():
            z=read(pp)
            if len(z)==18 and len({r['key'] for r in z})==18:
                expectedkeys={c+'_'+p for c in pre for p in ['abc_original','semantic_json']}
                assert {r['key'] for r in z}==expectedkeys
                for r in z:
                    exp=json_prompt(pre[r['case_id']]) if r['protocol']=='semantic_json' else old_prompt(pre[r['case_id']])
                    audit_direct(r,exp,r['protocol'])
                    assert r['expected']==pre[r['case_id']]['y']
                    if r['protocol']=='abc_original':assert r['parsed']=={1:'eligible',0:'ineligible',-1:'unknown'}[r['selective_prediction']]
                result['preflight'][model]={'n':18,'sha256':sha(pp),'protocols':{}}
                for p in ['abc_original','semantic_json']:
                    rs=[r for r in z if r['protocol']==p]
                    result['preflight'][model]['protocols'][p]={'n':9,'correct':sum(r['expected']==r['parsed'] for r in rs),
                        'invalid':sum(r['parsed'] is None for r in rs),'stopped_limit':sum(r['stopped_limit'] for r in rs),
                        'inference_seconds':sum(r['seconds'] for r in rs)}
        tasks=[('benchmark','abc_original'),('benchmark','semantic_json'),('mechanism','semantic_json')]
        if model=='granite8':tasks += [('benchmark','facts_only'),('benchmark','rules_only'),('benchmark','decomposition')]
        for dataset,kind in tasks:
            filename=f'{dataset}_{model}_{kind}.jsonl';p=O/filename;source=bench if dataset=='benchmark' else mech
            if not p.exists():result['pending'].append(filename);continue
            z=read(p)
            if len(z)!=len(source) or {r['case_id'] for r in z}!=set(source):result['pending'].append(filename);continue
            h=sha(p);rule_seconds=0;rule_count=0
            if kind=='decomposition':
                rulefile=O/f'{model}_decomposition_rules.jsonl';rule_rows=read(rulefile)
                needed={r['rule_sha256'] for r in z};rules={r['rule_sha256']:r for r in rule_rows if r['rule_sha256'] in needed}
                assert len(rules)==len(needed)
                rule_seconds=sum(r['seconds'] for r in rules.values());rule_count=len(rules)
                for rr in rules.values():
                    assert rr['user_prompt']==RULE_PARSE_PROMPT+rr['rule_text']
                    assert not rr.get('truncated',False) and rr['input_tokens']+768<=4096
                    assert rr['seconds']>=0 and math.isfinite(rr['seconds'])
                for r in z:
                    rr=rules[r['rule_sha256']];expected=scope(source[r['case_id']]['rule_text'])
                    assert rr['rule_text']==expected
                    assert hashlib.sha256(expected.encode()).hexdigest()==r['rule_sha256']
                    if rr['valid']:
                        assert r['user_prompt']==evidence_prompt(source[r['case_id']]['facts'],rr['parsed']['conditions'])
                        assert not r.get('truncated',False) and r['input_tokens']+768<=4096
                        assert r['seconds']>=0 and math.isfinite(r['seconds'])
                    if r['pipeline_status'] in ['invalid_rule_parse','invalid_evidence_parse']:
                        continue
                    assert r['pipeline_status'] in ['valid','invalid_quote_forced_missing']
                    states={}
                    for c in r['conditions']:
                        q=c['fact_quote'];valid=bool(isinstance(q,str) and (q in source[r['case_id']]['facts'] if q else c['state']=='missing'))
                        assert valid==c['quote_valid']
                        state={'established':1,'contradicted':-1,'missing':0}[c['state']] if valid else 0
                        assert c['effective_state']==state;states[c['id']]=state
                    val=aggregate(r['logic']['logic'],states)
                    assert r['deterministic_aggregate']==val and r['parsed']=={1:'eligible',-1:'ineligible',0:'unknown'}[val]
            else:
                for r in z:
                    x=source[r['case_id']]
                    if kind=='semantic_json':expected=json_prompt(x)
                    else:expected=old_prompt({'facts':x['facts'] if kind!='rules_only' else '', 'rule_text':x['rule_text'] if kind!='facts_only' else ''})
                    audit_direct(r,expected,'semantic_json' if kind=='semantic_json' else 'abc_original')
            assert h==sha(p)
            result['formal'][filename]={'n':len(z),'sha256':h,'direct_or_evidence_inference_seconds':sum(r.get('seconds',0) for r in z),
                 'rule_parse_seconds':rule_seconds,'unique_rule_parses':rule_count,
                 'total_recorded_seconds':sum(r.get('seconds',0) for r in z)+rule_seconds,
                 'stopped_limit':sum(bool(r.get('stopped_limit')) for r in z),
                 'large_logprob_recovery_calls':sum(r.get('n_returned_logprobs',0)>2000 for r in z),
                 'truncated':sum(bool(r.get('truncated')) for r in z),
                 'pipeline_status_counts':dict(Counter(r.get('pipeline_status','direct') for r in z)),
                 'checks':'Prompt identity, score reconstruction or strict raw JSON, unique IDs, context and runtime checked.'}
    result['all_expected_complete']=not result['pending']
    result['cost_boundary']='Recorded inference-call seconds exclude download/startup and any discarded logit-recovery fallback call; cached rule calls charged once. ABC one-token limit stops are intentional.'
    dump(OUT/'completed_raw_output_audit.json',result)
    print(json.dumps({'completed_files':list(result['formal']),'preflight':result['preflight'],'pending':result['pending']}))
if __name__=='__main__':main()
