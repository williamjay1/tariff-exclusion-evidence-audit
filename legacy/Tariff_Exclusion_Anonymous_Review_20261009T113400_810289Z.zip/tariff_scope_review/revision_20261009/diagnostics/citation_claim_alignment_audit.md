# Citation–claim alignment audit

Audit date: 9 October 2026. Scope: the current introduction/related work, methods, results, discussion/conclusion and normalized references, checked against `literature/final_reference_metadata.json` and targeted primary-source reads. This is a read-only content audit; no manuscript, frozen data, model output or reference metadata was changed. It does not repeat the numerical audits or certify model runs that were still pending.

## Decision

The cited claims are generally appropriately narrow. The manuscript does not import another dataset's expert validity, treat an author-hosted working paper as peer reviewed, or infer universal language-model limits from small local evaluations. One close methodological predecessor should be explicitly acknowledged to make the RQ3 contribution defensible. One reference has a verified final publication version that should replace its arXiv-only entry. The previously missing direct inventory citation is now present.

## Actionable findings

### 1. Important proximity correction: extraction–execution decomposition already has a direct statutory-reasoning predecessor

**Location:** `manuscript/introduction_related.md`, Section 2.3, paragraph starting “Behavioral tests can isolate capabilities” (line 39 in the audited snapshot); also relevant to the RQ3 framing and Discussion 6.3.

The existing SARA 2020 reference establishes tax-law entailment/question answering, but it does not acknowledge the much closer follow-up: Holzenberger and Van Durme (2023), *Connecting Symbolic Statutory Reasoning with Legal Information Extraction*. Its abstract and opening PDF discussion expressly connect legal case information extraction with symbolic statutory reasoning and study downstream dependence on extraction quality. This is close to the manuscript's rule/field controls. The current article need not abandon RQ3, but its contribution should not be understood as discovering that symbolic execution depends on extracted facts. [Official ACL record](https://aclanthology.org/2023.nllp-1.12/) and [official paper, p. 113](https://aclanthology.org/2023.nllp-1.12.pdf).

**Recommended insertion after the first sentence of the Section 2.3 paragraph:**

> Holzenberger and Van Durme (2023) connect legal information extraction to symbolic statutory reasoning and show that downstream performance depends on extraction quality. We extend this diagnostic concern to public tariff-exclusion records, distinguishing administrative agreement from restricted-input evidence support and testing governed-product, rating and measurement-scope ambiguities.

This is a narrowly justified addition, not a request to inflate the bibliography. Do not add the 2021 SARA follow-up as well merely to increase coverage. The replacement should retain the existing statement that supplied reference fields are test-only controls. No claim of a new general-purpose neuro-symbolic architecture is warranted or currently needed.

**Verified reference details:** Holzenberger N, Van Durme B (2023). Proceedings of the Natural Legal Language Processing Workshop 2023, pp. 113–131. DOI: [10.18653/v1/2023.nllp-1.12](https://doi.org/10.18653/v1/2023.nllp-1.12). The ACL record and the official PDF opening were read; this audit does not claim to have reproduced that paper's experiments.

### 2. CUAD has a verified final publication; replace the preprint-only bibliographic version

**Location:** `manuscript/references_normalized.md`, Hendrycks et al. entry, line 23; metadata ID `hendrycks2021cuad`.

The current authors, year and title are correct, and the associated Section 2.2 claim is supported. However, the official final venue is the *Proceedings of the Neural Information Processing Systems Track on Datasets and Benchmarks 1 (NeurIPS Datasets and Benchmarks 2021)*, round 1. The [official proceedings record](https://datasets-benchmarks-proceedings.neurips.cc/paper_files/paper/2021/hash/6ea9ab1baa0efb9e19094440c317e21b-Abstract-round1.html) verifies the four authors and the expert-annotation character of the resource.

**Exact bibliographic replacement:**

> Hendrycks D, Burns C, Chen A, Ball S (2021) CUAD: An Expert-Annotated NLP Dataset for Legal Contract Review. Proceedings of the Neural Information Processing Systems Track on Datasets and Benchmarks 1. https://datasets-benchmarks-proceedings.neurips.cc/paper_files/paper/2021/hash/6ea9ab1baa0efb9e19094440c317e21b-Abstract-round1.html.

Synchronize the metadata container/type and use the official record URL. No final-publication DOI was verified here; do not invent one or relabel the arXiv DOI as the proceedings DOI. The existing arXiv link can remain an alternative version locator.

### 3. Minor legal-source precision: identify USTR guidance as request guidance

**Location:** `manuscript/introduction_related.md`, first paragraph: “The associated application guidance emphasizes physically verifiable product attributes.”

The underlying source is guidance for filing product-specific exclusion requests. The present sentence does not overtly claim that the guidance defines granted coverage, but “application guidance” is avoidably ambiguous between applying a granted exclusion and filing a request. Replace it with:

> USTR's exclusion-request guidance emphasizes physically verifiable product attributes (USTR n.d.).

The prior sentence should continue to anchor the scope of granted exclusions to the published notice/description, not to filing guidance. This is supported by the scope distinction already recorded in the source metadata; the present audit did not reparse the entire guidance PDF.

## Resolved or intentionally retained items

| Item | Finding and disposition |
|---|---|
| USTR 2024 inventory source | **Resolved in the current manuscript.** `task_methods.md` line 19 explicitly cites `(USTR 2024)` after the index title and update date. The text correctly distinguishes an extension index from a claim of current legal effect and uses historical case wording separately. |
| Movva author-hosted paper absent from the reference list | **Not an error.** The journal's [References instructions](https://link.springer.com/journal/10506/submission-guidelines) reserve the reference list for published/accepted work and direct unpublished work to the text. The manuscript labels the work undated and author hosted, supplies its title, author, URL and access date, and does not claim peer review. `literature/movva_version_manifest.json` identifies the retrieved PDF. This is an explicit adaptation to the guide, not a missing published reference. |
| Movva version verification | The manifest records an undated, unversioned author-hosted document, without a verified venue or DOI. This audit inspected that provenance record and the manuscript's cautious characterization; it did not reread the entire raw PDF. Do not upgrade its publication status. |
| SARA 2020 | The arXiv identity and broad entailment/question-answering characterization are consistent. No final venue for this exact title was verified in this audit. Do not substitute the different 2021 paper under the 2020 title. |
| Qwen year suffixes | The rendered 2025a/2025b/2025c suffixes distinguish same-author entries; the plain numerical year in the Qwen 14B metadata is not a substantive publication-date contradiction. Model-card citations document checkpoint identity, not independently validated legal capability. |
| Results and Discussion | The reviewed passages interpret this study's saved outputs and explicitly limit prospective value, source prevalence, costs and deployment claims. They do not require an external citation on every local finding. General statutory extraction precedent should be acknowledged as in finding 1, rather than attaching unrelated references to these paragraphs. |

## Targeted claim checks

| Manuscript claim | Source support and limit | Verification depth in this pass |
|---|---|---|
| VITA provides expert references for 130 original questions and tests meaning-preserving perturbations (Section 2.2). | Supported. The article describes expert answer construction/adjudication and original/perturbed questions. The manuscript correctly avoids transferring that expert validity to the present AI-assisted codes. | Publisher full-text HTML: abstract; perturbation procedure; Section 2.5 on ground truth. [Gogani-Khiabani et al.](https://link.springer.com/article/10.1007/s10506-025-09465-7). |
| Automated case-law annotation has task-dependent strengths, with basic characteristics differing from complex reference extraction (Section 2.2). | Supported. The paper compares GPT-4o and students, while an expert team constructs/adjudicates its reference. The manuscript's traceability claim does not imply that AI-only agreement inherits that standard. | Publisher full-text HTML: abstract and Section 4.1, including reference construction. [Schepers et al.](https://link.springer.com/article/10.1007/s10506-025-09495-1). |
| Shallow, adapted neural and generative legal classifiers can be compared with resource costs (Section 2.3). | Supported. The comparison concerns different configurations and adaptation regimes. It supports reporting simple baselines and costs; it does not identify a general effect of parameter scale, and the manuscript does not claim one. | Publisher full-text HTML: abstract and introduction/method overview. [O'Connell et al.](https://link.springer.com/article/10.1007/s10506-025-09484-4). |
| CUAD illustrates expert-defined legal extraction references (Section 2.2). | Supported by the final proceedings abstract. It does not validate the present source-coded evidence policy. | Official proceedings metadata and abstract; bibliographic version correction above. |
| Customs classification, robustness, public CBP data and rule/graph workflows precede this study (Sections 1 and 2.1). | Consistent with the archived metadata/abstract checks for Lee, Gholamian, ATLAS, HSCodeComp, HSGraphAgent and Zhang. Current prose makes broad task-level statements, not borrowed numerical rankings. Zhang is explicitly called a preprint. | Cross-checked current claims against `final_reference_metadata.json`; this pass did not reread every full paper. Lee's publisher full text and the large HSCodeComp PDF were not available in the original checks. |
| ContractNLI distinguishes three information states and evidence spans; legal retrospective inputs differ from prospective evidence (Section 2.2). | Consistent with the recorded official ACL abstract/metadata support for ContractNLI, Medvedeva/McBride, Vaudaux and Liu. The statements are used as task-design precedents, not proof that removing holdings solves leakage. | Current prose-to-provenance review; not a fresh full-text verification of all four papers. |
| A citation or fluent explanation is not equivalent to validated support (Section 2.2). | Consistent with ALCE's separate citation-quality objectives and the legal-hallucination literature. No historical model-specific failure rate is presented as a universal current rate. | Current prose-to-recorded primary-source support review for Gao and Dahl; not a new full-text reproduction. |
| Reject-option literature motivates coverage/error reporting; classifier scores need not be calibrated (Section 2.3). | Consistent with Chow, El-Yaniv/Wiener, SelectiveNet and Guo. The manuscript does not claim theoretical guarantees for the present noisy legal labels or call its rule gate SelectiveNet. | Existing official metadata/abstract/excerpt checks; current passage checked for unsupported transfer. |

## Verification provenance and stopping boundary

The locally saved `vita.txt`, `annotation.txt`, `cost.txt` and journal-guidelines text contain client-challenge responses, not article content. `literature/source_manifest.json` already labels those responses accordingly. They were not used as evidence of full-text access. The three article checks above used readable publisher HTML returned by the web tool, and the journal reference-list rule was independently located in the publisher's submission guidelines. The CUAD and 2023 statutory-reasoning checks used the official conference repositories.

No blanket “all references full-text verified” statement is justified. Other entries retain the verification depth explicitly recorded in the metadata. The present claims are modest enough to be supported at that depth; a later addition of numerical comparisons, procedural details or stronger novelty claims would require targeted original-text checks. No extra citations are requested solely to reach a reference-count target.

The audit is complete at this scope. Required handoff: acknowledge the 2023 statutory extraction predecessor, use the verified CUAD final venue, and consider the small request-guidance wording correction. No manuscript files were edited by this auditor.
