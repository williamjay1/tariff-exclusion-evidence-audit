"""Render the completed, post hoc diagnostics without modifying the manuscript."""
from common import *

def main():
    a=json.loads((OUT/'diagnostic_analysis.json').read_text())
    splits=json.loads((OUT/'split_diagnostics.json').read_text())
    execution=json.loads((OUT/'training_execution.json').read_text())
    verification=json.loads((OUT/'verification.json').read_text())
    primary=a['subsets']['compatible_code_73'];exact=a['subsets']['exact_ten_digit_60']
    def pct(v):return 'NA' if v is None else f'{100*v:.2f}'
    def ci(v):return f"[{pct(v['lower'])}, {pct(v['upper'])}]"
    def ba(q):return pct(q['balanced_accuracy'])+' '+ci(q['cluster_bootstrap_95ci']['balanced_accuracy'])
    L=['# Source, split and input diagnostics — completed 2026-10-09',
       '', '## 执行范围与审稿解释', '',
       '本目录已实际完成原始 86 对样本、73 对 compatible-code 主集、60 对 exact-ten-digit 敏感性集的来源、输入和划分诊断。所有分析均为事后补充；未改动冻结样本、标签、分组、原始预测或主稿。不能把本轮补充写成预注册设计。', '',
       '最有价值的新证据是：合并来源评价可以奖励来源与标签的关系；来源内部检验、输入消融及跨来源迁移揭示这种表现不能直接视为产品—规则推理。73 主集的来源基线高于 4B 的点估计，但 paired 区间跨零，尚不能断言前者显著更优。60 敏感性集上排序反转且差值区间同样跨零，应并列报告，不能择优选择子集。', '',
       '所有 binary 比较具有相同的已知税号不匹配拒绝门。该门在 73 和 60 内不改变预测；在 86/85 汇总中，source-only 是来源分类器加共同代码门，不能称完全不含税号信息。训练始终使用原 86 的外层训练成员，之后在预先指定的子集计算指标；未按子集另行重训以改变难度。', '',
       '区间采用 2,000 次原 linked source-group 整组重抽样，固定 seed=20261007；各模型及 paired 差值共享同一重抽样序列。点估计按样本计算 balanced accuracy，保留原始簇大小，不是各组等权准确率。结果条件于冻结预测和所保留材料，未包含重训练不确定性，也不证明该精选样本代表 CBP 全部裁定或实际进口。', '',
       '## 1. 来源分层结果', '',
       '下表混淆顺序为 TN / FP / FN / TP；括号为 group bootstrap 95% CI，均为百分数。HQ 主集 27 对（11 eligible、16 ineligible；21 组），NY 主集 46 对（36 eligible、10 ineligible；20 组）。', '',
       '| 模型 | 合并 73：BA [CI] | HQ：混淆；BA [CI] | NY：混淆；BA [CI] |',
       '|---|---|---|---|']
    for name in ['Source_majority','Qwen4','Qwen4_guard','NLI','NLI_guard','Qwen06','Qwen06_guard','Frozen_LR_word','Frozen_LR_word_char']:
        p=primary['all']['models'][name];h=primary['HQ']['models'][name];n=primary['NY']['models'][name]
        conf=lambda x:'/'.join(str(x[k]) for k in ['tn','fp','fn','tp'])
        L.append(f'| {name} | {ba(p)} | {conf(h)}; {ba(h)} | {conf(n)}; {ba(n)} |')
    L+=['', '来源多数规则在每个原外折中仅用训练集估计 HQ/NY 多数标签，平局预测 0；逐折计数见 source_majority_training.json。所有外折学得 HQ→ineligible、NY→eligible，因此 73 集内每个来源的 BA 都恰为 50%，合并后为 69.07%。此退化 50% 区间是固定常数预测与 BA 定义的结果，不能解释为对真实泛化性能没有不确定性。', '',
        'Qwen4 的 HQ/NY 来源内部 BA 点估计分别为 67.61% 和 61.94%，均高于来源常数预测，但样本很小，paired 区间分别为 [−1.92,+36.63] 和 [−15.15,+27.78] 个百分点，不能据此宣称稳定消除了来源偏差。合并值与分层值的相对变化来自标签比例和错误分布；这些数据并不识别源办公室本身的因果效应。', '',
        '## 2. Paired 差值与 guard 的代价', '',
        '下表 ΔBA 为 A−B，单位百分点，所有区间使用同组、同次重抽样；未实施多重比较校正，各项为透明的诊断比较。', '',
        '| A−B | 73 主集 ΔBA [CI] | 60 敏感性 ΔBA [CI] |', '|---|---|---|']
    for name in ['Qwen4 MINUS Source_majority','NLI MINUS Source_majority','Frozen_LR_word_char MINUS Source_majority',
                 'NLI_guard MINUS NLI','Qwen06_guard MINUS Qwen06','Qwen4_guard MINUS Qwen4',
                 'LR_full MINUS LR_fact_only','LR_full MINUS LR_rule_only','LR_full MINUS LR_source_only']:
        p=primary['all']['paired_differences'][name]['metrics']['balanced_accuracy']
        e=exact['all']['paired_differences'][name]['metrics']['balanced_accuracy']
        L.append(f"| {name} | {pct(p['delta'])} {ci(p)} | {pct(e['delta'])} {ci(e)} |")
    L+=['', 'Qwen4−source 在 73 内为 −5.32pp，在 60 内为 +11.11pp；两项 paired 区间均跨零。60 集保留全部 NY 的 46 对而把 HQ 从 27 缩至 14，对来源混合构成的改变必须呈现；这不等同于 60 集发现了更有效的模型。', '',
        '数值 guard 没有改变 NLI 或 Qwen4 的 binary 判定，因而 ΔBA 恰为 0，区间也为 [0,0]；这仅说明本批固定预测没有变化。Qwen0.6 guard 多制造 1 个 binary 错误，未纠正错误，对应主集 ΔBA −1.06pp。', '',
        'Qwen4 的 guard 把回答覆盖率由 91.78% 降至 64.38%，paired Δcoverage −27.40pp [−39.13,−14.00]；已回答错误率由 34.33% 降至 31.91%，paired Δrisk −2.41pp [−9.00,+4.64]。明显减少回答不等于已证实降低错误风险，更不能证明规则证据不足的判断正确。NLI guard 的已回答错误率反而从 48.39% 到 52.38%；完整选择性指标及差值区间均保留于 JSON/CSV。', '',
        '## 3. 公平固定折输入消融', '',
        '四种输入使用完全相同的 word+character TF-IDF、class-balanced Logistic Regression、C∈{0.1,1,10}、外五折和训练内三折选择，预处理只在训练折拟合，阈值固定为 0.5。事实和规则从同一冻结数据抽取，规则中的代码定位括号按原模型规则移除。source-only LR 使用 HQ/NY 两个来源标记；它与非加权 source-majority 是不同估计器，但本次逐案结果一致。', '',
        '| 输入 | 73 BA [CI] | 60 BA [CI] |', '|---|---|---|']
    for name in ['LR_full','LR_fact_only','LR_rule_only','LR_source_only']:
        L.append(f"| {name} | {ba(primary['all']['models'][name])} | {ba(exact['all']['models'][name])} |")
    L+=['', 'full 相对 fact-only 与 rule-only 的主集增量均为 +2.99pp，但两项 paired 区间都跨零；不能把它们写成经过验证的事实—规则交互收益。两种消融碰巧有相同总混淆矩阵，不代表逐案预测相同。full 相对 fact-only 纠正 4 条、制造 2 条错误；相对 rule-only 纠正 10 条、制造 8 条错误。', '',
        '## 4. 划分结构及额外种子', '',
        '每格顺序为 n / eligible / ineligible / groups / max-group-size。这里展示实际外层测试折；训练集仍为原 86 中不在该折的全部成员。', '',
        '| 外折（0-based） | 全 86 | 主集 73 | 敏感性 60 |', '|---|---|---|---|']
    for f in range(5):
        cells=[]
        for sub in ['all_86','compatible_code_73','exact_ten_digit_60']:
            q=splits[sub]['folds'][f]['test'];cells.append(' / '.join(str(q[k]) for k in ['n','positive','negative','groups','max_group_n']))
        L.append('| '+str(f)+' | '+' | '.join(cells)+' |')
    L+=['', '73 主集共 41 组：31 个单例组、4 个双例组、1 个三例组、4 个四例组、1 个 15 例组。最大组 G084 含 10 positive / 5 negative，全部来自 NY，全部在第 0 折；因此原第 0 折只有 3 组，不应只报告每折 n≈17 而让读者误以为折间依赖结构均匀。完整组成员和每个折的来源构成见 split_diagnostics.json。', '',
        '60 敏感性集第 2 折没有 negative，不能计算该折 BA；本文的 BA 是所有 out-of-fold 预测合并后的类召回均值，不是逐折 BA 平均。所有 inner training/validation 折仍有两类，已检查组隔离。', '',
        '| 外层随机种子 | Word LR：73 / 60 BA | Word+char LR：73 / 60 BA |', '|---|---|---|']
    for seed in [20261007,20261008,20261009,20261010]:
        names=['Frozen_LR_word','Frozen_LR_word_char'] if seed==20261007 else [f'LR_full_word_seed{seed}',f'LR_full_word_char_seed{seed}']
        cells=[pct(primary['all']['models'][m]['balanced_accuracy'])+' / '+pct(exact['all']['models'][m]['balanced_accuracy']) for m in names]
        L.append(f'| {seed} | '+ ' | '.join(cells)+' |')
    L+=['', '原结果与三个额外种子全部保留，不选择最优种子作为正文主值。word+char 在 73 主集为 56.30–58.88%；word-only 为 47.14–57.16%，显示较大的划分敏感性。四个种子不是四次独立研究，不能把其标准差当成总体置信区间。每种子逐案预测、具体折分配和训练日志均已保存。', '',
        '## 5. 双向跨来源训练', '',
        '先把测试来源的所有组留出，再从训练来源删除与其共享组的条目。HQ→NY 从 37 删除 H320060_1 后训练 n=36（11 positive、25 negative，25 组）；NY→HQ 从 49 删除 N304078 后训练 n=48（35 positive、13 negative，19 组）。这些源转移比较同时改变训练量、类别构成与文本分布，不是源属性的受控因果实验，也不是无偏部署评估。', '',
        '| 转移及特征 | 主集测试 n / groups | TN / FP / FN / TP | BA [CI] | 相对同测试条目的原 grouped OOF ΔBA [CI] |',
        '|---|---|---|---|---|']
    for name,d in a['cross_source'].items():
        q=d['subsets']['compatible_code_73'];diff=q['cross_minus_grouped_oof_same_test']['metrics']['balanced_accuracy']
        conf='/'.join(str(q[k]) for k in ['tn','fp','fn','tp'])
        L.append(f"| {name} | {q['n']} / {q['groups']} | {conf} | {ba(q)} | {pct(diff['delta'])} {ci(diff)} |")
    L+=['', '两方向 word+char 的主集 BA 为 33.89% 和 40.91%，提示在这个小样本的来源转移设定下，文本特征关系不稳定。不能推成所有法律文本模型均无法迁移。HQ→NY 相对相同 NY 样本的原 grouped OOF 下降 −26.94pp [−42.00,−6.69]，但这些训练集合不同，差值包含训练支持差异，应以诊断语气呈现。', '',
        'NY 主集的组重抽样有 1/2000 次缺 negative；这次 BA 未定义并排除，只用 1999 次有效重抽样。60 集 HQ 仅 11 组、14 对，63/2000 次缺少某一类，只剩 1937 次有效重抽样；其看似较高的 4B BA 必须同时给出这些支持信息，不作为新的主要结论。', '',
        '## 6. 可直接用于正文的英文材料', '',
        'Source composition materially affected aggregate evaluation. On the 73 compatible-code pairs, a training-fold source-majority classifier achieved balanced accuracy of 69.1% (cluster bootstrap 95% CI 57.7–82.3). It predicted ineligibility for all HQ cases and eligibility for all NY cases, yielding 50.0% balanced accuracy within each source. Qwen4 achieved 63.7% overall; its paired difference from the source classifier was −5.3 percentage points (95% CI −24.5 to 11.5), which does not establish a performance advantage for either model. The ordering reversed on the 60 exact-code pairs, but the paired interval again included zero. These comparisons identify sensitivity to sample composition rather than a deployable source-based decision rule.', '',
        'Using the original grouped folds and identical nested model selection, the full word-and-character classifier achieved 56.5% balanced accuracy, compared with 53.6% for fact-only and rule-only inputs and 69.1% for source-only inputs. The full-input increments over both text ablations were 3.0 percentage points, with paired intervals spanning zero. Three additional grouped seeds produced full word-and-character scores of 58.9%, 58.9%, and 56.3%. Cross-source training, after removing shared groups from the training source, yielded 33.9% for HQ-to-NY and 40.9% for NY-to-HQ. These small-sample diagnostics do not establish that any particular textual feature caused the transfer failure; they limit interpretations of pooled performance as evidence of generalizable product–provision reasoning.', '',
        'The numeric guard left Qwen4 binary predictions unchanged while reducing selective coverage from 91.8% to 64.4%. The corresponding change in answered error rate was −2.4 percentage points (paired 95% CI −9.0 to 4.6). Reduced coverage therefore cannot by itself substantiate a validated improvement in selective decision quality.', '',
        '## 7. 执行、核验与文件', '',
        f"- 已实际完成 54 个 classical 外层拟合任务，1,032 条新预测；训练总墙钟 {execution['seconds']:.2f} 秒，单 compute thread。模型选择还包括各任务内部 grid search。",
        '- 新 full-input 模型逐案标签与旧冻结模型完全一致，最大概率差 7.216e−16。',
        '- 独立 sklearn 重算 240 项模型/来源/子集点指标；逐行重抽样另算主集、NY 子集和稀疏 HQ 子集的 bootstrap 与 paired 区间，与向量化实现一致。',
        '- 已核验全部 54 个训练任务的外层、内层组不重叠和训练/验证两类支持；旧 Qwen4 三个已报告子集的点估计与区间全部复现。输入文件哈希保持不变。',
        '- 神经 fact-only/rule-only 消融尚未运行：旧 Qwen4 BF16 权重约 8 GB，而当时空闲物理内存约 5.5 GiB，且模型代理正在运行协议实验。本目录未以不同精度结果冒充纯输入消融；如模型代理完成同配置神经消融，可追加逐案预测并复算。',
        '- protocol.md：事后诊断计算协议；run_classical_diagnostics.py：真实训练；common.py 和 analyze_diagnostics.py：统计；verify_diagnostics.py：独立核验；write_report.py：本报告生成器。',
        '- all_diagnostic_predictions.jsonl：全部逐案原模型与诊断模型的 raw/gated binary 和 selective 预测；classical_predictions.jsonl：新增模型逐案输出；classical_training_log.json：训练/测试 IDs、组数、class support、C 与耗时。',
        '- diagnostic_analysis.json：完整分源、分子集 CI 及 paired 差值；metrics.csv 和 paired_differences.csv：可直接制表；split_diagnostics.json 和 seed_split_assignments.jsonl：全部组成员与外折支持。',
        '- verification.json：核验结果；training_execution.json：运行版本、时长和旧输入哈希；classical_reproduction.json：完整输入复现误差。', '',
        '限制：本轮尚不验证条件级 S/R/U 标签，不替代专家标注，也不衡量适用法规的法律正确性；这些诊断只针对现有冻结 disposition 目标。未对失败样本删改标签、替换规则或挑选更有利划分。']
    (OUT/'report.md').write_text('\n'.join(L)+'\n',encoding='utf-8')
    print('report.md written; checks passed:',verification['all_checks_passed'])

if __name__=='__main__':main()
