"""Independent metrics and literal resampling check for native three-state results."""
from common import *
from collections import Counter
from sklearn.metrics import f1_score

def recorded_path(value):
    """Resolve redacted package-relative provenance without changing its digest."""
    p=Path(value.replace('\\','/'))
    return p if p.is_absolute() else ROOT/p

def main():
    a=json.loads((OUT/'native_three_state_analysis.json').read_text());rows=load_rows()
    records=read(OUT/'native_three_state_predictions.jsonl');by={}
    for r in records:by.setdefault(r['model'],{})[r['case_id']]=r
    target={'support':1,'refute':0,'unknown':-1};checks=0
    for sub,sources in a['subsets'].items():
        ss=[r for r,m in zip(rows,subset_masks(rows)[sub]) if m]
        for source,d in sources.items():
            rr=ss if source=='all' else [r for r in ss if r['source']==source]
            for model,q in d['models'].items():
                y=[target[by[model][r['case_id']]['AI_evidence_reference']] for r in rr]
                p=[by[model][r['case_id']]['native_int'] for r in rr]
                accuracy=sum(yy==pp for yy,pp in zip(y,p))/len(y)
                assert abs(accuracy-q['metrics']['evidence_accuracy']['value'])<1e-12
                cm=[[sum(yy==c and pp==cc for yy,pp in zip(y,p)) for cc in [1,0,-1,-2]] for c in [1,0,-1]]
                assert cm==q['confusion_matrix'] and sum(map(sum,cm))==len(y)
                if len(set(y))==3:
                    mf=f1_score(y,p,labels=[1,0,-1],average='macro',zero_division=0)
                    assert abs(mf-q['metrics']['macro_f1']['value'])<1e-12
                det=[i for i,v in enumerate(p) if v in [1,0]]
                assert len(det)==q['determinate_n']
                assert sum(p[i]!=rr[i]['y'] for i in det)==q['determinate_disposition_errors']
                assert sum(pp==1 and yy!=1 for yy,pp in zip(y,p))==q['unsupported_support_outputs']
                assert sum(pp==1 and yy==-1 for yy,pp in zip(y,p))==q['unknown_reference_support_outputs']
                checks+=1
    rr=[r for r in rows if r['code_match']==1];groups=sorted({r['group'] for r in rr});rng=np.random.default_rng(BOOT_SEED)
    names=['Qwen4','NLI','Source_majority','Always_unknown','Qwen06']+list(a['inputs']);metrics={n:{'evidence_accuracy':[],'three_class_balanced_accuracy':[],'macro_f1':[]} for n in names}
    for _ in range(B):
        draw=rng.choice(groups,len(groups),replace=True);sample=[r for g in draw for r in rr if r['group']==g]
        for name in names:
            y=[target[by[name][r['case_id']]['AI_evidence_reference']] for r in sample];p=[by[name][r['case_id']]['native_int'] for r in sample]
            metrics[name]['evidence_accuracy'].append(sum(x==z for x,z in zip(y,p))/len(y))
            if len(set(y))==3:
                ct=Counter(y);pc=Counter(p);tp={k:sum(yy==pp==k for yy,pp in zip(y,p)) for k in [1,0,-1]}
                metrics[name]['three_class_balanced_accuracy'].append(sum(tp[k]/ct[k] for k in tp)/3)
                metrics[name]['macro_f1'].append(sum(2*tp[k]/(ct[k]+pc[k]) for k in tp)/3)
    for name,d in metrics.items():
        for metric,v in d.items():
            q=a['subsets']['compatible_code_73']['all']['models'][name]['metrics'][metric]
            assert np.allclose(np.quantile(v,[.025,.975]),[q['lower'],q['upper']],atol=1e-12)
            assert len(v)==q['valid_replicates']
    paired_checks=[]
    for name,d in a['subsets']['compatible_code_73']['all']['paired_differences'].items():
        aa,bb=name.split(' MINUS ')
        if aa not in metrics or bb not in metrics:continue
        for metric in ['evidence_accuracy','three_class_balanced_accuracy','macro_f1']:
            diff=np.asarray(metrics[aa][metric])-np.asarray(metrics[bb][metric]);q=d[metric]
            assert np.allclose(np.quantile(diff,[.025,.975]),[q['lower'],q['upper']],atol=1e-12)
        paired_checks.append(name)
    # This protocol produced the same native predictions as the original 0.6 letters.
    pair=a['subsets']['compatible_code_73']['all']['paired_differences']['Qwen06_semantic_json MINUS Qwen06']
    assert all(v['delta']==0 and v['lower']==0 and v['upper']==0 for v in pair.values())
    assert sha(recorded_path(a['reference_file']))==a['reference_sha256']
    assert all(sha(recorded_path(v['path']))==v['sha256'] for v in a['inputs'].values())
    report={'passed':True,'point_checks':checks,'literal_group_bootstrap_models':names,'literal_metrics_per_model':3,
            'literal_paired_difference_checks':paired_checks,
            'paired_Qwen06_protocol_identical':True,'reference_sha256':a['reference_sha256'],
            'current_source_hashes_match':True,'invalid_policy':'Checked 3x4 confusion preserves invalid column and row denominator'}
    dump(OUT/'native_verification.json',report);print(json.dumps(report,indent=2))

if __name__=='__main__':main()
