# Native three-state model diagnostics

本报告仅汇总已经完整写出 86 条、ID 集合完整且分析过程中哈希未变化的模型文件。未完成的模型不得当作已有实验。主要参照为 evidence_operational_reference.jsonl 的保守操作性 AI 证据状态（73 条：21 support、5 refute、47 unknown），包含已披露的源语义修订；不使用第一轮未协调的标签冒充最终参照。

三个模型语义标签分别映射证据 support/refute/unknown。未知是独立类，不强制转为不适用；非法 JSON 或分解规则/证据解析失败计 invalid，在三态准确率分母内作为错误，并单列格式失败。分解管线的 invalid_quote_forced_missing 则保留守卫后的实际三态输出，并另列管线状态。

区间沿用 2,000 次原 linked source-group 抽样，seed=20261007；同子集模型及差值共享抽样。三类 BA/macro-F1 只在该抽样含全部三参照类时计算，报告有效重复数。评估固定当前预测与参照编码，区间不包括 AI 编码误差或训练不确定性。

## 当前完成模型的主集结果

| 模型/协议 | Evidence accuracy [95% CI] | 3-class BA [95% CI] | Macro-F1 [95% CI] | 确定回答 coverage | 确定回答 disposition error |
|---|---|---|---|---|---|
| NLI | 42.47 [31.88, 53.25] | 32.33 [20.63, 49.88] | 31.81 [22.46, 43.15] | 42.47 | 48.39 |
| NLI_guard | 53.42 [35.00, 68.43] | 37.13 [24.51, 53.52] | 35.79 [24.34, 47.34] | 28.77 | 52.38 |
| Qwen06 | 28.77 [13.13, 48.06] | 33.33 [33.33, 33.33] | 14.89 [7.73, 21.66] | 100.00 | 35.62 |
| Qwen06_guard | 41.10 [25.00, 53.95] | 35.33 [24.16, 42.47] | 28.54 [17.01, 36.29] | 71.23 | 28.85 |
| Qwen4 | 36.99 [23.66, 53.85] | 53.70 [34.25, 68.75] | 33.17 [22.81, 45.02] | 91.78 | 34.33 |
| Qwen4_guard | 46.58 [31.25, 58.33] | 43.24 [28.63, 59.48] | 39.08 [26.69, 48.32] | 64.38 | 31.91 |
| Source_majority | 23.29 [8.75, 42.48] | 37.14 [19.30, 56.47] | 19.09 [8.50, 29.97] | 100.00 | 28.77 |
| Always_unknown | 64.38 [43.48, 81.08] | 33.33 [33.33, 33.33] | 26.11 [20.20, 29.85] | 0.00 | NA |
| Qwen06_semantic_json | 28.77 [13.13, 48.06] | 33.33 [33.33, 33.33] | 14.89 [7.73, 21.66] | 100.00 | 35.62 |
| Qwen14_abc_original | 28.77 [15.84, 45.90] | 53.65 [37.41, 66.67] | 25.78 [15.64, 37.31] | 100.00 | 31.51 |
| Qwen14_semantic_json | 23.29 [12.50, 39.22] | 47.30 [30.00, 62.22] | 22.55 [13.41, 34.51] | 100.00 | 39.73 |
| Granite8_abc_original | 27.40 [14.29, 46.00] | 57.14 [46.80, 66.67] | 27.69 [16.78, 39.67] | 100.00 | 34.25 |
| Granite8_semantic_json | 23.29 [11.90, 39.66] | 52.38 [43.33, 61.54] | 24.56 [14.93, 35.36] | 100.00 | 42.47 |
| Granite8_facts_only | 34.25 [23.13, 47.83] | 41.06 [24.56, 59.99] | 30.66 [19.63, 42.88] | 82.19 | 38.33 |
| Granite8_rules_only | 13.70 [6.09, 27.28] | 29.35 [10.18, 47.53] | 13.75 [6.20, 27.53] | 97.26 | 54.93 |
| Granite8_decomposition | 5.48 [1.15, 12.07] | 8.79 [0.53, 25.05] | 11.90 [0.99, 26.32] | 4.11 | 33.33 |

Source_majority 来自对 administrative disposition 的训练折来源多数规则，作为来源捷径诊断，并非针对新三态证据标签拟合的模型。Always_unknown 是不回答任何确定结论的常数诊断；其较高准确率反映参照类比例，不能称为有用法律系统。

## 已完成的 Qwen0.6 semantic JSON

冻结 86 条全部为 eligible，invalid=0、输入截断=0、生成上限命中=0，总推理墙钟 350.688 秒。73 主集与原 letter native 输出逐案相同；全部 paired 指标差值及区间为零。

在最终操作性参照上，主集三态 accuracy=21/73=28.77% [13.13,48.06]；macro recall=33.33%，macro-F1=14.89% [7.73,21.66]。有 17/2000 次组重抽样缺 refute 类，故三类指标使用 1983 个有效重复。常数输出的 macro recall 退化区间不是对真实能力精确掌握，而是固定预测与定义的结果。

确定回答覆盖率 100%，其 administrative disposition 错误率为26/73=35.62% [24.32,50.00]。这与证据任务错误率是不同目标，不能混称法律正确率。三态参照不是专家 gold。

该次 semantic JSON 协议没有消除旧 0.6 checkpoint 在此样本上的全部授予行为，因此不能把旧结果仅归为 A/B/C 字母抽取问题；同时 JSON 指令新增了语义约束，提示模板/解码也不同，这不是只改变输出格式的一因素实验。它也不说明所有 LLM 或尚未完成的新 checkpoint 具有同样行为。

## 0.6 JSON 的子集/来源支持

| 子集 | 来源 | n | S/R/U | Evidence accuracy [CI] | 3-class BA [CI] |
|---|---|---:|---|---|---|
| compatible_code_73 | all | 73 | 21/5/47 | 28.77 [13.13, 48.06] | 33.33 [33.33, 33.33] |
| compatible_code_73 | HQ | 27 | 6/2/19 | 22.22 [8.33, 38.10] | 33.33 [33.33, 33.33] |
| compatible_code_73 | NY | 46 | 15/3/28 | 32.61 [11.36, 67.65] | 33.33 [33.33, 33.33] |
| exact_ten_digit_60 | all | 60 | 20/4/36 | 33.33 [15.00, 59.57] | 33.33 [33.33, 33.33] |
| exact_ten_digit_60 | HQ | 14 | 5/1/8 | 35.71 [14.29, 63.64] | 33.33 [33.33, 33.33] |
| exact_ten_digit_60 | NY | 46 | 15/3/28 | 32.61 [11.36, 67.65] | 33.33 [33.33, 33.33] |

## 用于正文的限定表述

The semantic JSON protocol produced eligible for all 86 cases with no invalid or capped outputs. On the 73 compatible-code cases, its native predictions were identical to those from the original 0.6B letter protocol. Against the conservative AI evidence reference, three-state accuracy was 28.8% (cluster bootstrap 95% CI 13.1–48.1), with macro recall of 33.3%. These results show that the all-eligible behavior in this checkpoint and sample was not removed by the revised semantic protocol; they do not establish that output formatting alone caused the original behavior or that other models share the same limitation. Unknown and invalid outputs were not collapsed into ineligibility.

完整机器表为 native_three_state_analysis.json、native_three_state_metrics.csv，逐案输出为 native_three_state_predictions.jsonl。后续完整模型可通过 analyze_new_models.py 复算；CI 不混入未完成文件。

尚未完成/未提供的模型列表：

本统计管线内预定 native 模型文件均已完整提供。
