# Focused archive path and digest review

The minimal solution is to preserve every raw `models/outputs` JSON/JSONL file byte for byte, including neutral execution/cache locators. The package README now distinguishes these historical locators from portable verification paths. The manifest retains the source digest and the actual packaged digest for transformed derived records. No digest exception or fabricated digest is needed.

The two recorded-input checks in `verify_native_analysis.py` and the one in `verify_mechanism_metrics.py` now normalize recorded backslashes to `/`, keep absolute paths, and resolve relative paths against the project root. Their original SHA equality assertions are unchanged. `verify_diagnostics.py` applies the same slash normalization to its two relative training-input keys. Neither the prediction files, scientific algorithms, nor point/interval results changed.

All three verifiers were actually rerun in the original environment after these interface edits. Binary verification passed 264 point checks, the existing literal paired group resampling checks and the prior classifier reproduction comparison; native verification passed 72 point checks and nine models' literal group resampling; mechanism verification passed the three currently complete models and all three paired family comparisons. This is recalculation of saved outputs, not new model training or inference.

## Exact dependencies

| Check | Digest dependency | Archive implication |
|---|---|---|
| `verify_diagnostics.py` | Original `datasets/benchmark.jsonl` and `results/benchmark_classical.jsonl` | Original-bundle bytes are retained. Only relative backslash normalization was required. |
| `verify_native_analysis.py` | Final operational evidence reference and each complete new raw model file | References remain byte-identical; normalized package-relative resolution now reaches them independently of working directory. |
| `verify_mechanism_metrics.py` | Frozen/v2 constructed prediction files and complete raw mechanism model files | Same resolution repair; original digest comparisons remain exact. |
| `audit_completed_raw_outputs.py` | Fresh before/after file digest and literal rule-text digest | Does not compare the runner's historical source digest to portable code. Exact prompts, score arithmetic, strict JSON and rule text remain checked. |
| `audit_numeric_references.py` | Constructed-input digest from design record; fresh before/after digests | No transformed executable source digest assertion. The constructed source and frozen engine remain unchanged. |
| Original `verify_results.py` / `verify_scale_results.py` | Frozen `constraint_engine.py` digest | The original archive carries this exact file unchanged. It must not be relocated by rewriting its contents. |
| `run_gguf_models.py` resume guard | Checkpoint, `protocols.py`, benchmark digest | Not part of saved-output recomputation. The protocol module has no host path transformation and remains byte-identical. `runner_sha256` is execution provenance, not an assertion that the relocated runner has the old byte digest. |

The separate `decomposition_protocol.py` and `constraint_engine_v2.py` also have no host-root substitution. The package manifest therefore verifies their actual bytes directly. Portable changes to `common.py` legitimately change its own source digest; no saved-result verifier asserts that its current bytes equal a historical code digest.

`inspect_archive_hash_interfaces.py` checks the current pure archive transformations in memory without executing the archive builder. It resolves each current native/mechanism input locator and verifies that the simulated payload digest equals the stored original input digest. It separately records original and simulated packaged code digests. Its JSON report is a bounded source-snapshot check, not a claim that a final ZIP has been extracted and validated. The parent performs the final fresh-extraction checks after the complete model queue is frozen.
