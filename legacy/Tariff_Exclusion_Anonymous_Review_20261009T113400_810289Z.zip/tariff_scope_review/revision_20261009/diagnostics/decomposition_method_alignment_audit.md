# Condition-decomposition method alignment audit

Read-only source review, 9 October 2026. Inspected `models/decomposition_protocol.py`, `models/run_gguf_models.py`, and the imported `evidence_prompt`/`aggregate` functions in `models/protocols.py`, against the current Methods 4.2/4.6 and Appendix A. No inference, test rerun, parser change or outcome assessment was performed. Partial output files were not used to infer final performance. The running queue and frozen validation rules remain untouched.

## Required wording repairs

### 1. Distinguish requested semantic structure from what the validator establishes

**Locations:** `manuscript/task_methods.md`, Section 4.2, paragraph beginning “The semantic protocol uses greedy generation” (current line 65); `manuscript/appendices.md`, Appendix A, final paragraph (current line 15).

The rule prompt correctly instructs affirmative atomic requirements and NOT nodes, including the guarded-exception convention. However, `valid_logic` in `run_gguf_models.py` lines 53–64 checks the outer object, nonempty condition list capped at 25, distinct IDs, literal rule quotations, string requirements, operator structure/arity, ID membership and use of every condition. It does not verify that a requirement is affirmative, that all legally necessary conditions were recovered, or that the generated exception/alternative structure is faithful to the source. A structurally valid tree can still omit or misrepresent a condition.

**Methods replacement for the categorical generation sentence:**

> It is instructed to list necessary conditions with literal source quotations, preserve alternatives and exceptions, and assign local established, contradicted or missing states. Deterministic aggregation then evaluates the generated tree; structural and quotation checks do not establish that the tree is semantically complete or faithful to the rule.

**Appendix replacement for “Positive leaves and explicit NOT nodes avoid …; conditional guards and exceptions remain attached to their scopes”:**

> The prompt requires affirmative leaves and explicit NOT nodes to avoid double-negating a negative requirement, and instructs the model to preserve conditional guards and exception scope. These are representation requirements, not semantic properties certified by the structural validator.

**Appendix phrase “unsupported interpretations are separately reported”:** these inspected functions emit parse/structure and quotation statuses, not a semantic-interpretation-validity flag. Unless a separately completed interpretive audit is explicitly cited, replace the phrase with:

> Structural and quotation failures are recorded separately; literal quotation validity does not test the completeness of the decomposition, the scope of an exception or the entailment of an atomic requirement.

This is not a reason to relax the rule validator or retry failed rule generations with a favorable alternative.

### 2. Correct the claim that missing evidence always survives aggregation

**Location:** Appendix A, immediately after the definitions of AND, OR and NOT: “Missing evidence therefore survives aggregation.”

The preceding truth-table descriptions are correct, but this concluding sentence is too broad. The actual `aggregate` function (`protocols.py`, lines 41–47) uses strong three-valued propagation: AND is refuted if any child is refuted, and OR is supported if any child is supported, even if another child is unknown. NOT preserves unknown. This can also leave a determinate root after a quotation-failed leaf is forced to missing.

**Exact replacement:**

> Unknown is preserved by NOT and propagates unless a determinate sibling settles an AND or OR node.

The current Methods explanation of quotation failures already correctly says that a failed factual quotation lowers the associated condition to missing before aggregation. Keep that behavior distinct from invalid rule/evidence parsing.

### 3. State the limits of product quantification and factual binding

**Location:** Appendix A, following the three-valued aggregation description; optionally refer to it from Methods 4.2.

The task-level reference policy requires every listed product to satisfy the condition. The implementation has no product-indexed quantifier node, governed-object schema, numerical field executor or independent binding validator. Rule generation uses the candidate alone; factual evaluation sees the retained facts and generated conditions, but not the generated tree. Whether one fact applies to the right product, whether all products have been covered, and whether the same product satisfies multiple attributes therefore depend on model interpretation. The aggregator operates only on the supplied propositional leaves.

**Insert:**

> The deterministic stage supports propositional AND, OR and NOT; it does not separately execute product quantifiers or validate entity and attribute bindings. Coverage of every listed product, the attachment of a measurement and the fidelity of an exception remain responsibilities of the generated representation and evidence states.

The saved `fact_quote_start` is the first exact occurrence of the quoted string in the factual text. It is a provenance locator, not independent identification of the governed product or measurement role. This is covered by the proposed binding limitation; no separate experiment is needed.

### 4. Disclose rule-level caching, including failures, and narrow the general resume guarantee

**Locations:** Methods 4.2 for caching; Methods 4.6 sentence “Input fingerprints, checkpoint revisions, prompts, raw generations, scores and timing records prevent resumed runs from mixing different configurations.”

`decompose` keys the per-model rule cache by SHA-256 of the candidate wording after `scope()` removes the described-in locator. A valid rule tree is reused across cases sharing that exact text. An invalid rule parse is cached too: associated cases are marked `invalid_rule_parse` and receive no factual-generation call. There is no retry/repair of that cached parse. The rule-cache counts and case-level consequences are therefore different units.

**Insert in Methods 4.2:**

> One rule-generation result is cached per model and exact candidate wording after locator removal, including failed validations. A cached invalid rule makes each associated case structurally invalid without a factual-generation call; valid trees are followed by case-specific factual evaluation.

The runner records the revised decomposition-prompt and runner hashes, but the resume assertion at `run_gguf_models.py` line 117 directly compares only checkpoint, `protocols.py` and benchmark hashes. Cached rule records are keyed by rule text. The source therefore does not justify a blanket assertion that every possible decomposition configuration change is automatically rejected. No actual configuration mixing is inferred here.

**Exact narrower Methods 4.6 wording:**

> Checkpoint, benchmark and base-protocol hashes are checked on resume; decomposition-prompt and runner hashes, rendered prompts, raw generations, scores and timings are retained to audit configuration consistency.

Do not alter the running queue to add a different validation or retry rule. This correction concerns the documented guarantee, not a request for another experiment.

## Failure-state alignment already confirmed

The current Methods 4.2 was reread after its latest edit. It now distinguishes invalid rule schema/tree, invalid evidence parse, and a parsed factual quotation that fails literal verification. That paragraph is aligned with the inspected implementation.

Rule/evidence parse failures retain raw material and an explicit invalid pipeline status. Their placeholder `parsed='unknown'` and selective `-1` values must not be mistaken for a successful unknown answer. The metrics owner confirmed that `analyze_new_models.py::native()` maps `invalid_rule_parse`, `invalid_evidence_parse` and `pending_evidence` to invalid (`-2`), while `invalid_quote_forced_missing` retains the guard-adjusted E/I/U result. Quote-guard case/condition counts and final-state distributions are recorded separately. This confirmation is a code-owner report; this auditor did not rerun the metric code.

If a generated table note still says broadly “invalid decomposition stage”, use “invalid rule or evidence parse” to avoid classifying the recoverable quotation guard as a parse failure. Quote-guarded outputs can be unknown or determinate, depending on the remaining tree. All syntactic/quotation success remains weaker than verified legal interpretation.

## Initial numeric-v2 retention query

The existing `numeric_v2_initial_analysis.json` preserves the first revision engine hash, 23/33 real-case and 70/96 constructed matches, overall and mechanism-specific confusion counts, and eight real-case changes relative to the frozen component. It does not preserve the complete first-revision per-case predictions/traces or the first-revision source snapshot. Later execution of `evaluate_v2.py` writes to the same final prediction filenames. No historical files were reconstructed. The current Methods 4.5 now accurately says that the initial summary and final case-level predictions are retained; this item is resolved.

No inference outcomes are asserted by this report. The findings concern implementation guarantees and manuscript descriptions only.
