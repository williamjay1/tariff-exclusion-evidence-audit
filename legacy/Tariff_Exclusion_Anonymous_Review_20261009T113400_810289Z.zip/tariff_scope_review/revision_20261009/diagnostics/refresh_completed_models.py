"""Sequential statistics refresh. Does not train, infer, or edit source files."""
from common import *
import time,runpy
start=time.perf_counter();runs=[]
for script in ['analyze_diagnostics.py','analyze_new_models.py','analyze_mechanism_models.py','analyze_annotation_versions.py',
               'verify_diagnostics.py','verify_native_analysis.py','verify_mechanism_metrics.py',
               'audit_completed_raw_outputs.py','write_native_report.py','write_manuscript_blocks.py']:
    st=time.perf_counter();print('START',script,flush=True)
    runpy.run_path(str(OUT/script),run_name='__main__')
    runs.append({'script':script,'seconds':time.perf_counter()-st,'sha256':sha(OUT/script)})
report={'success':True,'total_seconds':time.perf_counter()-start,'runs':runs,
        'complete_models':json.loads((OUT/'manuscript_results_blocks_status.json').read_text('utf8'))}
dump(OUT/'completed_model_refresh.json',report);print('REFRESH FINISHED',report['total_seconds'],flush=True)
