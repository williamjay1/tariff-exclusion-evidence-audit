# Focused body-readiness audit

Read-only review, 9 October 2026. Reviewed the five manuscript components and the latest `diagnostics/manuscript_results_blocks.json`. Pending new-model blocks were treated as pending work, not manuscript errors. No prior numerical analyses were rerun. The single additional lookup below reads an already saved contingency summary; it does not regenerate labels or results.

The contribution is now framed as an evaluation and diagnostic resource, rather than a claim that a particular checkpoint wins or that extraction–execution decomposition is new. Section 2.3 appropriately acknowledges Holzenberger and Van Durme (2023). Its incremental questions are assessable through the shared ruling pairs, retained-input evidence policy, and governed-product/rating/measurement-scope controls. Methods 3.1, 3.3 and 4.5 and Discussion 6.2–6.4 adequately distinguish administrative outcome, AI evidence reference and numerical predicates. I found no necessary new experiment or additional literature requirement within this review's scope.

## 1. Add the direct administrative-outcome × evidence-state result to RQ2

**Location:** `manuscript/results_core.md`, Section 5.4, immediately following `[[EVIDENCE_RESULTS]]` and before the paragraph starting “Two source traces explain why the targets differ” (currently lines 52–54). The generated evidence block reports evidence margins and model agreement, but neither it nor the prose shows the joint distribution of the two reference targets.

**Why this matters:** This is the most direct empirical support for RQ2 and the paper's main increment beyond statutory extraction studies. Without it, the central distinction is illustrated by one case while the section's quantitative emphasis falls on model rankings. It also leaves the reader unable to tell whether the reference disagreement means contrary determinate judgments or withheld judgments under missing evidence.

**Insert the following result paragraph:**

> Among the 47 administratively eligible pairs, the operational AI evidence reference classified 21 as supported and 26 as unknown. Among the 26 administratively ineligible pairs, five were refuted and 21 were unknown. No pair received a determinate evidence state opposing its administrative disposition. The difference between the targets therefore concerns judgments withheld under the restricted-input policy, rather than demonstrated agency errors; an unknown state does not convert an eligible disposition into a denial.

The counts are already saved in `evidence_numeric/evidence_target_analysis.json`, key `disposition_by_operational_evidence`: eligible→support 21; eligible→unknown 26; ineligible→refute 5; ineligible→unknown 21. These are AI-policy states, not independently validated determinations of evidentiary sufficiency. No cross-tabulation of model outputs needs to be recomputed to make this addition.

This single paragraph supplies the most useful missing result-level anchor. RQ3 already has adequate concrete support: the four layer counts, paired differences, source-versus-extraction unknown decomposition, numeric-versus-whole-description opportunity counts, and the identifier/handle/relay traces. Repeating those numbers in another table or adding another generic contribution paragraph would add little.

## 2. Name the target in the H336040 “correct negative” sentence

**Location:** `manuscript/results_core.md`, Section 5.4, current line 54, final sentence of the H330938/H336040 paragraph:

> A correct negative prediction cannot establish that the model used the relevant condition.

**Replace with:**

> Agreement with the negative administrative disposition does not establish that the model used the relevant condition.

This sentence appears inside the evidence-target section. Naming the administrative target avoids suggesting independent legal correctness or leaving “correct” to refer ambiguously to the full retained-input evidence reference versus the truncated model input. This is a wording clarification, not a claim that native unknown outputs should be recoded or that the recorded prediction needs changing.

## Boundaries already handled adequately

No further revision is required merely because the coding is AI assisted: the manuscript discloses same-lineage passes, prior project exposure, condition-level versus case-level review, conservative reconciliation, subsequent source corrections and the absence of customs-law experts. The saved model blocks condition intervals on the current coding and supply alternative-coding sensitivities. The always-unknown diagnostic prevents ordinary evidence accuracy from being equated with useful decision coverage.

The numeric reference/reference result is explicitly an internal execution-consistency check. The revision parser is identified as a repair on inspected development cases; constructed controls are not added to the ruling sample. Local arithmetic success is not equated with full legal applicability. Pending Granite and mechanism blocks should be completed and integrated through the established process; their current placeholders do not generate another readiness objection here.

Only the two targeted edits above are requested. No manuscript, metadata, data or result file was modified by this audit.
