"""Pure helpers for post hoc diagnostics. Never import an old script with side effects."""
import os
for _k in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"]:
    os.environ[_k]="1"
import sys,json,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/"revision_20261009"/"diagnostics"
OUT.mkdir(parents=True,exist_ok=True)
BOOT_SEED=20261007
B=2000
def read(path):
    return [json.loads(s) for s in Path(path).read_text(encoding="utf-8").splitlines() if s.strip()]
def dump(path,obj):
    def conv(x):
        if isinstance(x,np.generic): return x.item()
        if isinstance(x,np.ndarray): return x.tolist()
        raise TypeError(type(x).__name__)
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=conv,allow_nan=False),encoding="utf-8")
def write_jsonl(path,rows):
    Path(path).write_text("".join(json.dumps(x,ensure_ascii=False,allow_nan=False)+"\n" for x in rows),encoding="utf-8")
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load_rows():
    rows=read(ROOT/"datasets/benchmark.jsonl")
    assert len(rows)==86 and len({r["case_id"] for r in rows})==86
    assert sum(r["code_match"]==1 for r in rows)==73
    assert sum(r["exact_code_match"] for r in rows)==60
    return rows
def row_meta(r):
    return {k:r[k] for k in ["case_id","y","group","source","fold","code_match","exact_code_match"]}
def record(r,model,raw,prob=None,selective_raw=None,**more):
    raw=int(raw); sr=raw if selective_raw is None else int(selective_raw)
    gate=r["code_match"]==0
    return {**row_meta(r),"model":model,"binary_raw":raw,"binary":0 if gate else raw,
            "selective_raw":sr,"selective":0 if gate else sr,
            "prob_eligible":None if prob is None else float(prob),**more}
def subset_masks(rows):
    return {"all_86":np.ones(len(rows),bool),
            "known_code_85":np.array([r["code_match"] is not None for r in rows]),
            "compatible_code_73":np.array([r["code_match"]==1 for r in rows]),
            "exact_ten_digit_60":np.array([bool(r["exact_code_match"]) for r in rows])}
def count_matrix(rows,p,s):
    y=np.array([r["y"] for r in rows]);p=np.asarray(p);s=np.asarray(s);keep=s!=-1
    return np.stack([np.ones(len(y),int),y==1,y==0,(y==1)&(p==1),(y==1)&(p==0),
                     (y==0)&(p==1),(y==0)&(p==0),keep,keep&(s!=y),
                     (y==0)&(s==1),(y==1)&(s==0),keep&(y==1),keep&(y==0)],axis=1).astype(int)
def rates(counts):
    c=np.asarray(counts,dtype=float);n,pos,neg,tp,fn,fp,tn,ans,err,sfp,sfn,ap,an=np.moveaxis(c,-1,0)
    def div(a,b):
        return np.divide(a,b,out=np.full_like(a,np.nan,dtype=float),where=b!=0)
    return {"accuracy":div(tp+tn,n),"balanced_accuracy":(div(tp,pos)+div(tn,neg))/2,
            "false_exemption_rate":div(fp,neg),"eligible_recall":div(tp,pos),
            "coverage":div(ans,n),"answered_error_rate":div(err,ans),
            "eligible_coverage":div(ap,pos),"ineligible_coverage":div(an,neg)}
def summary_counts(c):
    names=["n","positive","negative","tp","fn","fp","tn","answered","answered_errors",
           "selective_false_exemptions","selective_false_denials","eligible_answered","ineligible_answered"]
    d={k:int(v) for k,v in zip(names,c)}
    d["referrals"]=d["n"]-d["answered"]
    d["confusion_matrix"]=[[d["tn"],d["fp"]],[d["fn"],d["tp"]]]
    d["confusion_labels"]=[0,1]
    d.update({k:(float(v) if np.isfinite(v) else None) for k,v in rates(c).items()})
    return d
def bootstrap_plan(rows):
    groups=np.array([r["group"] for r in rows]);u=np.unique(groups);rng=np.random.default_rng(BOOT_SEED)
    draws=rng.integers(len(u),size=(B,len(u)))
    multiplicity=np.stack([np.bincount(v,minlength=len(u)) for v in draws])
    return groups,u,multiplicity
def evaluate(rows,records,plan=None):
    byid={x["case_id"]:x for x in records}
    assert len(byid)==len(records)
    rec=[byid[r["case_id"]] for r in rows]
    p=np.array([r["binary"] for r in rec]);s=np.array([r["selective"] for r in rec])
    counts=count_matrix(rows,p,s);groups,u,mult=plan or bootstrap_plan(rows)
    gc=np.stack([counts[groups==g].sum(0) for g in u])
    sampled=rates(mult@gc);out=summary_counts(counts.sum(0));out["groups"]=len(u);out["cluster_bootstrap_95ci"]={}
    for k,v in sampled.items():
        a=v[np.isfinite(v)]
        out["cluster_bootstrap_95ci"][k]={"lower":float(np.quantile(a,.025)) if len(a) else None,
                                         "upper":float(np.quantile(a,.975)) if len(a) else None,
                                         "valid_replicates":int(len(a)),"requested_replicates":B}
    return out,sampled,p,s
def paired(rows,rec_a,rec_b,plan):
    a,va,pa,sa=evaluate(rows,rec_a,plan);b,vb,pb,sb=evaluate(rows,rec_b,plan)
    y=np.array([r["y"] for r in rows])
    out={"n":len(rows),"groups":a["groups"],
         "corrected":int(sum((pa==y)&(pb!=y))),"new_errors":int(sum((pa!=y)&(pb==y))),"metrics":{}}
    for k in va:
        v=va[k]-vb[k];ok=v[np.isfinite(v)]
        point=None if a[k] is None or b[k] is None else a[k]-b[k]
        out["metrics"][k]={"delta":point,
                          "lower":float(np.quantile(ok,.025)) if len(ok) else None,
                          "upper":float(np.quantile(ok,.975)) if len(ok) else None,
                          "valid_replicates":int(len(ok))}
    return out

