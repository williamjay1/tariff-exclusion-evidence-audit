# 对用户修订意见的全文内容与覆盖审计

审计对象为用户粘贴意见（2026年10月9日）及现有五个部分：`introduction_related.md`、`task_methods.md`、`results_core.md`、`discussion_conclusion.md`、`appendices.md`。本审计只读，未改动正文。执行时主代理正在整合新结果，因此以下位置以章节及段首识别；已知GGUF实验、结果表和相关占位属于在途任务，不重复列为新遗漏。本轮没有重新核验外部期刊指标或文献全文，结论只涉及用户意见的内容覆盖和当前主张边界。

## 总体判断

研究主线已从小模型低分和单一正则缺陷，转为三个可区分的评价对象：行政结论一致性、受限事实的证据支持、数值表示与执行。用户允许的AI-only方案已被落实为有来源跨度、初始分歧记录及敏感性目标的诊断参考。五节均未将其冒称专家金标，也没有声称获得人类独立验证。无需继续把“没有海关专家”列为本轮必须虚构补齐的阻断项。

此前指出的三处问题已经修好：条件记录不再冒称统一的对象字段；第二轮明确为逐案状态和理由；多产品的全称量词及离散评级已经写进任务定义。

仍需精确处理的主线问题是：证据参考对应完整保留事实，而非每个模型截断后的真实输入；原始区间情景的量词需要明示；任务外法律前提应写成设定而非已经核查的事实。建议加一个很短的条件编码实例，使双目标不只由定义和汇总数字构成。其余建议主要是把已经完成的结果接入正文，以及压缩研究过程叙述。

## 与原意见的覆盖映射

| 原意见 | 当前落实位置 | 审计判断 |
|---|---|---|
| III：以证据敏感适用评估为贡献，不包装自主裁定系统 | 引言三个RQ；讨论6.1–6.4；结论 | 已落实。没有把局部97.1%写成真实法律适用准确率。 |
| IV：行政二元目标与证据三状态目标分离 | 方法3.1、3.3；结果5.4；证据文件 | 已落实；初始两轮与最终操作性参考均保留。证据结果占位由已完成文件填充，不属未做实验。 |
| IV：保留合取、析取、例外和嵌套 | 方法3.1；条件记录；附录A逻辑树 | 已落实，未统一压成合取清单。 |
| IV：86来源检查、73条件编码、结果隐藏、分歧记录 | 方法3.2–3.3；结果5.4；AI声明 | AI-only替代已明确。208条件记录、第二轮逐案评价、66/73初始一致及第三轮来源修正应分别报告，不能称独立专家一致率。 |
| IV：不能从分析段补事实后仍声称原输入 | 方法3.2；H330938实例；冻结数据 | 已遵守。保留输入未改，行政目标没有被证据标签覆盖。 |
| V：保留原4B，再加更大模型和不同家族 | 方法4.1、结果5.3在途占位 | 配置与比较协议已有设计。GGUF尚待运行是已知在途工作，此处不重复报缺。完成后仍须用实际日志核实措辞。 |
| V：条件分解基线 | 方法4.2、附录A | 已设计，保留树和引文检验；运行结果随GGUF任务完成。引文匹配没有被当成语义正确的证明。 |
| V：独立短题、字母与位置正交、另一输出格式 | 方法4.2；结果5.3；附录A | 已落实。324正交执行、9题语义输出及86例语义协议结果已报告，并保留原来不利输出。 |
| V：不要从弱模型接口失效推论普遍法律能力 | 引言2.3；方法4.1；结果5.3；讨论6.4 | 已落实。没有将规模、后训练、模板和量化的混合变化解释为纯规模效应。 |
| VI：来源内结果、来源基线区间及配对差 | 结果5.2 | 已落实。来源多数与来源逻辑回归也被准确区分。 |
| VI：完整/事实/规则/来源输入消融 | 方法4.3；结果5.2表2；神经消融占位 | 经典模型已完成；神经模型是已知在途项。没有从相近分数直接推断模型内部捷径机制。 |
| VI：双向来源迁移、构成变化限制 | 方法4.3；结果5.2；讨论6.4 | 已落实，并清楚说明小样本分布变化不能识别偏差的因果来源。 |
| VI/VII：语义等价与决定性改变配对 | 方法4.5；结果5.5；附录B | 20等价、26决定性、2同状态控制已区分，且报告“两侧均正确”而非只报不变性。 |
| VII：真实数值机会与四层控制 | 方法4.5；结果5.5 | 已完成43条件/33例、四层33/30/17/17及1/3/1可纠正affirmative机会。已说明reference字段不是自动系统能力。 |
| VII：旧引擎保留、修订不能只有单案补丁 | 方法4.5；结果5.5；分离v2文件 | 多机制与一般词法修复已完成。新v2没有独立留出测试，故仅可称同诊断集上的事后修复；正文已如实限定，这属于对建议的透明收窄，不是完成了“独立一般性验证”。 |
| VII：unknown原因进入结果 | 结果5.5 | 已有日志分解及测量范围、评级实例。建议再加下述7与15互斥分解，直观区分源证据未知和自动化损失。 |
| VIII：2482→102流程、不编中间阅读数 | 方法3.2；结果5.4；讨论6.4；检索台账 | 已落实可证明阶段，未伪造2390份未入选裁定的逐案排除原因或人工阅读数量。没有全量召回率主张。 |
| VIII：73主集与60精确集、折与组结构 | 方法3.2、3.4；结果5.2；附录B表B1 | 已落实；主集地位未依结果改变。 |
| VIII：397清单语义判定和边界 | 方法3.2；结果5.1；库存审计 | 已从旧356修为354＋2日期换码，词法标记与语义条件未混同。 |
| VIII：合成去重与逻辑单位 | 方法4.4–4.5；附录B表B2 | 480/443/435/60/59及96/88已集中定义；仍应明确原始straddling interval的单一属性不确定性解释。 |
| VIII：方法间差值、分组区间、额外种子 | 方法3.4；结果5.2、5.6；附录B | 模型/来源、消融、guard、种子已完成。此次另应主代理要求补跑了数值四层及v2配对差值，见下文。 |
| VIII：覆盖率与错误、成本附录、review-all | 方法4.6；结果5.6；附录C | 已落实，未宣称真实节税、审阅时间或固定质量人工服务已经得到验证。 |
| IX：同刊VITA、自动标注、模型成本研究 | 相关工作2.2–2.3 | 已有任务与参考结构层面的对话，而非机械添加引用；未跨数据集直接比较准确率。 |
| XI：设计图、流程图、错误来源图 | 方法3.1–3.2；结果5.5 | 对应真实实验结构，未画成已经验证的自主系统。此次未进行视觉版式审计。 |
| XI：匿名复现入口与完整声明 | 数据代码声明、AI声明 | 内容要求覆盖。最终审稿包仍须实际随交付提供；当前“archive accompanies”应由最终打包状态支持。不能把文件清单等同于已公开DOI。 |

## 需要实质精确化的正文位置

### 1. 证据参考与模型截断后的可见输入不完全一致

位置：`introduction_related.md`，2.2末段末句：“the restricted input actually supplied to each model”；方法3.3与4.1及证据结果表说明。

73例证据标签基于完整冻结事实。NLI的512-token处理会截断事实，原始审计显示主集有70例不截断、3例截断。故“每个模型实际得到的输入”过强；H336040的截断实例本身已说明二者不同。这会影响读者将证据任务分数解释为文本蕴含能力，而不是单纯表述问题。

建议替换相关工作末句：

> Our separate evidence target operationalizes that distinction for the retained factual input defining the benchmark; model-specific truncation is recorded separately.

证据结果表或方法3.3增加：

> Evidence codes refer to the full retained facts. NLI predictions are evaluated against that common reference despite model-specific truncation; the untruncated subset is reported separately.

若未另报证据分数的不截断子集，把最后一个分句改为明确局限，不可声称已经报告。无需改原标签或悄悄把事实补进模型。

### 2. 原始区间测试应明确表示单个属性的认识不确定性

位置：`task_methods.md`，4.4首段“A factual interval passes…”及原始480场景定义；`appendices.md`表B2后。

多产品已正确使用全称量词；但原始straddling interval未直说它不同于已知多个型号的值集合。一个未知真实值跨界，应是unknown；已知多个产品中有越界值，则可能存在确定反例。这正是relay修正所揭示的区别。

建议增加：

> In the local scenarios, an interval represents uncertainty about one product attribute, not a known list of distinct products or component-specific measurements. Known product lists and rating alternatives retain their own quantifiers and bindings.

### 3. 任务外条件应写成研究设定，不暗示已逐案核查

位置：`task_methods.md`，3.1首段“conditional on classification, origin, timing and procedure being separately checked”。

当前表述可能被理解为作者已经完成所有来源、时间和程序要件核查。研究实际供应base code与历史candidate，原产地、申报程序及实际进口日期不属于本研究独立验证对象。

可替换为：

> The task supplies the product's base classification and the candidate wording considered in the historical ruling. Origin, import timing and filing compliance are held outside the prediction target and are not independently verified here.

### 4. 用一个简短来源编码实例使双目标可复查

位置：方法3.1结尾或结果5.4的H330938段后。原意见要求“具体标注示例”，当前有说明性个案，但没有展示条件→证据→状态的最小完整链条。无需新增数据或大表。

可展示H330938四行：

| Literal requirement | Retained factual span | AI-coded state |
|---|---|---|
| “[M]onopolar conductors” | “single conducting aluminum core” | supported |
| “for a voltage exceeding 1,000 V” | “2000V” | supported |
| “other than of copper” | “single conducting aluminum core” | supported, with the conducting core distinguished from protective copper strands |
| “not fitted with connectors” | No supporting or contradicting retained span | unknown |

表下说明合取聚合为unknown，行政目标仍eligible，且前三行也是可争议的AI解释而非专家判决。该实例已有逐字跨度与理由；不应补入分析段事实。

## 已补齐、只待主稿整合的内容

数值四层配对差值已实际运行，输出在 `evidence_numeric/numeric_paired_differences.json`，并纳入统一JSON与英文报告。33例属于原16个linked groups，最大组15例；2,000次、seed 20261007、同组抽样、固定预测、每次合并案例计数。所有对比均有2,000个有效重采样。另一代理用组重复次数矩阵独立复算，全部结果一致。

| 固定条件下的对比 | 三状态参考匹配率差，百分点 | 95%组重采样区间 |
|---|---:|---:|
| reference fields−automatic fields，reference rule固定 | 48.5 | 33.3至66.7 |
| reference fields−automatic fields，automatic rule固定 | 39.4 | 18.7至50.0 |
| reference rule−automatic rule，reference fields固定 | 9.1 | 0.0至33.3 |
| reference rule−automatic rule，automatic fields固定 | 0.0 | 0.0至0.0 |
| 事后v2−原全自动引擎 | 21.2 | 10.0至35.0 |

这些不是BA差、因果效果或部署收益；reference/reference33/33仍是编码执行内部一致性，v2差值仍是同数据开发诊断。

unknown分解可以直接从既有confusion补一条，避免读者只看到混合计数单位：

> Of the 22 automatic unknowns, seven remain unknown under the source-coded representation; fifteen replace a determinate reference state—twelve passes and three failures—with abstention.

这区分了源证据仍不确定与自动处理未恢复确定参考状态，不需要再建立未经验证的法律真值分类。

## 重复与程序语言：建议压缩的位置

1. **引言RQ3的“independent mechanism tests”**。主代理已收到并正在改为“constructed mechanism tests with paired controls”。保留事后开发边界，不把新造情景等同于未触碰的独立验证。
2. **引言最后一段前两句**“Original experiments…Revision experiments…”更像修订说明。方法与结果已充分交代冻结及追加历史，引言可用资源与评价对象概括替代：

   > The study combines a dated official inventory, public ruling pairs with separate administrative and evidence targets, and numerical diagnostics that control rule and field representations.

   之后直接接贡献句即可；不要删除方法中的事后性披露。
3. **结果5.5的v2段与机制段末尾**均重复发展历史。保留两套主要结果及一次明确的“same inspected diagnostics”限定即可；初始23/33、近似处理修复、八条语法修订的完整过程放方法4.5及归档，结果避免讲两遍。对结果有解释价值的“例外组5降至1”应保留。
4. **结论第二段**“retains unfavorable predictions…instead of…”是研究诚信过程陈述，与首段的实质贡献重复。可换成：

   > The resource permits separate evaluation of administrative agreement, evidence-supported scope, and numerical predicate recovery under specified inputs. Its source spans and layer controls make disagreements inspectable while preserving unresolved conditions for further review.

5. **AI声明最后一句**“does not claim that a human author has already completed…”诚实但属于草稿进度语言。不要改为虚构人工核查；可用责任声明替换：

   > The submitting author remains responsible for the accuracy and integrity of the final manuscript and its supporting materials.

   AI参与范围、没有专家标注、来源和结果只经AI及程序复核的事实应完整保留。最终实际投稿前的作者审阅不是本审计可以代称已经发生的动作。

## 结论与停止范围

从内容覆盖看，原意见最重要的任务分离、源证据检查、接口诊断、来源控制、数值层拆分及成本降调均已实质推进。AI-only调整符合用户后续指令，并保留有效性边界。本轮不要求补大规模专家用户研究、不要求虚构独立留出集、不要求重写成贸易因果论文，也不把未完成的GGUF占位重复报成新问题。完成上述精确化和在途结果接入后，应做针对新增数字的最终检查，而不是再次从头启动同一覆盖审计。
