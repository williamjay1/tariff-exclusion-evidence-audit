"""Native three-state evidence evaluation; unknown/invalid are never forced negative.
All outputs here are post hoc, conditional on AI-coded diagnostic references.
Completed (86-case) files only. No model inference and no writes to sources.
"""
from common import *
from collections import Counter,defaultdict
import csv
M=ROOT/'revision_20261009/models/outputs';E=ROOT/'revision_20261009/evidence_numeric'
LABELS={1:'eligible',0:'ineligible',-1:'unknown',-2:'invalid'}
TO_INT={'eligible':1,'ineligible':0,'unknown':-1,'support':1,'refute':0}

def native(q):
    status=q.get('pipeline_status','')
    if status in ['invalid_rule_parse','invalid_evidence_parse','pending_evidence']:return -2
    if q.get('invalid_output'):return -2
    if 'parsed' in q:return TO_INT.get(q['parsed'],-2)
    return q.get('selective_prediction') if q.get('selective_prediction') in [1,0,-1] else -2

def load_models(rows):
    ids={r['case_id'] for r in rows};models={};sources={};pending=[]
    # Original selective outputs supply native class predictions, not forced binaries.
    old=read(OUT/'all_diagnostic_predictions.jsonl')
    for name in ['NLI','NLI_guard','Qwen06','Qwen06_guard','Qwen4','Qwen4_guard','Source_majority']:
        ps=[p for p in old if p['model']==name]
        models[name]={p['case_id']:{'case_id':p['case_id'],'native':p['selective_raw'],'pipeline_status':'original_selective'} for p in ps}
    models['Always_unknown']={r['case_id']:{'case_id':r['case_id'],'native':-1,'pipeline_status':'constant_unknown_diagnostic'} for r in rows}
    specs=[('Qwen06_semantic_json','benchmark_qwen06_semantic_json.jsonl')]
    for model,title in [('qwen14','Qwen14'),('granite8','Granite8')]:
        for suffix in ['abc_original','semantic_json']+(['facts_only','rules_only','decomposition'] if model=='granite8' else []):
            specs.append((title+'_'+suffix,f'benchmark_{model}_{suffix}.jsonl'))
    for name,filename in specs:
        p=M/filename
        if not p.exists():pending.append({'model':name,'status':'not_available'});continue
        h=sha(p);rr=read(p)
        if len(rr)!=86 or {r['case_id'] for r in rr}!=ids:
            pending.append({'model':name,'status':'incomplete','n':len(rr)});continue
        models[name]={r['case_id']:{**r,'native':native(r)} for r in rr}
        sources[name]={'path':str(p),'sha256':h,'n':len(rr),'status_counts':dict(Counter(r.get('pipeline_status','direct') for r in rr)),
                       'invalid':sum(native(r)==-2 for r in rr),'native_counts':dict(Counter(LABELS[native(r)] for r in rr)),
                       'truncated':sum(bool(r.get('truncated')) for r in rr),'stopped_limit':sum(bool(r.get('stopped_limit')) for r in rr),
                       'inference_seconds':sum(r.get('seconds',0) for r in rr)}
        if name.endswith('_decomposition'):
            sources[name]['quote_guard']={}
            for subset,mask in subset_masks(rows).items():
                ids_sub={r['case_id'] for r,m in zip(rows,mask) if m}
                ss=[r for r in rr if r['case_id'] in ids_sub]
                bad=[r for r in ss if any(not c.get('quote_valid',False) for c in r.get('conditions',[]))]
                sources[name]['quote_guard'][subset]={
                    'cases':len(ss),'bad_quote_cases':len(bad),
                    'bad_quote_conditions':sum(not c.get('quote_valid',False) for r in ss for c in r.get('conditions',[])),
                    'recorded_conditions':sum(len(r.get('conditions',[])) for r in ss),
                    'guarded_case_final_native_counts':dict(Counter(LABELS[native(r)] for r in bad)),
                    'guarded_case_determinate_n':sum(native(r) in [0,1] for r in bad),
                    'guarded_case_determinate_coverage':sum(native(r) in [0,1] for r in bad)/len(bad) if bad else None,
                    'status_count':sum(r.get('pipeline_status')=='invalid_quote_forced_missing' for r in ss)}
                assert len(bad)==sources[name]['quote_guard'][subset]['status_count']
            rulepath=M/(filename.replace('benchmark_','').replace('_decomposition.jsonl','_decomposition_rules.jsonl'))
            if rulepath.exists():
                needed={r['rule_sha256'] for r in rr};rule_rows=read(rulepath)
                used=[r for r in rule_rows if r['rule_sha256'] in needed]
                assert len(used)==len(needed) and len({r['rule_sha256'] for r in used})==len(needed)
                sources[name]['rule_parse_source']={'path':str(rulepath),'sha256':sha(rulepath)}
                sources[name]['cached_unique_rule_parses']=len(used)
                sources[name]['rule_parse_seconds']=sum(r.get('seconds',0) for r in used)
                sources[name]['total_inference_seconds_including_rule_parses']=sources[name]['inference_seconds']+sources[name]['rule_parse_seconds']
    return models,sources,pending

def counter_matrix(rows,pm,refs):
    y=np.array([TO_INT[refs[r['case_id']]['aggregate_evidence_state']] for r in rows]);p=np.array([pm[r['case_id']]['native'] for r in rows]);dy=np.array([r['y'] for r in rows]);det=np.isin(p,[1,0])
    return np.stack([np.ones(len(rows),int),y==p,y==1,y==0,y==-1,
                     (y==1)&(p==1),(y==0)&(p==0),(y==-1)&(p==-1),
                     p==1,p==0,p==-1,p==-2,det,det&(p!=dy),det&(p!=y),
                     (p==1)&(y!=1),(p==1)&(y==-1)],axis=1).astype(int),y,p

def native_rates(c):
    z=np.asarray(c,float);n,correct,ns,nr,nu,ts,tr,tu,ps,pr,pu,invalid,det,de,ee,us,uus=np.moveaxis(z,-1,0)
    def div(a,b):return np.divide(a,b,out=np.full_like(a,np.nan,dtype=float),where=b!=0)
    complete=(ns>0)&(nr>0)&(nu>0)
    recall=(div(ts,ns)+div(tr,nr)+div(tu,nu))/3
    f1=(div(2*ts,ns+ps)+div(2*tr,nr+pr)+div(2*tu,nu+pu))/3
    return {'evidence_accuracy':div(correct,n),'three_class_balanced_accuracy':np.where(complete,recall,np.nan),
            'macro_f1':np.where(complete,f1,np.nan),'supported_recall':div(ts,ns),'refuted_recall':div(tr,nr),'unknown_recall':div(tu,nu),
            'determinate_coverage':div(det,n),'determinate_disposition_error_rate':div(de,det),
            'determinate_evidence_error_rate':div(ee,det),'unknown_output_rate':div(pu,n),'invalid_output_rate':div(invalid,n),
            'unsupported_share_of_support_outputs':div(us,ps),'unknown_reference_to_support_rate':div(uus,nu)}

def assess(rows,pm,refs,plan):
    counts,y,p=counter_matrix(rows,pm,refs);groups,u,mult=plan
    total=counts.sum(0);gc=np.stack([counts[groups==g].sum(0) for g in u]);br=native_rates(mult@gc);point=native_rates(total)
    d={'n':len(rows),'groups':len(u),'reference_counts':dict(Counter(LABELS[int(z)] for z in y)),
       'prediction_counts':dict(Counter(LABELS[int(z)] for z in p)),
       'confusion_rows':['eligible','ineligible','unknown'],'confusion_columns':['eligible','ineligible','unknown','invalid'],
       'confusion_matrix':[[int(sum((y==a)&(p==b))) for b in [1,0,-1,-2]] for a in [1,0,-1]],
       'determinate_n':int(total[12]),'determinate_disposition_errors':int(total[13]),'determinate_evidence_errors':int(total[14]),
       'unsupported_support_outputs':int(total[15]),'unknown_reference_support_outputs':int(total[16]),
       'metrics':{}}
    for k,v in point.items():
        valid=br[k][np.isfinite(br[k])];d['metrics'][k]={'value':float(v) if np.isfinite(v) else None,
            'lower':float(np.quantile(valid,.025)) if len(valid) else None,'upper':float(np.quantile(valid,.975)) if len(valid) else None,
            'valid_replicates':int(len(valid)),'requested_replicates':B}
    return d,br

def main():
    rows=load_rows();refpath=E/'evidence_operational_reference.jsonl';refhash=sha(refpath)
    refs={r['case_id']:{**r,'aggregate_evidence_state':r['operational_evidence_state']} for r in read(refpath)};assert len(refs)==73
    models,sources,pending=load_models(rows);out={'protocol':{'post_hoc':True,'reference':'Conservative operational AI source-coded S/R/U, including disclosed third-pass corrections; not human/expert gold',
        'resampling':'Original source groups, 2000 paired draws, seed20261007; predictions fixed',
        'invalid_policy':'Invalid direct JSON or invalid rule/evidence parse is invalid, counted wrong in evidence accuracy, excluded from determinate coverage. No U/invalid forced to ineligible.',
        'quote_guard_policy':'invalid_quote_forced_missing retains the guard final native label; pipeline status is reported separately',
        'three_class_bootstrap':'Macro recall/F1 require all 3 reference classes in each draw; per-class recall requires its class; report valid draws.',
        'binary_disposition':'Only determinate eligible/ineligible native outputs enter answered error rate. No forced binary BA for native JSON.',
        'comparison_scope':'JSON and letter prompts/scoring differ; a paired comparison is protocol sensitivity, not isolated decoding causality.'},
        'reference_file':str(refpath),'reference_sha256':refhash,'inputs':sources,'pending':pending,'subsets':{}}
    pairs=[('Qwen06_semantic_json','Qwen06')]
    for title in ['Qwen14','Granite8']:
        pairs += [(title+'_semantic_json',title+'_abc_original'),(title+'_abc_original','Source_majority'),
                  (title+'_semantic_json','Always_unknown'),
                  (title+'_semantic_json','Qwen06_semantic_json'),(title+'_decomposition',title+'_semantic_json'),
                  (title+'_abc_original',title+'_facts_only'),(title+'_abc_original',title+'_rules_only')]
    flat=[];allrows=[]
    for name,pm in models.items():
        for r in rows:
            x=pm[r['case_id']];allrows.append({**row_meta(r),'model':name,'native_prediction':LABELS[x['native']],
                'native_int':x['native'],'AI_evidence_reference':refs[r['case_id']]['aggregate_evidence_state'] if r['case_id'] in refs else None,
                'pipeline_status':x.get('pipeline_status','direct'),'invalid_output':x['native']==-2})
    for sub in ['compatible_code_73','exact_ten_digit_60']:
        ss=[r for r,m in zip(rows,subset_masks(rows)[sub]) if m];out['subsets'][sub]={}
        for source in ['all','HQ','NY']:
            rr=ss if source=='all' else [r for r in ss if r['source']==source];plan=bootstrap_plan(rr)
            d={'n':len(rr),'models':{},'paired_differences':{}};boots={}
            for name,pm in models.items():
                d['models'][name],boots[name]=assess(rr,pm,refs,plan)
                for metric,v in d['models'][name]['metrics'].items():flat.append({'subset':sub,'source':source,'model':name,'metric':metric,**v})
            for aa,bb in pairs:
                if aa not in models or bb not in models:continue
                delta={}
                for k,va in boots[aa].items():
                    vb=boots[bb][k];v=va-vb;valid=v[np.isfinite(v)]
                    pa=d['models'][aa]['metrics'][k]['value'];pb=d['models'][bb]['metrics'][k]['value']
                    delta[k]={'delta':None if pa is None or pb is None else pa-pb,
                        'lower':float(np.quantile(valid,.025)) if len(valid) else None,
                        'upper':float(np.quantile(valid,.975)) if len(valid) else None,'valid_replicates':int(len(valid))}
                d['paired_differences'][aa+' MINUS '+bb]=delta
            out['subsets'][sub][source]=d
    assert refhash==sha(refpath),'Reference changed during analysis: rerun final version'
    assert all(sha(Path(v['path']))==v['sha256'] for v in sources.values()),'Prediction source changed during analysis'
    dump(OUT/'native_three_state_analysis.json',out);write_jsonl(OUT/'native_three_state_predictions.jsonl',allrows)
    with (OUT/'native_three_state_metrics.csv').open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
    print(json.dumps({'complete_models':list(models),'reference_sha256':refhash,'Qwen06_semantic_main':out['subsets']['compatible_code_73']['all']['models'].get('Qwen06_semantic_json')},indent=2))

if __name__=='__main__':main()
