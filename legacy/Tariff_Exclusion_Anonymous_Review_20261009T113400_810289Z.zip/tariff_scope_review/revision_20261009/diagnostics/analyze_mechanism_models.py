"""Fixed 12-family mechanism diagnostics. No IID 96-row inference."""
from common import *
from collections import Counter,defaultdict
from analyze_new_models import native,assess,LABELS
E=ROOT/'revision_20261009/evidence_numeric';M=ROOT/'revision_20261009/models/outputs'
MAP={'pass':1,'fail':0,'unknown':-1}

def main():
    source=E/'constructed_diagnostics.jsonl';h=sha(source);rr=read(source)
    assert len(rr)==96 and len({r['case_id'] for r in rr})==96
    refs={r['case_id']:{'aggregate_evidence_state':LABELS[MAP[r['gold']]]} for r in rr}
    rows=[{**r,'y':MAP[r['gold']]} for r in rr]
    groups=defaultdict(list)
    for r in rows:groups[r['pair_id']].append(r)
    assert len(groups)==48 and all(len(v)==2 for v in groups.values())
    models={};inputs={};pending=[]
    for name,filename in [('Frozen_numeric','constructed_frozen_engine_predictions.jsonl'),('Posthoc_numeric_v2','constructed_v2_predictions.jsonl')]:
        p=E/filename;z=read(p);assert {r['case_id'] for r in z}==set(refs)
        models[name]={r['case_id']:{'native':MAP[r['prediction']]} for r in z}
        inputs[name]={'path':str(p),'sha256':sha(p),'n':len(z)}
    for model,title in [('qwen14','Qwen14_semantic_json'),('granite8','Granite8_semantic_json')]:
        p=M/f'mechanism_{model}_semantic_json.jsonl'
        if not p.exists():pending.append({'model':title,'status':'not_available'});continue
        z=read(p)
        if len(z)!=96 or {r['case_id'] for r in z}!=set(refs):
            pending.append({'model':title,'status':'incomplete','n':len(z)});continue
        models[title]={r['case_id']:{**r,'native':native(r)} for r in z}
        inputs[title]={'path':str(p),'sha256':sha(p),'n':len(z),'inference_seconds':sum(r.get('seconds',0) for r in z),
                      'invalid':sum(native(r)==-2 for r in z),'truncated':sum(bool(r.get('truncated')) for r in z),
                      'stopped_limit':sum(bool(r.get('stopped_limit')) for r in z)}
    result={'protocol':{'reference':'AI-authored explicit numeric design references; not actual exclusions or human/expert gold',
        'sampling':'12 purposive mechanism families, 48 linked pairs, 96 presentations, 88 exact unique fact-rule inputs',
        'cluster_intervals':'Conditional family-resampling sensitivity, 2000 fixed-prediction draws over 12 families. No IID 96-case CI or population sampling claim.',
        'pair_consistency':'Same predictions alone do not mean correctness; both-correct and state-transition results are reported separately.',
        'posthoc_v2':'Developed on these already inspected diagnostics; not independent validation'},
        'reference_sha256':h,'inputs':inputs,'pending':pending,'models':{},'paired_differences':{}}
    plan=bootstrap_plan(rows);boots={};flat=[]
    for name,pm in models.items():
        m,boots[name]=assess(rows,pm,refs,plan)
        # Native assess disposition risk is inapplicable to a three-state synthetic
        # target. Remove it rather than labelling synthetic U an administrative act.
        m.pop('determinate_disposition_errors');m['metrics'].pop('determinate_disposition_error_rate')
        m['correct']=sum(pm[r['case_id']]['native']==r['y'] for r in rows)
        byfamily={}
        for family in sorted({r['group'] for r in rows}):
            ss=[r for r in rows if r['group']==family]
            byfamily[family]={'n':len(ss),'correct':sum(pm[r['case_id']]['native']==r['y'] for r in ss),
                'invalid':sum(pm[r['case_id']]['native']==-2 for r in ss),
                'confusion':dict(Counter(LABELS[r['y']]+'->'+LABELS[pm[r['case_id']]['native']] for r in ss))}
        m['by_family']=byfamily;m['pairs']={}
        for kind in sorted({r['pair_type'] for r in rows}):
            ps=[v for v in groups.values() if v[0]['pair_type']==kind]
            m['pairs'][kind]={'n':len(ps),
                'both_correct':sum(all(pm[r['case_id']]['native']==r['y'] for r in v) for v in ps),
                'same_prediction':sum(pm[v[0]['case_id']]['native']==pm[v[1]['case_id']]['native'] for v in ps),
                'same_reference':sum(v[0]['y']==v[1]['y'] for v in ps),
                'any_invalid':sum(any(pm[r['case_id']]['native']==-2 for r in v) for v in ps)}
        unique={}
        for r in rows:
            key=r['facts'],r['rule_text'];p=pm[r['case_id']]['native']
            if key in unique:assert unique[key]['y']==r['y']
            # Duplicate model outputs may differ. Average within the exact input
            # cluster, instead of silently selecting a favorable repeated output.
            unique.setdefault(key,{'y':r['y'],'correct':[],'predictions':[]})['correct'].append(p==r['y'])
            unique[key]['predictions'].append(p)
        m['exact_unique_weight_sensitivity']={'n':len(unique),'mean_accuracy':float(np.mean([np.mean(v['correct']) for v in unique.values()])),
            'exact_duplicate_clusters_with_different_predictions':sum(len(set(v['predictions']))>1 for v in unique.values())}
        result['models'][name]=m
        for r in rows:flat.append({'case_id':r['case_id'],'model':name,'family':r['group'],'pair_id':r['pair_id'],
             'pair_type':r['pair_type'],'gold':LABELS[r['y']],'prediction':LABELS[pm[r['case_id']]['native']],
             'correct':pm[r['case_id']]['native']==r['y']})
    pairs=[('Posthoc_numeric_v2','Frozen_numeric')]
    for model in ['Qwen14_semantic_json','Granite8_semantic_json']:
        pairs.extend([(model,'Frozen_numeric'),(model,'Posthoc_numeric_v2')])
    pairs.append(('Granite8_semantic_json','Qwen14_semantic_json'))
    for a,b in pairs:
        if a not in models or b not in models:continue
        entry={}
        for metric in ['evidence_accuracy','three_class_balanced_accuracy','macro_f1','unknown_recall']:
            da=boots[a][metric]-boots[b][metric];valid=da[np.isfinite(da)]
            pa=result['models'][a]['metrics'][metric]['value'];pb=result['models'][b]['metrics'][metric]['value']
            entry[metric]={'delta':None if pa is None or pb is None else pa-pb,
                'lower':float(np.quantile(valid,.025)) if len(valid) else None,
                'upper':float(np.quantile(valid,.975)) if len(valid) else None,'valid_replicates':len(valid)}
        result['paired_differences'][a+' MINUS '+b]=entry
    assert h==sha(source)
    assert all(sha(Path(v['path']))==v['sha256'] for v in inputs.values())
    dump(OUT/'mechanism_model_analysis.json',result);write_jsonl(OUT/'mechanism_model_predictions.jsonl',flat)
    print(json.dumps({'complete_models':list(models),'pending':pending,'counts':{k:v['correct'] for k,v in result['models'].items()}}))
if __name__=='__main__':main()
