from common import *
from collections import Counter
E=ROOT/'revision_20261009/evidence_numeric'
for name in ['evidence_condition_codes.jsonl','root_visible_evidence_review.json','evidence_operational_reference.jsonl']:
    p=E/name
    x=read(p) if name.endswith('jsonl') else json.loads(p.read_text('utf8'))
    print(name,'type',type(x).__name__,'length',len(x))
    if isinstance(x,dict):
        print('keys',list(x))
        for k,v in x.items():
            if isinstance(v,list) and v:print(k,'list n',len(v),'first',v[0])
    else:print('first',x[0])
    if name=='root_visible_evidence_review.json':print('states',dict(Counter(r['state'] for r in x['records'])))
    elif name=='evidence_condition_codes.jsonl':print('states',dict(Counter(r['aggregate_evidence_state'] for r in x)))
    else:print('states',dict(Counter(r['operational_evidence_state'] for r in x)))
