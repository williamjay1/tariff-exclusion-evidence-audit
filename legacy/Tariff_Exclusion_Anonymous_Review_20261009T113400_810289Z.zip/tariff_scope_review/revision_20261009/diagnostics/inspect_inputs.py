from common import *
E=ROOT/'revision_20261009/evidence_numeric'
for fn in ['constructed_diagnostics.jsonl','constructed_frozen_engine_predictions.jsonl','constructed_v2_predictions.jsonl']:
    r=read(E/fn)[0]
    print(fn,{k:v for k,v in r.items() if k!='trace'})
nl=read(ROOT/'results/benchmark_nli.jsonl')
print('NLI schema',list(nl[0]))
print('NLI truncation fields', [{k:v for k,v in r.items() if k not in ['facts','rule_text','hypothesis','premise'] and ('trunc' in k or k=='case_id' or 'token' in k)} for r in nl if r.get('truncated') or r.get('input_truncated') or r.get('truncation')])
for name in ['qwen14','granite8']:
    p=ROOT/'revision_20261009/models/outputs'/f'{name}_preflight.jsonl'
    if p.exists():
        print(name, [{k:r.get(k) for k in ['case_id','protocol','expected','parsed','invalid_output']} for r in read(p)])
