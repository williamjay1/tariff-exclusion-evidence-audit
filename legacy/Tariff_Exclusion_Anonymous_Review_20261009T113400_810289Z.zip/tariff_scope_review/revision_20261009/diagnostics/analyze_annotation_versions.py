"""Descriptive reference-version sensitivity; fixed predictions, no refitting/CIs."""
from common import *
from collections import Counter,defaultdict
from sklearn.metrics import recall_score,accuracy_score
E=ROOT/'revision_20261009/evidence_numeric';MAP={'support':1,'refute':0,'unknown':-1}
def canonical(x):return {'supported':'support','refuted':'refute'}.get(x,x)

def main():
    rows=[r for r in load_rows() if r['code_match']==1];ids={r['case_id'] for r in rows};assert len(ids)==73
    paths={'first_pass':E/'evidence_condition_codes.jsonl','second_case_pass':E/'root_visible_evidence_review.json',
           'final_operational':E/'evidence_operational_reference.jsonl'}
    first=read(paths['first_pass']);second=json.loads(paths['second_case_pass'].read_text('utf8'))['records'];final=read(paths['final_operational'])
    refs={}
    for key,rs,field in [('first_pass',first,'aggregate_evidence_state'),('second_case_pass',second,'state'),('final_operational',final,'operational_evidence_state')]:
        assert len(rs)==73 and {r['case_id'] for r in rs}==ids
        assert all(canonical(r[field]) in MAP for r in rs)
        refs[key]={r['case_id']:canonical(r[field]) for r in rs}
    assert all(r['first_pass_state']==refs['first_pass'][r['case_id']] and r['second_pass_state']==refs['second_case_pass'][r['case_id']] for r in final)
    predfile=OUT/'native_three_state_predictions.jsonl';preds=read(predfile);models=defaultdict(dict)
    for r in preds:
        if r['case_id'] in ids:
            assert r['case_id'] not in models[r['model']]
            models[r['model']][r['case_id']]=r['native_int']
    result={'protocol':{'scope':'Fully descriptive fixed-prediction sensitivity to three preserved AI coding versions; no bootstrap, refitting, tuning, or reference selection.',
        'reference_validity':'Same-lineage AI readings with prior project exposure, plus conservative/source corrections. None is independent human/expert truth.',
        'input_scope':'All labels concern complete retained text. NLI truncation and input-omission ablations are not silently recoded.',
        'invalid_policy':'Invalid outputs count as incorrect, with no forced negative or unknown conversion.',
        'normalization':'Second-pass supported/refuted labels mapped literally to support/refute; no substantive recoding.'},
        'n':73,'case_ids':[r['case_id'] for r in rows],
        'class_counts':{k:dict(Counter(v.values())) for k,v in refs.items()},'models':{},
        'source_sha256':{k:sha(p) for k,p in paths.items()},'prediction_sha256':sha(predfile)}
    flat=[]
    for name,pm in models.items():
        assert set(pm)==ids
        p=[pm[r['case_id']] for r in rows];d={}
        for key,ref in refs.items():
            y=[MAP[ref[r['case_id']]] for r in rows]
            correct=sum(a==b for a,b in zip(y,p));ct=Counter(y)
            recalls={s:sum(a==b==v for a,b in zip(y,p))/ct[v] for s,v in MAP.items()}
            acc=correct/73;macro=sum(recalls.values())/3
            assert np.isclose(accuracy_score(y,p),acc)
            assert np.isclose(recall_score(y,p,labels=[1,0,-1],average='macro',zero_division=0),macro)
            d[key]={'correct':correct,'accuracy':acc,'macro_recall':macro,'per_class_recall':recalls,
                'confusion_reference_S_R_U_prediction_S_R_U_invalid':[[sum(a==v and b==w for a,b in zip(y,p)) for w in [1,0,-1,-2]] for v in [1,0,-1]]}
        d['max_minus_min_accuracy']=max(x['accuracy'] for x in d.values())-min(x['accuracy'] for x in d.values())
        d['final_minus_first_accuracy']=d['final_operational']['accuracy']-d['first_pass']['accuracy']
        d['final_minus_second_accuracy']=d['final_operational']['accuracy']-d['second_case_pass']['accuracy']
        result['models'][name]=d
        for r in rows:flat.append({'case_id':r['case_id'],'model':name,'native_prediction':pm[r['case_id']],
            **{k:ref[r['case_id']] for k,ref in refs.items()}})
    result['independent_point_checks']='Literal class counts and correct-count ratios verified against sklearn accuracy_score and macro recall_score for every model/version.'
    assert result['prediction_sha256']==sha(predfile)
    assert result['source_sha256']=={k:sha(p) for k,p in paths.items()}
    dump(OUT/'annotation_version_sensitivity.json',result);write_jsonl(OUT/'annotation_version_predictions.jsonl',flat)
    print(json.dumps({'n':73,'class_counts':result['class_counts'],'models':len(models),
        'accuracy_first_second_final':{k:[d[v]['accuracy'] for v in refs] for k,d in result['models'].items()}}))
if __name__=='__main__':main()
