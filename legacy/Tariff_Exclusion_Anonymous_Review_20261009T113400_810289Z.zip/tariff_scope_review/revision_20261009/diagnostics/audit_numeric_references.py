"""Read-only audit; independent arithmetic checks, no evaluated-parser gold creation."""
from common import *
import re,importlib.util
from decimal import Decimal as D
from collections import Counter,defaultdict
E=ROOT/'revision_20261009/evidence_numeric'
def num(v):return D(v.replace(',',''))
N=r'\d[\d,]*(?:\.\d+)?'
def numbers(s):return [num(x) for x in re.findall(N,s)]
def above_ceiling(vals,limit):
    return 'pass' if max(vals)<=limit else 'fail' if min(vals)>limit else 'unknown'
def field(t,name,unit):
    m=re.search(name+r' (?:is )?('+N+r') '+unit,t,re.I)
    return num(m[1]) if m else None

def independent_constructed(r):
    t=r['facts'];rule=r['rule_text'];m=r['mechanism'];q=numbers(rule);limit=q[0]
    if m in ['identifier','component_binding']:
        v=field(t,'motor power','W');return 'unknown' if v is None else above_ceiling([v],limit)
    if m=='mass_capacity':return above_ceiling([field(t,'lifting capacity','kg')],limit)
    if m=='comparative_facts':
        vs=numbers(t);v=vs[0]
        if 'from ' in t:return above_ceiling(vs,limit)
        if 'not more than' in t or 'less than' in t or 'below' in t:
            return 'pass' if v<=limit else 'unknown'
        if 'more than' in t:return 'fail' if v>=limit else 'unknown'
        if 'at least' in t:return 'fail' if v>limit else 'unknown'
        return above_ceiling([v],limit)
    if m=='conflicting_reports':return above_ceiling([num(x) for x in re.findall('('+N+r') W',t)],limit)
    if m=='unit_equivalence':
        v=numbers(t)[0]
        if '1 kg' in rule:
            if re.search(r'\bg\.',t):v/=1000
        elif 'kg' in rule and ' lb.' in t:v*=D('0.45359237')
        elif 'mm' in rule and 'inch' in t:v*=D('25.4')
        elif ' W' in rule and 'kW' in t:v*=1000
        return above_ceiling([v],limit)
    if m=='compound_units':
        # Unit exponent '2' is not a threshold: parse the two numerical bounds explicitly.
        lo=num(re.search(r'at least ('+N+r') g/m2',rule)[1]);hi=num(re.search(r'not more than ('+N+r') g/m2',rule)[1])
        v=numbers(t)[0]*(1000 if 'kg/m2' in t else 1)
        return 'pass' if lo<=v<=hi else 'fail'
    if m=='two_sided_bounds':return 'pass' if q[0]<numbers(t)[0]<q[1] else 'fail'
    if m=='dimension_binding':
        return 'pass' if all(field(t,name,'cm')<=ceiling for name,ceiling in zip(['length','width','height'],q)) else 'fail'
    if m=='disjunction':
        st=[]
        for name,c in zip(['width','height'],q):
            v=field(t,name,'cm');st.append('unknown' if v is None else above_ceiling([v],c))
        return 'pass' if 'pass' in st else 'fail' if all(x=='fail' for x in st) else 'unknown'
    if m=='nested_exception':
        weight=numbers(t)[0]
        if 'battery status is unspecified' in t:
            states={above_ceiling([weight],c) for c in q};return states.pop() if len(states)==1 else 'unknown'
        return above_ceiling([weight],q[0] if 'not battery-powered' in t else q[1])
    if m=='measurement_uncertainty':
        if 'approximately' in t:return 'unknown'
        values=numbers(t)
        return above_ceiling([values[0]-values[1],values[0]+values[1]],limit) if len(values)==2 else above_ceiling(values,limit)
    raise ValueError(m)

def main():
    constructed=read(E/'constructed_diagnostics.jsonl');design=json.loads((E/'constructed_diagnostics_design.json').read_text())
    refs=read(E/'numeric_reference_fields.jsonl');visible={r['case_id']:r for r in read(E/'evidence_visible_inputs.jsonl')}
    layers=read(E/'numeric_layer_predictions.jsonl');summary=json.loads((E/'numeric_layer_analysis.json').read_text())
    pred=read(E/'constructed_frozen_engine_predictions.jsonl');predmap={r['case_id']:r for r in pred}
    out={'audit_type':'Independent AI audit, not human/expert validation','input_hashes':{p.name:sha(p) for p in [E/'constructed_diagnostics.jsonl',E/'numeric_reference_fields.jsonl',E/'numeric_layer_predictions.jsonl',E/'numeric_layer_analysis.json',E/'evidence_visible_inputs.jsonl']},'constructed':{},'numeric_layers':{}}
    assert sha(E/'constructed_diagnostics.jsonl')==design['sha256']
    reviewed=[];pairs=defaultdict(list);duplicates=defaultdict(list)
    for r in constructed:
        state=independent_constructed(r);reviewed.append({'case_id':r['case_id'],'gold':r['gold'],'independent_reference_state':state,'agreement':state==r['gold'],'mechanism':r['mechanism']})
        pairs[r['pair_id']].append(r);duplicates[r['facts'],r['rule_text']].append(r)
    for name,rr in pairs.items():
        assert len(rr)==2 and len({r['pair_type'] for r in rr})==1
        assert (rr[0]['gold']!=rr[1]['gold'])==(rr[0]['pair_type']=='decisive_change')
    u=[rr[0] for rr in duplicates.values()]
    out['constructed']={'n':len(constructed),'unique_exact_fact_rule_inputs':len(duplicates),'pair_n':len(pairs),
        'mechanism_n':len({r['mechanism'] for r in constructed}),'independent_label_agreement':sum(r['agreement'] for r in reviewed),
        'independent_review_rows':reviewed,'pair_type_label_consistency':True,
        'duplicate_input_clusters':[[r['case_id'] for r in rr] for rr in duplicates.values() if len(rr)>1],
        'duplicate_labels_consistent':all(len({r['gold'] for r in rr})==1 for rr in duplicates.values()),
        'descriptive_duplicate_sensitivity':{'weighted_rows_correct':sum(predmap[r['case_id']]['correct'] for r in constructed),'weighted_n':len(constructed),
                     'unique_exact_input_correct':sum(predmap[r['case_id']]['correct'] for r in u),'unique_n':len(u),
                     'note':'Diagnostic only; no independence claim. Semantic near-duplicates remain.'}}
    assert all(r['agreement'] for r in reviewed)
    span_checks=0
    for r in refs:
        inp=visible[r['case_id']];c=r['constraint'];assert inp['rule_text'][slice(*c['span'])]==c['quote'];span_checks+=1
        for f in r['evidence_quotes']:
            assert inp['facts'][slice(*f['span'])]==f['quote'];span_checks+=1
        for f in r['reference_fields']:
            for s in f['source_quotes']:assert inp['facts'][slice(*s['span'])]==s['quote'];span_checks+=1
    refby=defaultdict(list)
    for r in refs:refby[r['case_id']].append(r)
    layerchecks={}
    for name in layers[0]['layers']:
        count=Counter();correct=0
        for r in layers:
            es=[e['expected_numeric_state'] for e in refby[r['case_id']]]
            gold='fail' if 'fail' in es else 'unknown' if 'unknown' in es else 'pass'
            assert gold==r['numeric_reference_state']
            p=r['layers'][name]['state'];p='unknown' if p=='not_parsed' else p
            count[gold+'->'+p]+=1;correct+=gold==p
        target=summary['layer_results'][name];assert count==target['confusion'] and correct==target['three_state_correct']
        layerchecks[name]={'n':len(layers),'correct':correct,'confusion':dict(count)}
    spec=importlib.util.spec_from_file_location('readonly_frozen_engine',ROOT/'scripts/constraint_engine.py')
    engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)
    for r in constructed:
        state=engine.verify_numeric(r['facts'],r['rule_text'])['state'];state='unknown' if state=='not_parsed' else state
        assert state==predmap[r['case_id']]['prediction']
    for r in layers:
        v=visible[r['case_id']];p=engine.verify_numeric(v['facts'],v['rule_text'])
        assert p['state']==r['layers']['auto_rule_auto_fields']['state']
    out['numeric_layers']={'cases':len(layers),'conditions':len(refs),'exact_quote_span_checks':span_checks,
        'visible_input_excluded_outcome_keys':all(not ({'y','reference_disposition','reference_quote','holding','predictions'}&set(r)) for r in visible.values()),
        'summary_counts_reproduced':layerchecks,'full_auto_reexecuted_and_matched':len(layers),
        'constructed_engine_reexecuted_and_matched':len(constructed),
        'reference_reference_status':'Internal execution consistency against the same source-coded reference fields, not independent predictive validation',
        'author_blinding_status':'Input files/scripts omit disposition and prediction fields, but this does not establish author-level blinding or absence of prior exposure.'}
    # Two source-semantic corrections found by this audit, verified against v3.
    handle=[r for r in refs if r['case_id']=='H318593_1' and r['constraint']['attribute'] in ['length','width','height']]
    assert len(handle)==3 and all(r['expected_numeric_state']=='unknown' and not r['reference_fields'] for r in handle)
    relay=next(r for r in refs if r['case_id']=='N311039_33' and r['constraint']['attribute']=='voltage')
    subjects=[]
    for f in relay['reference_fields']:
        states=['pass' if D('60')<D(v['lower'])<=D('250') else 'fail' for v in f['interpretations']]
        state=states[0] if len(set(states))==1 else 'unknown'
        subjects.append({'subject':f['subject'],'alternative_states':states,'subject_state':state})
    assert [s['subject_state'] for s in subjects]==['fail','unknown','fail','fail']
    assert relay['expected_numeric_state']=='fail'
    relaypred=next(r for r in layers if r['case_id']=='N311039_33')
    assert relaypred['layers']['reference_rule_reference_fields']['state']=='fail'
    assert relaypred['layers']['auto_rule_reference_fields']['state']=='fail'
    out['numeric_layers']['audit_corrections_verified']={'H318593_1':'3 dimensions unknown: source excludes handle, rule does not',
          'N311039_33':{'subjects':subjects,'all_listed_products_state':'fail','adapter_status':'Source-coded test-only subject binding; not original extractor functionality'}}
    assert all(sha(E/k)==v for k,v in out['input_hashes'].items()),'Input changed during audit'
    out['all_computational_checks_passed']=True
    dump(OUT/'independent_numeric_computational_audit.json',out)
    print(json.dumps({k:v for k,v in out.items() if k not in ['constructed','numeric_layers']},indent=2))
    print('constructed labels',out['constructed']['independent_label_agreement'],'of',len(constructed))
    print('layer_checks',layerchecks,'span_checks',span_checks)

if __name__=='__main__':main()
