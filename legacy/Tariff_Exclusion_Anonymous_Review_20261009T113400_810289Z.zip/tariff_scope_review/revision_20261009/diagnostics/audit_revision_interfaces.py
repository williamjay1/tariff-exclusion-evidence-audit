"""Read-only replay of already evaluated v2 rows and bounded interface audit."""
from common import *
import importlib.util
E=ROOT/'revision_20261009/evidence_numeric';M=ROOT/'revision_20261009/models'
files=[E/n for n in ['constraint_engine_v2.py','numeric_reference_fields.jsonl','constructed_diagnostics.jsonl',
                     'real_numeric_v2_predictions.jsonl','constructed_v2_predictions.jsonl']]
before={str(p):sha(p) for p in files}
spec=importlib.util.spec_from_file_location('readonly_v2_audit',E/'constraint_engine_v2.py')
v2=importlib.util.module_from_spec(spec);spec.loader.exec_module(v2)
inputs={r['case_id']:r for r in read(E/'evidence_visible_inputs.jsonl')}
constructed={r['case_id']:r for r in read(E/'constructed_diagnostics.jsonl')}
out={'read_only':True,'source_hashes':before,'replay':{},'issues':[]}
for label,fn,inp in [('real33','real_numeric_v2_predictions.jsonl',inputs),
                     ('constructed96','constructed_v2_predictions.jsonl',constructed)]:
    saved=read(E/fn);matched=[];correct=[]
    for r in saved:
        x=inp[r['case_id']];p=v2.verify_numeric(x['facts'],x['rule_text'])['state']
        p='unknown' if p=='not_parsed' else p
        assert p==r['prediction'],(r['case_id'],p,r['prediction'])
        matched.append(r['case_id']);correct.append(p==r['gold'])
    out['replay'][label]={'n':len(saved),'predictions_matched':len(matched),'correct':sum(correct)}
unique={}
for r in read(E/'constructed_v2_predictions.jsonl'):
    x=constructed[r['case_id']];unique[x['facts'],x['rule_text']]=r
out['replay']['constructed_unique']={'n':len(unique),'correct':sum(r['correct'] for r in unique.values())}
out['issues']=[
 {'id':'V2-1','severity':'reporting_boundary','status':'already_disclosed',
  'finding':'Parser repairs and the subsequent approximate-report correction were developed after inspecting these same diagnostics. Replayed scores measure same-suite repair, not held-out generalization.'},
 {'id':'V2-2','severity':'scope_limit','status':'not_a_new_data_error',
  'finding':'Literal motor/lamp binding and number boundary repair cover a limited grammar. The program does not implement arbitrary entity binding, general quantifiers, exceptions, compound-unit algebra, or all legal requirements.'},
 {'id':'GGUF-1','severity':'high','status':'resolved_before_new_inference',
  'finding':'Initial decomposition instruction could place a negated leaf under NOT and double-negate. Model agent introduced affirmative proposition leaves, negation in logic and guarded conditional exceptions in separately versioned decomposition_protocol.py before new GGUF inference.'},
 {'id':'GGUF-2','severity':'reporting_boundary','status':'handled_in_statistics',
  'finding':'Invalid rule/evidence parse stores operational unknown for referral, but must be counted invalid rather than correctly predicted unknown in evidence evaluation. Statistics uses pipeline_status to enforce this.'},
 {'id':'GGUF-3','severity':'reporting_boundary','status':'already_disclosed',
  'finding':'Literal quote occurrence and logic schema checks do not verify entailment, complete requirement coverage, or semantic scope. A quote-valid decomposition remains model-generated.'},
 {'id':'GGUF-4','severity':'reporting_boundary','status':'already_disclosed',
  'finding':'New semantic JSON adds missing-fact and AND/OR instructions as well as changing output form. Paired comparisons measure joint instruction/output-protocol sensitivity, not a single-factor format intervention.'},
]
out['interface_checks']={
 'ABC':'Stable softmax over three recovered single-token log probabilities; forced binary compares eligible vs ineligible only; native prediction uses all three. Bare-letter mass recorded separately.',
 'JSON':'Strict sole decision key with one of eligible/ineligible/unknown; invalid is not forced negative.',
 'logical_aggregation':'Kleene AND/OR/NOT are consistent for established, contradicted, missing; no legal truth guarantee follows from valid syntax.',
 'decomposition_input_separation':'Rule parsing sees literal rule only; evidence prompt sees facts and extracted conditions; cached rule representations keyed by rule text.',
 'context':'Inputs exceeding context are rejected rather than silently truncated.'}
out['decision']='No open fatal implementation discrepancy identified in the bounded audit; retain disclosed developmental and semantic limits.'
assert before=={str(p):sha(p) for p in files}
for p in [M/'run_gguf_models.py',M/'decomposition_protocol.py']:
    if p.exists():out['source_hashes'][str(p)]=sha(p)
dump(OUT/'revision_interface_audit.json',out)
text='''# Revision interface audit

This is a bounded read-only replay and code review, not an independent external validation.

The final v2 implementation was independently rerun on the already evaluated 33 restricted-text numerical cases and 96 constructed inputs. Every saved prediction was reproduced: **24/33**, **73/96**, and **66/88 exact unique constructed inputs**. No source file was altered. The final numerical-reference hash is `85675a17300559c6830ddb8471611a65f1933767a9eb55e2f53efaf4fe0b49e6`.

These are same-suite post hoc repairs, including a second correction after the initial repair run. They cannot be described as held-out generalization. The parser retains a limited lexical grammar; identifier boundaries and motor/lamp binding are not general entity resolution. General quantifiers, legal scope, exceptions and compound-unit reasoning remain outside its claim.

For the new model runner, the three recovered letter log probabilities are renormalized correctly; forced binary scoring and native three-state scoring are separate. Strict JSON failure remains invalid. Invalid rule/evidence parsing defaults operationally to referral, but the statistics explicitly scores it as invalid rather than a correct unknown. The AND/OR/NOT combination is internally coherent.

One substantive interface ambiguity was identified before new inference: negated requirements under NOT could produce double negation. The model agent clarified the decomposition prompt to use affirmative leaves and logic-level negation, with guarded exceptions, in a separately hashed module before any new GGUF result. Literal quote matching and schema validation still establish provenance and syntax only, not entailment or requirement completeness.

The semantic JSON comparison is a joint instruction/output-protocol sensitivity analysis, because its instructions also clarify missing facts and logical scope. The bounded audit found no remaining fatal code discrepancy; it does not certify legal applicability or external model reliability.
'''
(OUT/'revision_interface_audit.md').write_text(text,encoding='utf8')
print(json.dumps({'replay':out['replay'],'decision':out['decision'],'v2_sha256':before[str(E/'constraint_engine_v2.py')]}))
