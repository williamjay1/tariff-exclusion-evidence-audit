"""Independent scalar recomputation and leakage checks for revision diagnostics."""
from common import *
from collections import defaultdict
from sklearn.metrics import balanced_accuracy_score,confusion_matrix
from sklearn.model_selection import StratifiedGroupKFold

def main():
    rows=load_rows();byid={r['case_id']:r for r in rows}
    preds=read(OUT/'all_diagnostic_predictions.jsonl');pm=defaultdict(dict)
    for p in preds:pm[p['model']][p['case_id']]=p
    a=json.loads((OUT/'diagnostic_analysis.json').read_text())
    logs=json.loads((OUT/'classical_training_log.json').read_text())
    report={'all_checks_passed':False,'scalar_metric_checks':0,'scalar_bootstrap_checks':[],
            'training_jobs_checked':len(logs),'frozen_hashes_unchanged':True}
    for log in logs:
        tr=[byid[c] for c in log['train_ids']];te=[byid[c] for c in log['test_ids']]
        assert not {r['group'] for r in tr}&{r['group'] for r in te}
        assert not set(log['train_ids'])&set(log['test_ids'])
        for split in StratifiedGroupKFold(log['inner_folds'],shuffle=True,
                  random_state=log['seed']+max(log['fold'],0)).split(
                      np.zeros(len(tr)),[r['y'] for r in tr],[r['group'] for r in tr]):
            ii,jj=split
            assert not {tr[i]['group'] for i in ii}&{tr[i]['group'] for i in jj}
            assert len({tr[i]['y'] for i in ii})==2 and len({tr[i]['y'] for i in jj})==2
        if log['model'].startswith('Cross_'):
            assert len({r['source'] for r in tr})==len({r['source'] for r in te})==1
            assert tr[0]['source']!=te[0]['source']
    # Independent sklearn point metrics, including every source/subset.
    for sub,ss in a['subsets'].items():
        selected=[r for r,m in zip(rows,subset_masks(rows)[sub]) if m]
        for source,d in ss.items():
            rr=selected if source=='all' else [r for r in selected if r['source']==source]
            y=[r['y'] for r in rr]
            for name,q in d['models'].items():
                p=[pm[name][r['case_id']]['binary'] for r in rr]
                assert abs(balanced_accuracy_score(y,p)-q['balanced_accuracy'])<1e-14
                assert confusion_matrix(y,p,labels=[0,1]).tolist()==q['confusion_matrix']
                report['scalar_metric_checks']+=1
    # Literal sampled-row bootstrap, independent of the vectorized group-count method.
    for sub,src in [('compatible_code_73','all'),('compatible_code_73','NY'),('exact_ten_digit_60','HQ')]:
        rr=[r for r,m in zip(rows,subset_masks(rows)[sub]) if m and (src=='all' or r['source']==src)]
        groups=sorted({r['group'] for r in rr});rng=np.random.default_rng(BOOT_SEED)
        lists=defaultdict(list)
        names=['Source_majority','Qwen4','Qwen4_guard','LR_full','LR_fact_only']
        names += [k for k in ['Qwen14_abc_original','Granite8_abc_original','Granite8_facts_only','Granite8_rules_only'] if k in pm]
        pairnames=[k for k,q in a['subsets'][sub][src]['paired_differences'].items() if q['A'] in names and q['B'] in names]
        for _ in range(B):
            chosen=rng.choice(groups,len(groups),replace=True)
            boot=[r for g in chosen for r in rr if r['group']==g]
            pos=sum(r['y'] for r in boot);neg=len(boot)-pos
            if not pos or not neg:continue
            vals={}
            for name in names:
                tp=sum(r['y']==1 and pm[name][r['case_id']]['binary']==1 for r in boot)
                tn=sum(r['y']==0 and pm[name][r['case_id']]['binary']==0 for r in boot)
                vals[name]=(tp/pos+tn/neg)/2;lists[name].append(vals[name])
            for key in pairnames:
                aa,bb=key.split(' MINUS ');lists[key].append(vals[aa]-vals[bb])
        for name,v in lists.items():
            ci=np.quantile(v,[.025,.975])
            target=(a['subsets'][sub][src]['paired_differences'][name]['metrics']['balanced_accuracy']
                    if name in pairnames else a['subsets'][sub][src]['models'][name]['cluster_bootstrap_95ci']['balanced_accuracy'])
            assert np.allclose(ci,[target['lower'],target['upper']],atol=1e-14)
            assert len(v)==target['valid_replicates']
        report['scalar_bootstrap_checks'].append({'subset':sub,'source':src,'models':len(names),
                         'paired_comparisons':pairnames,'valid_replicates':len(lists['Qwen4 MINUS Source_majority'])})
    # Exact legacy CI reproduction confirms that the resampling estimand did not change.
    old=json.loads((ROOT/'results/scale_analysis.json').read_text())
    for sub,oldsub in [('compatible_code_73','same_code'),('known_code_85','all_code_known'),('exact_ten_digit_60','exact_ten_digit')]:
        oq=old['observed'][oldsub]['models']['Qwen3 4B Instruct']
        nq=a['subsets'][sub]['all']['models']['Qwen4']
        for metric in ['balanced_accuracy','false_exemption_rate','eligible_recall']:
            assert abs(oq[metric]-nq[metric])<1e-14
            c=nq['cluster_bootstrap_95ci'][metric]
            assert np.allclose(oq['cluster_bootstrap_95ci'][metric],[c['lower'],c['upper']],atol=1e-14)
    execution=json.loads((OUT/'training_execution.json').read_text())
    assert all(sha(ROOT/k.replace('\\','/'))==v for k,v in execution['source_hashes'].items())
    reproduction=json.loads((OUT/'classical_reproduction.json').read_text())
    assert not reproduction['label_disagreements'] and reproduction['max_probability_difference']<1e-7
    report.update(all_checks_passed=True,full_classifier_reproduction=reproduction,
                  legacy_Qwen4_point_and_CI_reproduced=True,
                  old_imported_7_model_gated_predictions_reproduced=True)
    dump(OUT/'verification.json',report);print(json.dumps(report,indent=2))

if __name__=='__main__':main()
