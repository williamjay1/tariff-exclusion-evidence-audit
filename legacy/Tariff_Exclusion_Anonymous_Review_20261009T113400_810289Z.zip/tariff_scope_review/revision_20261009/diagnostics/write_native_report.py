"""Concise report from the current completed native-output statistics."""
from common import *
def main():
    a=json.loads((OUT/'native_three_state_analysis.json').read_text());main=a['subsets']['compatible_code_73']['all']
    def pct(v):return 'NA' if v is None else f'{v*100:.2f}'
    def cell(q):return f"{pct(q['value'])} [{pct(q['lower'])}, {pct(q['upper'])}]"
    out=['# Native three-state model diagnostics','',
        '本报告仅汇总已经完整写出 86 条、ID 集合完整且分析过程中哈希未变化的模型文件。未完成的模型不得当作已有实验。主要参照为 evidence_operational_reference.jsonl 的保守操作性 AI 证据状态（73 条：21 support、5 refute、47 unknown），包含已披露的源语义修订；不使用第一轮未协调的标签冒充最终参照。', '',
        '三个模型语义标签分别映射证据 support/refute/unknown。未知是独立类，不强制转为不适用；非法 JSON 或分解规则/证据解析失败计 invalid，在三态准确率分母内作为错误，并单列格式失败。分解管线的 invalid_quote_forced_missing 则保留守卫后的实际三态输出，并另列管线状态。', '',
        '区间沿用 2,000 次原 linked source-group 抽样，seed=20261007；同子集模型及差值共享抽样。三类 BA/macro-F1 只在该抽样含全部三参照类时计算，报告有效重复数。评估固定当前预测与参照编码，区间不包括 AI 编码误差或训练不确定性。', '',
        '## 当前完成模型的主集结果','',
        '| 模型/协议 | Evidence accuracy [95% CI] | 3-class BA [95% CI] | Macro-F1 [95% CI] | 确定回答 coverage | 确定回答 disposition error |',
        '|---|---|---|---|---|---|']
    for name,q in main['models'].items():
        m=q['metrics'];out.append(f"| {name} | {cell(m['evidence_accuracy'])} | {cell(m['three_class_balanced_accuracy'])} | {cell(m['macro_f1'])} | {pct(m['determinate_coverage']['value'])} | {pct(m['determinate_disposition_error_rate']['value'])} |")
    out+=['', 'Source_majority 来自对 administrative disposition 的训练折来源多数规则，作为来源捷径诊断，并非针对新三态证据标签拟合的模型。Always_unknown 是不回答任何确定结论的常数诊断；其较高准确率反映参照类比例，不能称为有用法律系统。', '',
          '## 已完成的 Qwen0.6 semantic JSON','',
          '冻结 86 条全部为 eligible，invalid=0、输入截断=0、生成上限命中=0，总推理墙钟 350.688 秒。73 主集与原 letter native 输出逐案相同；全部 paired 指标差值及区间为零。', '',
          '在最终操作性参照上，主集三态 accuracy=21/73=28.77% [13.13,48.06]；macro recall=33.33%，macro-F1=14.89% [7.73,21.66]。有 17/2000 次组重抽样缺 refute 类，故三类指标使用 1983 个有效重复。常数输出的 macro recall 退化区间不是对真实能力精确掌握，而是固定预测与定义的结果。', '',
          '确定回答覆盖率 100%，其 administrative disposition 错误率为26/73=35.62% [24.32,50.00]。这与证据任务错误率是不同目标，不能混称法律正确率。三态参照不是专家 gold。', '',
          '该次 semantic JSON 协议没有消除旧 0.6 checkpoint 在此样本上的全部授予行为，因此不能把旧结果仅归为 A/B/C 字母抽取问题；同时 JSON 指令新增了语义约束，提示模板/解码也不同，这不是只改变输出格式的一因素实验。它也不说明所有 LLM 或尚未完成的新 checkpoint 具有同样行为。', '',
          '## 0.6 JSON 的子集/来源支持','',
          '| 子集 | 来源 | n | S/R/U | Evidence accuracy [CI] | 3-class BA [CI] |',
          '|---|---|---:|---|---|---|']
    for sub,sources in a['subsets'].items():
        for source,d in sources.items():
            q=d['models']['Qwen06_semantic_json'];m=q['metrics'];cc=q['reference_counts'];counts='/'.join(str(cc.get(k,0)) for k in ['eligible','ineligible','unknown'])
            out.append(f"| {sub} | {source} | {q['n']} | {counts} | {cell(m['evidence_accuracy'])} | {cell(m['three_class_balanced_accuracy'])} |")
    out+=['','## 用于正文的限定表述','',
        'The semantic JSON protocol produced eligible for all 86 cases with no invalid or capped outputs. On the 73 compatible-code cases, its native predictions were identical to those from the original 0.6B letter protocol. Against the conservative AI evidence reference, three-state accuracy was 28.8% (cluster bootstrap 95% CI 13.1–48.1), with macro recall of 33.3%. These results show that the all-eligible behavior in this checkpoint and sample was not removed by the revised semantic protocol; they do not establish that output formatting alone caused the original behavior or that other models share the same limitation. Unknown and invalid outputs were not collapsed into ineligibility.', '',
        '完整机器表为 native_three_state_analysis.json、native_three_state_metrics.csv，逐案输出为 native_three_state_predictions.jsonl。后续完整模型可通过 analyze_new_models.py 复算；CI 不混入未完成文件。', '',
        '尚未完成/未提供的模型列表：', '']
    out += [f"- {r['model']}: {r['status']}" for r in a['pending']] if a['pending'] else ['本统计管线内预定 native 模型文件均已完整提供。']
    (OUT/'native_model_report.md').write_text('\n'.join(out)+'\n',encoding='utf8')
    print('native_model_report.md written')
if __name__=='__main__':main()
