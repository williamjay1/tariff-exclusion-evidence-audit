from common import *
A=json.loads((OUT/'diagnostic_analysis.json').read_text('utf8'));N=json.loads((OUT/'native_three_state_analysis.json').read_text('utf8'))
K=json.loads((OUT/'mechanism_model_analysis.json').read_text('utf8'));V=json.loads((OUT/'annotation_version_sensitivity.json').read_text('utf8'))
summary={'binary':{},'native':{},'mechanisms':{},'annotation':{},'refresh':json.loads((OUT/'completed_model_refresh.json').read_text('utf8'))['total_seconds']}
for name in N['inputs']:
    if name=='Qwen06_semantic_json':continue
    for sub in ['compatible_code_73','exact_ten_digit_60']:
        if name in A['subsets'][sub]['all']['models']:
            q=A['subsets'][sub]['all']['models'][name]
            summary['binary'][name+' '+sub]={k:q[k] for k in ['n','groups','tp','fn','fp','tn','balanced_accuracy','coverage','answered_error_rate']}
            summary['binary'][name+' '+sub]['BA_CI']=q['cluster_bootstrap_95ci']['balanced_accuracy']
    q=N['subsets']['compatible_code_73']['all']['models'][name]
    summary['native'][name]={'counts':q['prediction_counts'],
        'metrics':{k:q['metrics'][k] for k in ['evidence_accuracy','three_class_balanced_accuracy','unknown_recall','unsupported_share_of_support_outputs','determinate_coverage','determinate_disposition_error_rate']},
        'unsupported_support_outputs':q['unsupported_support_outputs'],
        'unknown_reference_support_outputs':q['unknown_reference_support_outputs']}
    summary['annotation'][name]={k:V['models'][name][k] for k in ['final_minus_first_accuracy','final_minus_second_accuracy']}
summary['paired_binary_73']={k:v['metrics']['balanced_accuracy'] for k,v in A['subsets']['compatible_code_73']['all']['paired_differences'].items() if 'Qwen14' in k or 'Granite8' in k}
summary['paired_native_73']={k:{m:v[m] for m in ['evidence_accuracy','three_class_balanced_accuracy','determinate_coverage','determinate_disposition_error_rate']} for k,v in N['subsets']['compatible_code_73']['all']['paired_differences'].items() if ('Qwen14' in k or 'Granite8' in k) and 'semantic_json' in k}
for name,q in K['models'].items():
    if 'semantic_json' in name:summary['mechanisms'][name]={'correct':q['correct'],'unique':q['exact_unique_weight_sensitivity'],'pairs':q['pairs'],
        'prediction_counts':q['prediction_counts'],'unknown_recall':q['metrics']['unknown_recall'],
        'by_family':{k:v['correct'] for k,v in q['by_family'].items()}}
summary['paired_mechanism_accuracy']={k:v['evidence_accuracy'] for k,v in K['paired_differences'].items() if 'semantic_json' in k}
dump(OUT/'completed_new_models_summary.json',summary);print(json.dumps(summary,indent=2))
