"""Train only revision diagnostic classical models; all outputs remain in diagnostics."""
from common import *
import re,time,platform
from collections import Counter
from sklearn.pipeline import Pipeline,FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold,GridSearchCV
from threadpoolctl import threadpool_limits
import sklearn
ROWS=load_rows();Y=np.array([r["y"] for r in ROWS]);G=np.array([r["group"] for r in ROWS])
ORIGINAL=np.array([r["fold"] for r in ROWS])
def inputs(view):
    rules=[re.split(r"\(\s*(?:as )?described",r["rule_text"],flags=re.I)[0] for r in ROWS]
    return np.array([r["facts"] if view=="fact_only" else rules[i] if view=="rule_only"
                     else r["source"] if view=="source_only" else r["facts"]+" RULE: "+rules[i] for i,r in enumerate(ROWS)])
def model(kind,seed):
    word=TfidfVectorizer(ngram_range=(1,2),min_df=1,sublinear_tf=True,max_features=18000)
    vec=word if kind=="word" else FeatureUnion([("word",word),("char",TfidfVectorizer(analyzer="char_wb",ngram_range=(3,5),sublinear_tf=True,max_features=30000))])
    return Pipeline([("tfidf",vec),("clf",LogisticRegression(class_weight="balanced",solver="liblinear",max_iter=2000,random_state=seed))])
LOG=[];PRED=[];SPLITS=[]
def fit_predict(train,test,view,kind,seed,fold,name,cross=False):
    assert not set(G[train])&set(G[test])
    x=inputs(view);start=time.perf_counter()
    detail={"model":name,"view":view,"kind":kind,"seed":seed,"fold":fold,
            "train_n":len(train),"test_n":len(test),"train_groups":len(set(G[train])),
            "test_groups":len(set(G[test])),"train_classes":dict(Counter(map(int,Y[train]))),
            "test_classes":dict(Counter(map(int,Y[test]))),"train_ids":[ROWS[i]["case_id"] for i in train],
            "test_ids":[ROWS[i]["case_id"] for i in test],"group_overlap":[]}
    if len(set(Y[train]))<2:
        detail["status"]="not_fit_single_training_class";LOG.append(detail);return
    candidates=[3,2] if cross else [3]
    cvs=[]
    for k in candidates:
        if len(set(G[train]))<k: continue
        cv=list(StratifiedGroupKFold(k,shuffle=True,random_state=seed+max(fold,0)).split(x[train],Y[train],G[train]))
        valid=all(len(set(Y[train][a]))==2 and len(set(Y[train][b]))==2 for a,b in cv)
        if valid:
            cvs=cv;break
    if not cvs and not cross:
        raise RuntimeError("Original/seed inner folds lack class support: "+str(detail))
    if cvs:
        search=GridSearchCV(model(kind,seed),{"clf__C":[.1,1.,10.]},cv=cvs,scoring="balanced_accuracy",n_jobs=1,error_score="raise")
        search.fit(x[train],Y[train]);est=search.best_estimator_
        detail.update(best_C=search.best_params_["clf__C"],inner_balanced_accuracy=search.best_score_,
                      inner_folds=len(cvs),inner_group_separated=True)
    else:
        est=model(kind,seed);est.set_params(clf__C=1.);est.fit(x[train],Y[train])
        detail.update(best_C=1.,inner_folds=0,inner_balanced_accuracy=None,tuning_note="Prespecified C=1: insufficient two-class group-fold support")
    proba=est.predict_proba(x[test])[:,1]
    for i,p in zip(test,proba):
        PRED.append(record(ROWS[i],name,int(p>=.5),p,training_scope="cross_source" if cross else "grouped_oof",
                           input_view=view,feature_kind=kind,seed=seed,outer_fold=fold))
    detail.update(status="complete",seconds=time.perf_counter()-start);LOG.append(detail)
    print(name,fold,"done",round(detail["seconds"],2),flush=True)
    write_jsonl(OUT/"classical_predictions.jsonl",PRED);dump(OUT/"classical_training_log.json",LOG)
def new_folds(seed):
    out=np.full(len(ROWS),-1)
    for k,(_,te) in enumerate(StratifiedGroupKFold(5,shuffle=True,random_state=seed).split(np.zeros(len(ROWS)),Y,G)):out[te]=k
    assert min(out)>=0;return out
def run():
    start=time.perf_counter()
    hashes={str(p.relative_to(ROOT)):sha(p) for p in [ROOT/"datasets/benchmark.jsonl",ROOT/"results/benchmark_classical.jsonl"]}
    with threadpool_limits(limits=1):
        for view in ["full","fact_only","rule_only","source_only"]:
            name="LR_"+view
            for fold in range(5):
                fit_predict(np.where(ORIGINAL!=fold)[0],np.where(ORIGINAL==fold)[0],view,"word_char",20261007,fold,name)
        for seed in [20261008,20261009,20261010]:
            folds=new_folds(seed);SPLITS.extend({**row_meta(r),"evaluation_seed":seed,"new_fold":int(folds[i])} for i,r in enumerate(ROWS))
            for kind in ["word","word_char"]:
                for fold in range(5):
                    fit_predict(np.where(folds!=fold)[0],np.where(folds==fold)[0],"full",kind,seed,fold,f"LR_full_{kind}_seed{seed}")
        for source in ["HQ","NY"]:
            test=np.array([i for i,r in enumerate(ROWS) if r["source"]!=source])
            testgroups=set(G[test]);original_train=np.array([i for i,r in enumerate(ROWS) if r["source"]==source])
            train=np.array([i for i in original_train if G[i] not in testgroups])
            for kind in ["word","word_char"]:
                name=f"Cross_{source}_to_{'NY' if source=='HQ' else 'HQ'}_{kind}"
                fit_predict(train,test,"full",kind,20261007,-1,name,cross=True)
                LOG[-1]["purged_train_ids"]=[ROWS[i]["case_id"] for i in original_train if G[i] in testgroups]
                LOG[-1]["unpurged_train_n"]=len(original_train)
    old={r["case_id"]:r for r in read(ROOT/"results/benchmark_classical.jsonl") if r["model"]=="word_char_lr"}
    new={r["case_id"]:r for r in PRED if r["model"]=="LR_full"}
    check={"label_disagreements":[cid for cid in old if old[cid]["binary_prediction"]!=new[cid]["binary_raw"]],
           "max_probability_difference":max(abs(old[c]["prob_eligible"]-new[c]["prob_eligible"]) for c in old)}
    dump(OUT/"classical_reproduction.json",check)
    assert not check["label_disagreements"] and check["max_probability_difference"]<1e-7,check
    assert all(sha(ROOT/k)==v for k,v in hashes.items())
    write_jsonl(OUT/"classical_predictions.jsonl",PRED);dump(OUT/"classical_training_log.json",LOG)
    write_jsonl(OUT/"seed_split_assignments.jsonl",SPLITS)
    dump(OUT/"training_execution.json",{"status":"completed","post_hoc":True,"seconds":time.perf_counter()-start,
         "python":sys.version,"sklearn":sklearn.__version__,"numpy":np.__version__,"threads":1,
         "source_hashes":hashes,"original_inputs_unchanged":True,"prediction_rows":len(PRED)})
if __name__=="__main__":run()

