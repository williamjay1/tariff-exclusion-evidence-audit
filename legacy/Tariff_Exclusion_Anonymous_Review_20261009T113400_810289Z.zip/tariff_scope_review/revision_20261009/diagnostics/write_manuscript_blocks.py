"""Generate directly sourced English result blocks; unfinished runs stay pending."""
from common import *
A=json.loads((OUT/'diagnostic_analysis.json').read_text('utf8'))
N=json.loads((OUT/'native_three_state_analysis.json').read_text('utf8'))
K=json.loads((OUT/'mechanism_model_analysis.json').read_text('utf8'))
V=json.loads((OUT/'annotation_version_sensitivity.json').read_text('utf8'))
E=ROOT/'revision_20261009/evidence_numeric'
agreement=json.loads((E/'evidence_agreement.json').read_text('utf8'))
main=A['subsets']['compatible_code_73']['all'];exact=A['subsets']['exact_ten_digit_60']['all']
native=N['subsets']['compatible_code_73']['all'];nexact=N['subsets']['exact_ten_digit_60']['all']
names={'Code_only':'Code gate','Frozen_LR_word':'Word LR','Frozen_LR_word_char':'Word + character LR',
 'LR_full':'Full text LR','LR_fact_only':'Facts only LR','LR_rule_only':'Rules only LR','LR_source_only':'Source only LR',
 'Source_majority':'Training-fold source majority','NLI':'DeBERTa NLI','NLI_guard':'DeBERTa NLI + guard',
 'Qwen06':'Qwen 0.6B (ABC)','Qwen06_guard':'Qwen 0.6B + guard','Qwen4':'Qwen 4B (ABC)',
 'Qwen4_guard':'Qwen 4B + guard','Qwen06_semantic_json':'Qwen 0.6B (JSON)','Always_unknown':'Always unknown',
 'Qwen14_abc_original':'Qwen 14B (ABC)','Qwen14_semantic_json':'Qwen 14B (JSON)',
 'Granite8_abc_original':'Granite 8B (ABC)','Granite8_semantic_json':'Granite 8B (JSON)',
 'Granite8_facts_only':'Granite 8B (facts only ABC)','Granite8_rules_only':'Granite 8B (rules only ABC)',
 'Granite8_decomposition':'Granite 8B (decomposition)'}
def pct(x):return 'NA' if x is None else f'{100*x:.1f}'
def interval(q):return f"[{pct(q['lower'])}, {pct(q['upper'])}]"
def nm(q,metric):
    z=q['metrics'][metric];return pct(z['value'])+' '+interval(z)
def bm(q,metric):return pct(q[metric])+' '+interval(q['cluster_bootstrap_95ci'][metric])
def delta(q):return pct(q['delta'])+' '+interval(q)
def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','|'+'---|'*len(headers)]+['| '+' | '.join(map(str,r))+' |' for r in rows])
def title(k):return names.get(k,k)
blocks={}
order=['Code_only','Frozen_LR_word','Frozen_LR_word_char','NLI','NLI_guard','Qwen06','Qwen06_guard',
       'Qwen4','Qwen4_guard','Source_majority','Qwen14_abc_original','Granite8_abc_original']
body=[]
for name in order:
    if name not in main['models']:continue
    q=main['models'][name];z=exact['models'][name]
    body.append([title(name),pct(q['balanced_accuracy']),interval(q['cluster_bootstrap_95ci']['balanced_accuracy']),
        f"{q['fp']}/26",f"{q['fn']}/47",pct(z['balanced_accuracy']),interval(z['cluster_bootstrap_95ci']['balanced_accuracy'])])
blocks['BINARY_TABLE']=table(['Model','73 BA (%)','95% CI','False grants','False denials','60 BA (%)','95% CI'],body)+'''

The 73-case columns use 47 eligible and 26 ineligible administrative dispositions; the 60-case sensitivity uses 45 and 15, respectively. False grants and false denials denote disagreements with the administrative disposition, not verified errors in actual import eligibility. All displayed binary models share the known-code-mismatch gate, which changes no predictions in either displayed subset. ABC models are forced binary by comparing the conditional eligible and ineligible scores, whereas native unknown outputs are preserved for separate three-state evaluation. Confidence intervals resample the original linked source groups, with fixed predictions and identical draws for paired contrasts. Constant-prediction intervals can be degenerate by construction. Native JSON and decomposition outputs are not forced into binary scores.
'''

text=''
needed=['Granite8_abc_original','Granite8_facts_only','Granite8_rules_only']
if all(k in main['models'] for k in needed):
    text='The neural input sensitivity held the Granite checkpoint, precision, prompt, scoring and decoding fixed and removed either the rule or the facts.\n\nTable 0. Within-model Granite input sensitivity.\n\n'+table(['Input','73 BA [95% CI] (%)','60 BA [95% CI] (%)','Native E/I/U/invalid','Determinate coverage [95% CI] (%)'],
        [[title(k),bm(main['models'][k],'balanced_accuracy'),bm(exact['models'][k],'balanced_accuracy'),
          '/'.join(str(native['models'][k]['prediction_counts'].get(c,0)) for c in ['eligible','ineligible','unknown','invalid']),
          nm(native['models'][k],'determinate_coverage')] for k in needed])
    for other in needed[1:]:
        d=main['paired_differences'][needed[0]+' MINUS '+other]['metrics']['balanced_accuracy']
        text+=f"\n\nFull input minus {title(other)} was {delta(d)} percentage points on the primary subset."
    text+=' Removing an input changes the available evidence and can legitimately induce unknown answers. These controls diagnose reliance on the supplied texts rather than performance on complete-facts legal tasks.'
else:text+='\n\n[PENDING: same-checkpoint Granite full/facts-only/rules-only outputs are not all complete.]'
blocks['NEURAL_ABLATION_RESULTS']=text

text='The additional checkpoints were evaluated as post hoc sensitivity analyses, not a controlled parameter-count experiment: model families, weights, precision and inference implementations differ from the original runs.'
pf=[]
for model,prefix in [('qwen14','Qwen14'),('granite8','Granite8')]:
    path=ROOT/'revision_20261009/models/outputs'/f'{model}_preflight.jsonl'
    if not path.exists():continue
    rr=read(path)
    if len(rr)!=18 or len({r['key'] for r in rr})!=18:continue
    for protocol in ['abc_original','semantic_json']:
        qs=[r for r in rr if r['protocol']==protocol];assert len(qs)==9
        pf.append([title(prefix+'_'+protocol),sum(r['parsed']==r['expected'] for r in qs),len(qs),sum(r.get('invalid_output',False) for r in qs)])
if pf:
    text+='\n\nTable 0. Fixed independent protocol controls for the additional checkpoints.\n\n'+table(['Model / protocol','Correct','Control items','Invalid'],pf)
    text+='\n\nThese nine elementary items per protocol test the output interface and basic semantic distinctions; they are not legal benchmark cases or a comprehensive reasoning test. ABC correctness refers to restricted first-token classification from the three letter scores; zero invalid entries means those scores were recoverable, not that unrestricted generation complied with the one-letter instruction. JSON correctness and invalid counts instead use strict parsing of the complete generated decision object.'
for k in ['Qwen14_abc_original','Granite8_abc_original']:
    if k not in main['models']:
        text+=f'\n\n[PENDING: {title(k)} complete 86-case output.]';continue
    q=main['models'][k]
    text+=f"\n\n{title(k)} achieved primary balanced accuracy of {bm(q,'balanced_accuracy')}%, compared with {bm(exact['models'][k],'balanced_accuracy')}% in the exact-code sensitivity."
    for other in ['Source_majority','Qwen4']:
        d=main['paired_differences'][k+' MINUS '+other]['metrics']['balanced_accuracy']
        text+=f" Its paired difference from {title(other)} was {delta(d)} percentage points."
for prefix in ['Qwen14','Granite8']:
    k=prefix+'_semantic_json';other=prefix+'_abc_original'
    if k not in native['models'] or other not in native['models']:
        text+=f'\n\n[PENDING: {prefix} native JSON/ABC protocol comparison.]';continue
    q=native['models'][k];d=native['paired_differences'][k+' MINUS '+other]['evidence_accuracy']
    text+=f"\n\n{title(k)} had native evidence accuracy {nm(q,'evidence_accuracy')}%, with a paired change of {delta(d)} percentage points from its ABC protocol. Its primary outputs comprised {q['prediction_counts'].get('eligible',0)} eligible, {q['prediction_counts'].get('ineligible',0)} ineligible, {q['prediction_counts'].get('unknown',0)} unknown and {q['prediction_counts'].get('invalid',0)} invalid outputs."
text+=' The JSON condition also clarifies missing evidence and AND/OR scope, so these comparisons measure joint instruction and output-protocol sensitivity. They are not a single-factor output-string experiment.'
blocks['ADDITIONAL_MODEL_RESULTS']=text

eo=['NLI','NLI_guard','Qwen06','Qwen06_guard','Qwen4','Qwen4_guard','Source_majority','Always_unknown',
    'Qwen06_semantic_json','Qwen14_abc_original','Qwen14_semantic_json','Granite8_abc_original','Granite8_semantic_json','Granite8_decomposition']
et=[]
for name in eo:
    if name not in native['models']:continue
    q=native['models'][name];support=q['prediction_counts'].get('eligible',0)
    unsupported=f"{q['unsupported_support_outputs']}/{support}" if support else 'NA (0 support outputs)'
    et.append([title(name),nm(q,'evidence_accuracy'),nm(q,'three_class_balanced_accuracy'),nm(q,'unknown_recall'),
               unsupported,pct(q['metrics']['determinate_coverage']['value'])])
text=f"The final operational AI evidence reference classified 21 of the 73 compatible-code pairs as supported, 5 as refuted and 47 as unknown under the complete retained inputs. Before conservative reconciliation and the disclosed source-level corrections, two AI coding passes agreed on {agreement['matching']}/{agreement['n']} cases ({100*agreement['agreement']:.1f}%; Cohen's kappa {agreement['cohen_kappa']:.3f}). This measures reproducibility of two same-lineage AI readings; it is neither independent expert agreement nor validation of legal correctness. The coding agents had prior project exposure, although the coding files masked administrative dispositions. No post-reconciliation agreement coefficient is presented."
text+='\n\nTable 0. Native three-state predictions against the complete retained-input AI evidence reference.\n\n'+table(['Native model / protocol','Accuracy [95% CI] (%)','Macro recall [95% CI] (%)','Unknown recall [95% CI] (%)','Unsupported / support outputs','Determinate coverage (%)'],et)
text+='''

For this table, eligible, ineligible and unknown outputs are compared with supported, refuted and unknown evidence states. Unsupported support outputs are eligible outputs when the AI evidence reference is refuted or unknown; this is an evidence-grounding discrepancy and must not be conflated with an erroneous actual tariff grant. Invalid JSON or an invalid rule or evidence parse counts as incorrect in evidence accuracy and is excluded from determinate coverage. Three-class metrics require all reference classes in a resampled draw; the primary subset supplies 1,983 valid draws out of 2,000. Confidence intervals condition on the current AI coding and do not include annotation uncertainty.

The always-unknown diagnostic matched 47/73 references (64.4%) but made no determinate decisions; its macro recall was 33.3%. Its accuracy therefore demonstrates the importance of the unknown-class prevalence, not the usefulness of refusing every case. The source-majority baseline was trained on administrative dispositions, not on the three-state evidence reference. Its evidence scores are a shortcut diagnostic rather than the result of a three-state learning experiment.
'''
q=native['models']['Qwen06_semantic_json']
text+=f"\nThe 0.6B JSON checkpoint labeled all {q['unknown_reference_support_outputs']} unknown-reference cases supported and produced {q['unsupported_support_outputs']} unsupported support outputs among its 73 primary answers. Its evidence accuracy was {nm(q,'evidence_accuracy')}%, while its administrative error rate among determinate answers was {nm(q,'determinate_disposition_error_rate')}%. These are distinct targets."
nli=json.loads((OUT/'nli_untruncated_sensitivity.json').read_text('utf8'))['metrics']
text+=f"\n\nNLI is evaluated against the complete retained-input reference, although three primary inputs exceeded its 512-token limit. A sensitivity excluding only those documented truncations retained 70 cases in 39 linked groups (21 supported, 4 refuted, 45 unknown). NLI evidence accuracy was {nm(nli,'evidence_accuracy')}%, macro recall {nm(nli,'three_class_balanced_accuracy')}%, macro-F1 {nm(nli,'macro_f1')}%, and unknown recall {nm(nli,'unknown_recall')}%. There were 1,974 valid three-class bootstrap draws. This sensitivity does not replace the primary 73-case result or recode the reference to match truncated text."
qv=V['models']['Qwen4'];uv=V['models']['Always_unknown'];vs=['first_pass','second_case_pass','final_operational']
text+='\n\nWith predictions fixed, Qwen 4B native accuracy was '+', '.join(pct(qv[v]['accuracy'])+'%' for v in vs)+' against the first, second and final AI coding versions, while always-unknown accuracy was '+', '.join(pct(uv[v]['accuracy'])+'%' for v in vs)+'. These descriptive version sensitivities (Appendix D4) expose dependence on the conservative reconciliation and source-correction policy; they neither select the most favorable labels nor establish any version as independent truth.'
if 'Granite8_decomposition' in native['models']:
    q=native['models']['Granite8_decomposition'];inp=N['inputs']['Granite8_decomposition']
    text+=f"\n\nThe decomposition pipeline achieved evidence accuracy {nm(q,'evidence_accuracy')}% and unknown recall {nm(q,'unknown_recall')}%, with {q['prediction_counts'].get('invalid',0)}/73 invalid pipelines in the primary subset."
    if 'Granite8_semantic_json' in native['models']:
        d=native['paired_differences']['Granite8_decomposition MINUS Granite8_semantic_json']['evidence_accuracy']
        text+=f" Its paired accuracy difference from direct Granite JSON was {delta(d)} percentage points."
    guard=inp['quote_guard']['compatible_code_73']
    text+=f" In the primary subset, {guard['bad_quote_conditions']} of {guard['recorded_conditions']} recorded condition quotes failed literal-source validation, affecting {guard['bad_quote_cases']}/73 cases."
    if guard['bad_quote_cases']:
        text+=f" Those cases retained their actual post-guard outputs: "+', '.join(f'{n} {label}' for label,n in guard['guarded_case_final_native_counts'].items())+f"; determinate coverage within the affected cases was {pct(guard['guarded_case_determinate_coverage'])}%."
    text+=' An invalid quote forces its condition to missing, but a structurally valid pipeline still contributes its final guarded state to accuracy and coverage. It is not counted as an invalid parse; quote failures are reported separately.'
    text+=' Rule/evidence schema validity and literal quote occurrence establish structural and provenance checks only. They do not validate entailment, complete requirement coverage, or legal scope. Failed parsing is not credited as a correct unknown.'
else:text+='\n\n[PENDING: complete Granite decomposition evidence results.]'
blocks['EVIDENCE_RESULTS']=text

st=[]
npred=read(OUT/'native_three_state_predictions.jsonl');primary_ids={r['case_id'] for r in load_rows() if r['code_match']==1}
so=['NLI','NLI_guard','Qwen06','Qwen06_guard','Qwen4','Qwen4_guard','Qwen14_abc_original','Granite8_abc_original']
for name in so:
    if name not in main['models']:continue
    q=main['models'][name]
    st.append([title(name),q['answered'],bm(q,'coverage'),bm(q,'answered_error_rate'),pct(q['eligible_coverage']),pct(q['ineligible_coverage'])])
for name in ['Qwen06_semantic_json','Qwen14_semantic_json','Granite8_semantic_json','Granite8_decomposition']:
    if name not in native['models']:continue
    q=native['models'][name]
    qs=[r for r in npred if r['model']==name and r['case_id'] in primary_ids]
    classcov=[sum(r['y']==y and r['native_int'] in [0,1] for r in qs)/sum(r['y']==y for r in qs) for y in [1,0]]
    st.append([title(name),q['determinate_n'],nm(q,'determinate_coverage'),nm(q,'determinate_disposition_error_rate'),pct(classcov[0]),pct(classcov[1])])
text='Table 0. Selective administrative-disposition errors and class-specific coverage.\n\n'+table(['Model / native protocol','Answered n','Coverage [95% CI] (%)','Answered disposition error [95% CI] (%)','Eligible coverage (%)','Ineligible coverage (%)'],st)
text+='\n\nCoverage counts only eligible/ineligible native decisions. Answered error is disagreement with administrative disposition among those answers, not the error rate of all cases or of all legal decisions. Unknown and invalid JSON outputs are not recoded as denials. Class-specific coverage in the ABC rows refers to administrative disposition classes.'
for a,b in [('NLI_guard','NLI'),('Qwen06_guard','Qwen06'),('Qwen4_guard','Qwen4')]:
    d=main['paired_differences'][a+' MINUS '+b]['metrics']
    text+=f"\n\nFor {title(b)}, the frozen numeric guard changed coverage by {delta(d['coverage'])} percentage points and answered disposition error by {delta(d['answered_error_rate'])} percentage points."
text+=' A reduction in answers is not by itself evidence of better selective decision quality; comparisons condition on different answered sets.'
blocks['SELECTIVE_TABLE']=text

at=[]
for name in ['Source_majority','Qwen4','Qwen14_abc_original','Granite8_abc_original']:
    if name not in main['models']:continue
    for source in ['HQ','NY']:
        q=A['subsets']['compatible_code_73'][source]['models'][name]
        at.append([title(name),source,q['n'],q['groups'],f"{q['tn']}/{q['fp']}/{q['fn']}/{q['tp']}",bm(q,'balanced_accuracy')])
text='Table D1. Source-stratified binary evaluation on the compatible-code subset.\n\n'+table(['Model','Source','n','Groups','TN/FP/FN/TP','BA [95% CI] (%)'],at)
text+='\n\nThe primary HQ subset contains 27 cases (11 eligible, 16 ineligible) and 21 groups; NY contains 46 cases (36 eligible, 10 ineligible) and 20 groups. These are source-stratified evaluations of the fixed predictions, not separate training runs. The 60-case sensitivity keeps all 46 NY cases but only 14 HQ cases, changing source composition. The primary NY bootstrap has 1,999 valid binary BA draws; the 60-case HQ bootstrap has 1,937. Other supported binary BA draws are reported with the machine-readable results.'
pt=[]
for k in ['Qwen4 MINUS Source_majority','Qwen14_abc_original MINUS Source_majority','Granite8_abc_original MINUS Source_majority',
          'Qwen14_abc_original MINUS Qwen4','Granite8_abc_original MINUS Qwen4','Granite8_abc_original MINUS Qwen14_abc_original',
          'Granite8_abc_original MINUS Granite8_facts_only','Granite8_abc_original MINUS Granite8_rules_only']:
    if k not in main['paired_differences']:continue
    a,b=k.split(' MINUS ')
    pt.append([title(a)+' minus '+title(b),delta(main['paired_differences'][k]['metrics']['balanced_accuracy']),
               delta(exact['paired_differences'][k]['metrics']['balanced_accuracy'])])
text+='\n\nTable D2. Paired binary balanced-accuracy contrasts.\n\n'+table(['Paired contrast','73 delta BA [95% CI] (pp)','60 delta BA [95% CI] (pp)'],pt)
cost=[]
for name,q in N['inputs'].items():
    seconds=q.get('total_inference_seconds_including_rule_parses',q['inference_seconds'])
    cost.append([title(name),q['n'],f'{seconds:.2f}',q['invalid'],q['truncated'],q['stopped_limit']])
for name,q in K['inputs'].items():
    if 'semantic_json' in name:
        cost.append([title(name)+' mechanisms',q['n'],f"{q['inference_seconds']:.2f}",q['invalid'],q['truncated'],q.get('stopped_limit',0)])
text+='\n\nTable D3. Recorded inference calls and output integrity.\n\n'+table(['Protocol','Recorded cases','Recorded inference seconds','Invalid native outputs','Truncated inputs','Limit stops'],cost)
text+='\n\nRecorded inference times exclude weight download, server startup and data construction. Decomposition totals include its cached unique rule-generation calls and case-level evidence calls; they do not charge the same cached rule once per case. For ABC, the invalid column concerns recoverability of the restricted class scores, not full-generation compliance; one-token scoring intentionally reaches its generation limit. Direct JSON invalid counts use strict decision-object parsing; decomposition invalid counts additionally include rule-schema, tree and literal-quotation validation failures. Cross-checkpoint runtime and performance are implementation-dependent, and quantized runs are not controlled comparisons of parameter count. The reporting follows the recorded calls; it is not a prospective economic cost estimate.'
version_order=eo+['Granite8_facts_only','Granite8_rules_only']
version_rows=[]
for name in version_order:
    if name not in V['models']:continue
    q=V['models'][name]
    version_rows.append([title(name)]+[pct(q[v]['accuracy'])+' / '+pct(q[v]['macro_recall']) for v in vs])
text+='\n\nTable D4. Accuracy / macro recall (%) under preserved AI coding versions.\n\n'+table(['Native model / protocol','First pass','Second case-level pass','Final operational'],version_rows)
text+='\n\nAll three versions contain the same 73 IDs. Their supported/refuted/unknown counts are 23/5/45, 25/4/44 and 21/5/47, respectively. Predictions are held fixed; no model is retrained, no version is selected by its score, and no bootstrap is added for this descriptive comparison. The second pass is a case-level review, not a second complete condition-span annotation. These are same-lineage AI readings and an operational reconciliation, not independent gold standards. Invalid predictions remain incorrect. NLI and input-removal controls retain their actual inputs while all three reference versions concern complete retained text.'
blocks['NEW_MODEL_APPENDIX']=text

kt=[]
for name in ['Qwen14_semantic_json','Granite8_semantic_json']:
    if name not in K['models']:continue
    q=K['models'][name];unique=q['exact_unique_weight_sensitivity']
    kt.append([title(name),f"{q['correct']}/96",pct(q['metrics']['evidence_accuracy']['value']),pct(unique['mean_accuracy']),
               q['prediction_counts'].get('invalid',0),q['pairs']['equivalence']['both_correct']])
if kt:
    text='Table 0. Additional models on the constructed mechanism diagnostics.\n\n'+table(['Native protocol','Correct / presentations','Presentation accuracy (%)','Equal exact-input accuracy (%)','Invalid','Equivalent pairs both correct'],kt)
    text+='\n\nThese are AI-authored constructed tests with 12 purposively selected families, 48 linked pairs and 88 exact unique inputs; the 96 presentations are not independent legal cases. The equal-input sensitivity weights each exact fact–rule input once, averaging repeated outputs within an input. It is not external validation. Pairwise prediction consistency alone is insufficient, because a model can consistently return the wrong state.'
    for name in ['Qwen14_semantic_json','Granite8_semantic_json']:
        if name not in K['models']:continue
        q=K['models'][name]
        text+=f"\n\n{title(name)} obtained both members correct in "+', '.join(f"{v['both_correct']}/{v['n']} {kind} pairs" for kind,v in q['pairs'].items())+'.'
    text+=' The paired family-resampling intervals are retained as conditional sensitivity summaries over these 12 chosen families, not as sampling inference for a population of legal requirements.'
else:text='[PENDING: complete 96-case new-model mechanism outputs. Retain the existing numeric/constructed-design results.]'
blocks['MECHANISM_MODEL_RESULTS']=text
# These keys intentionally contain no replacement prose: root owns the revised
# numeric-layer and prior mechanism sections and must preserve them.
blocks['NUMERIC_LAYER_RESULTS']='[ROOT-OWNED: retain the existing independently verified numeric-layer section.]'
blocks['MECHANISM_RESULTS']='[ROOT-OWNED: retain the existing constructed-design and numeric-engine section.]'
dump(OUT/'manuscript_results_blocks.json',blocks)
expected=['Qwen14_abc_original','Qwen14_semantic_json','Granite8_abc_original','Granite8_semantic_json','Granite8_facts_only','Granite8_rules_only','Granite8_decomposition']
pending=[name for name in expected if name not in N['inputs']]+['mechanism:'+name for name in ['Qwen14_semantic_json','Granite8_semantic_json'] if name not in K['models']]
dump(OUT/'manuscript_results_blocks_status.json',{'complete':not pending,'pending':pending,
 'root_owned_do_not_replace':['NUMERIC_LAYER_RESULTS','MECHANISM_RESULTS'],
 'source_hashes':{p.name:sha(p) for p in [OUT/'diagnostic_analysis.json',OUT/'native_three_state_analysis.json',OUT/'mechanism_model_analysis.json',OUT/'nli_untruncated_sensitivity.json',OUT/'annotation_version_sensitivity.json']}})
print(json.dumps({'blocks':list(blocks),'complete':not pending,'pending':pending}))
